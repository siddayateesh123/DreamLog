import express from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  calculateSleepDuration,
  calculateTimeRangeHours,
  generateProtectiveExamTimetable,
  getLocalDateStr,
  parseTimeToMinutes,
} from './src/shared/math.ts';
import type { ExamPlanTask, ExamSchedule } from './src/shared/types.ts';
import { getDashboardAnalytics } from './server/analytics.ts';
import {
  clearDemoData,
  db,
  getUserSettings,
  initDatabase,
  rebuildDailyMetrics,
  resetDemoData,
} from './server/db.ts';

initDatabase();

const app = express();
app.use(express.json({ limit: '1mb' }));

function isValidDateStr(dateStr: unknown): dateStr is string {
  return typeof dateStr === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(dateStr);
}

function isValidTimeStr(timeStr: unknown): timeStr is string {
  return typeof timeStr === 'string' && !Number.isNaN(parseTimeToMinutes(timeStr));
}

// ---------------- SLEEP ROUTES ----------------
app.get('/api/sleep', (_req, res) => {
  const rows = db
    .prepare('SELECT * FROM sleep_logs ORDER BY date DESC, id DESC')
    .all() as Array<Record<string, unknown>>;
  res.json(rows.map((r) => ({ ...r, isDemo: Boolean(r.isDemo) })));
});

app.post('/api/sleep', (req, res) => {
  const { date, bedtime, wakeTime, sleepQuality, notes = '' } = req.body ?? {};
  if (!isValidDateStr(date)) {
    res.status(400).json({ error: 'Valid date (YYYY-MM-DD) is required.' });
    return;
  }
  if (!isValidTimeStr(bedtime) || !isValidTimeStr(wakeTime)) {
    res.status(400).json({ error: 'Valid bedtime and wake-up time (HH:mm) are required.' });
    return;
  }
  const quality = Number(sleepQuality);
  if (!Number.isInteger(quality) || quality < 1 || quality > 5) {
    res.status(400).json({ error: 'Sleep quality rating must be an integer between 1 and 5.' });
    return;
  }
  const duration = calculateSleepDuration(bedtime, wakeTime);
  if (duration < 0.25 || duration > 20) {
    res.status(400).json({
      error: 'Calculated sleep duration must be between 15 minutes and 20 hours. Check bedtime and wake-up time.',
    });
    return;
  }

  const nowIso = new Date().toISOString();
  const result = db
    .prepare(
      `INSERT INTO sleep_logs (date, bedtime, wakeTime, duration, sleepQuality, notes, isDemo, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, 0, ?)`,
    )
    .run(date, bedtime, wakeTime, duration, quality, String(notes ?? '').trim(), nowIso);

  rebuildDailyMetrics();
  const created = db.prepare('SELECT * FROM sleep_logs WHERE id = ?').get(result.lastInsertRowid) as Record<
    string,
    unknown
  >;
  res.status(201).json({ ...created, isDemo: Boolean(created.isDemo) });
});

app.put('/api/sleep/:id', (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM sleep_logs WHERE id = ?').get(id);
  if (!existing) {
    res.status(404).json({ error: 'Sleep log not found.' });
    return;
  }

  const { date, bedtime, wakeTime, sleepQuality, notes = '' } = req.body ?? {};
  if (!isValidDateStr(date) || !isValidTimeStr(bedtime) || !isValidTimeStr(wakeTime)) {
    res.status(400).json({ error: 'Valid date, bedtime, and wake-up time are required.' });
    return;
  }
  const quality = Number(sleepQuality);
  if (!Number.isInteger(quality) || quality < 1 || quality > 5) {
    res.status(400).json({ error: 'Sleep quality must be between 1 and 5.' });
    return;
  }
  const duration = calculateSleepDuration(bedtime, wakeTime);
  if (duration < 0.25 || duration > 20) {
    res.status(400).json({ error: 'Calculated sleep duration must be between 15 minutes and 20 hours.' });
    return;
  }

  db.prepare(
    `UPDATE sleep_logs
     SET date = ?, bedtime = ?, wakeTime = ?, duration = ?, sleepQuality = ?, notes = ?, isDemo = 0
     WHERE id = ?`,
  ).run(date, bedtime, wakeTime, duration, quality, String(notes ?? '').trim(), id);

  rebuildDailyMetrics();
  const updated = db.prepare('SELECT * FROM sleep_logs WHERE id = ?').get(id) as Record<string, unknown>;
  res.json({ ...updated, isDemo: Boolean(updated.isDemo) });
});

app.delete('/api/sleep/:id', (req, res) => {
  const id = Number(req.params.id);
  const info = db.prepare('DELETE FROM sleep_logs WHERE id = ?').run(id);
  if (info.changes === 0) {
    res.status(404).json({ error: 'Sleep log not found.' });
    return;
  }
  rebuildDailyMetrics();
  res.json({ deleted: true, id });
});

// ---------------- STUDY ROUTES ----------------
app.get('/api/study', (_req, res) => {
  const rows = db
    .prepare('SELECT * FROM study_logs ORDER BY date DESC, id DESC')
    .all() as Array<Record<string, unknown>>;
  res.json(rows.map((r) => ({ ...r, isDemo: Boolean(r.isDemo) })));
});

app.post('/api/study', (req, res) => {
  const {
    date,
    subject,
    studyHours,
    focusRating,
    startTime = '',
    endTime = '',
    notes = '',
  } = req.body ?? {};

  if (!isValidDateStr(date)) {
    res.status(400).json({ error: 'Valid date (YYYY-MM-DD) is required.' });
    return;
  }
  if (typeof subject !== 'string' || subject.trim().length === 0) {
    res.status(400).json({ error: 'Subject name is required.' });
    return;
  }
  let hours = Number(studyHours);
  if ((!hours || Number.isNaN(hours)) && isValidTimeStr(startTime) && isValidTimeStr(endTime)) {
    hours = calculateTimeRangeHours(startTime, endTime);
  }
  if (Number.isNaN(hours) || hours < 0.25 || hours > 16) {
    res.status(400).json({ error: 'Study duration must be between 0.25 and 16 hours.' });
    return;
  }
  const focus = Number(focusRating);
  if (!Number.isInteger(focus) || focus < 1 || focus > 5) {
    res.status(400).json({ error: 'Focus rating must be an integer between 1 and 5.' });
    return;
  }

  const nowIso = new Date().toISOString();
  const result = db
    .prepare(
      `INSERT INTO study_logs (date, subject, studyHours, focusRating, startTime, endTime, notes, isDemo, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`,
    )
    .run(
      date,
      subject.trim(),
      Math.round(hours * 100) / 100,
      focus,
      String(startTime ?? ''),
      String(endTime ?? ''),
      String(notes ?? '').trim(),
      nowIso,
    );

  rebuildDailyMetrics();
  const created = db.prepare('SELECT * FROM study_logs WHERE id = ?').get(result.lastInsertRowid) as Record<
    string,
    unknown
  >;
  res.status(201).json({ ...created, isDemo: Boolean(created.isDemo) });
});

app.put('/api/study/:id', (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM study_logs WHERE id = ?').get(id);
  if (!existing) {
    res.status(404).json({ error: 'Study session not found.' });
    return;
  }

  const {
    date,
    subject,
    studyHours,
    focusRating,
    startTime = '',
    endTime = '',
    notes = '',
  } = req.body ?? {};

  if (!isValidDateStr(date) || typeof subject !== 'string' || subject.trim().length === 0) {
    res.status(400).json({ error: 'Valid date and subject name are required.' });
    return;
  }
  const hours = Number(studyHours);
  if (Number.isNaN(hours) || hours < 0.25 || hours > 16) {
    res.status(400).json({ error: 'Study duration must be between 0.25 and 16 hours.' });
    return;
  }
  const focus = Number(focusRating);
  if (!Number.isInteger(focus) || focus < 1 || focus > 5) {
    res.status(400).json({ error: 'Focus rating must be between 1 and 5.' });
    return;
  }

  db.prepare(
    `UPDATE study_logs
     SET date = ?, subject = ?, studyHours = ?, focusRating = ?, startTime = ?, endTime = ?, notes = ?, isDemo = 0
     WHERE id = ?`,
  ).run(
    date,
    subject.trim(),
    Math.round(hours * 100) / 100,
    focus,
    String(startTime ?? ''),
    String(endTime ?? ''),
    String(notes ?? '').trim(),
    id,
  );

  rebuildDailyMetrics();
  const updated = db.prepare('SELECT * FROM study_logs WHERE id = ?').get(id) as Record<string, unknown>;
  res.json({ ...updated, isDemo: Boolean(updated.isDemo) });
});

app.delete('/api/study/:id', (req, res) => {
  const id = Number(req.params.id);
  const info = db.prepare('DELETE FROM study_logs WHERE id = ?').run(id);
  if (info.changes === 0) {
    res.status(404).json({ error: 'Study session not found.' });
    return;
  }
  rebuildDailyMetrics();
  res.json({ deleted: true, id });
});

// ---------------- ANALYTICS ROUTES ----------------
app.get('/api/analytics/dashboard', (req, res) => {
  const days = Number(req.query.days) || 21;
  res.json(getDashboardAnalytics(days));
});

app.get('/api/analytics/correlation', (req, res) => {
  const days = Number(req.query.days) || 21;
  const analytics = getDashboardAnalytics(days);
  res.json(analytics.correlation);
});

app.get('/api/analytics/sleep-debt', (req, res) => {
  const days = Number(req.query.days) || 21;
  const analytics = getDashboardAnalytics(days);
  res.json(analytics.sleepDebt);
});

app.get('/api/analytics/weekly-insights', (req, res) => {
  const days = Number(req.query.days) || 21;
  const analytics = getDashboardAnalytics(days);
  res.json(analytics.insights);
});

// ---------------- CAFFEINE ROUTES ----------------
app.get('/api/caffeine', (_req, res) => {
  const rows = db
    .prepare('SELECT * FROM caffeine_logs ORDER BY date DESC, consumptionTime DESC, id DESC')
    .all() as Array<Record<string, unknown>>;
  res.json(rows.map((r) => ({ ...r, isDemo: Boolean(r.isDemo) })));
});

app.post('/api/caffeine', (req, res) => {
  const { date, beverageType, consumptionTime, caffeineAmount, notes = '' } = req.body ?? {};
  if (!isValidDateStr(date)) {
    res.status(400).json({ error: 'Valid date (YYYY-MM-DD) is required.' });
    return;
  }
  if (!['Coffee', 'Tea', 'Other'].includes(beverageType)) {
    res.status(400).json({ error: 'Beverage type must be Coffee, Tea, or Other.' });
    return;
  }
  if (!isValidTimeStr(consumptionTime)) {
    res.status(400).json({ error: 'Valid consumption time (HH:mm) is required.' });
    return;
  }
  const mg = Number(caffeineAmount);
  if (Number.isNaN(mg) || mg <= 0 || mg > 1000) {
    res.status(400).json({ error: 'Caffeine amount must be between 1 and 1000 mg.' });
    return;
  }

  const nowIso = new Date().toISOString();
  const result = db
    .prepare(
      `INSERT INTO caffeine_logs (date, beverageType, consumptionTime, caffeineAmount, notes, isDemo, createdAt)
       VALUES (?, ?, ?, ?, ?, 0, ?)`,
    )
    .run(date, beverageType, consumptionTime, Math.round(mg), String(notes ?? '').trim(), nowIso);

  const created = db.prepare('SELECT * FROM caffeine_logs WHERE id = ?').get(result.lastInsertRowid) as Record<
    string,
    unknown
  >;
  res.status(201).json({ ...created, isDemo: Boolean(created.isDemo) });
});

app.delete('/api/caffeine/:id', (req, res) => {
  const id = Number(req.params.id);
  const info = db.prepare('DELETE FROM caffeine_logs WHERE id = ?').run(id);
  if (info.changes === 0) {
    res.status(404).json({ error: 'Caffeine log not found.' });
    return;
  }
  res.json({ deleted: true, id });
});

// ---------------- EXAMS & PROTECTIVE TIMETABLE ROUTES ----------------
app.get('/api/exams', (_req, res) => {
  const exams = db.prepare('SELECT * FROM exam_schedules ORDER BY examDate ASC, id ASC').all();
  res.json(exams);
});

app.post('/api/exams', (req, res) => {
  const { examDate, subject, topics, priority, estimatedHours = 5 } = req.body ?? {};
  if (!isValidDateStr(examDate)) {
    res.status(400).json({ error: 'Valid exam date (YYYY-MM-DD) is required.' });
    return;
  }
  if (typeof subject !== 'string' || subject.trim().length === 0) {
    res.status(400).json({ error: 'Subject name is required.' });
    return;
  }
  if (!['High', 'Medium', 'Low'].includes(priority)) {
    res.status(400).json({ error: 'Priority must be High, Medium, or Low.' });
    return;
  }
  const est = Math.max(1, Math.min(40, Number(estimatedHours) || 5));
  const nowIso = new Date().toISOString();

  const result = db
    .prepare(
      `INSERT INTO exam_schedules (examDate, subject, topics, priority, estimatedHours, createdAt)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(examDate, subject.trim(), String(topics ?? '').trim(), priority, est, nowIso);

  const created = db.prepare('SELECT * FROM exam_schedules WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(created);
});

app.put('/api/exams/:id', (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM exam_schedules WHERE id = ?').get(id);
  if (!existing) {
    res.status(404).json({ error: 'Exam record not found.' });
    return;
  }
  const { examDate, subject, topics, priority, estimatedHours = 5 } = req.body ?? {};
  if (!isValidDateStr(examDate) || typeof subject !== 'string' || !subject.trim()) {
    res.status(400).json({ error: 'Valid exam date and subject are required.' });
    return;
  }
  if (!['High', 'Medium', 'Low'].includes(priority)) {
    res.status(400).json({ error: 'Invalid priority.' });
    return;
  }
  const est = Math.max(1, Math.min(40, Number(estimatedHours) || 5));

  db.prepare(
    `UPDATE exam_schedules
     SET examDate = ?, subject = ?, topics = ?, priority = ?, estimatedHours = ?
     WHERE id = ?`,
  ).run(examDate, subject.trim(), String(topics ?? '').trim(), priority, est, id);

  res.json(db.prepare('SELECT * FROM exam_schedules WHERE id = ?').get(id));
});

app.delete('/api/exams/:id', (req, res) => {
  const id = Number(req.params.id);
  const info = db.prepare('DELETE FROM exam_schedules WHERE id = ?').run(id);
  if (info.changes === 0) {
    res.status(404).json({ error: 'Exam not found.' });
    return;
  }
  res.json({ deleted: true, id });
});

app.get('/api/exams/plan', (_req, res) => {
  const rows = db
    .prepare('SELECT * FROM exam_plan_tasks ORDER BY date ASC, id ASC')
    .all() as Array<Omit<ExamPlanTask, 'completed'> & { completed: number }>;
  res.json(rows.map((r) => ({ ...r, completed: Boolean(r.completed) })));
});

app.post('/api/exams/generate', (req, res) => {
  const { dailyAvailableHours, preferredWakeTime } = req.body ?? {};
  const settings = getUserSettings();
  const safeHours = Math.max(1, Math.min(8, Number(dailyAvailableHours) || settings.dailyAvailableHours));
  const wakeTime = isValidTimeStr(preferredWakeTime) ? preferredWakeTime : settings.preferredWakeTime;

  db.prepare('UPDATE user_settings SET dailyAvailableHours = ?, preferredWakeTime = ? WHERE id = 1').run(
    safeHours,
    wakeTime,
  );

  const exams = db.prepare('SELECT * FROM exam_schedules ORDER BY examDate ASC').all() as ExamSchedule[];
  const generated = generateProtectiveExamTimetable(exams, safeHours, wakeTime, getLocalDateStr(0));

  db.transaction(() => {
    db.prepare('DELETE FROM exam_plan_tasks').run();
    const insertTask = db.prepare(
      `INSERT INTO exam_plan_tasks (date, startTime, endTime, title, subject, type, completed)
       VALUES (?, ?, ?, ?, ?, ?, 0)`,
    );
    for (const t of generated.tasks) {
      insertTask.run(t.date, t.startTime, t.endTime, t.title, t.subject, t.type);
    }
  })();

  const savedRows = db
    .prepare('SELECT * FROM exam_plan_tasks ORDER BY date ASC, id ASC')
    .all() as Array<Omit<ExamPlanTask, 'completed'> & { completed: number }>;

  res.json({
    ...generated,
    tasks: savedRows.map((r) => ({ ...r, completed: Boolean(r.completed) })),
  });
});

app.put('/api/exams/plan/:id', (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM exam_plan_tasks WHERE id = ?').get(id) as
    | (Omit<ExamPlanTask, 'completed'> & { completed: number })
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Timetable task not found.' });
    return;
  }

  const {
    completed = Boolean(existing.completed),
    title = existing.title,
    startTime = existing.startTime,
    endTime = existing.endTime,
  } = req.body ?? {};

  db.prepare(
    `UPDATE exam_plan_tasks SET completed = ?, title = ?, startTime = ?, endTime = ? WHERE id = ?`,
  ).run(completed ? 1 : 0, String(title), String(startTime), String(endTime), id);

  const updated = db.prepare('SELECT * FROM exam_plan_tasks WHERE id = ?').get(id) as Omit<
    ExamPlanTask,
    'completed'
  > & { completed: number };
  res.json({ ...updated, completed: Boolean(updated.completed) });
});

// ---------------- SETTINGS & DEMO DATA MANAGEMENT ----------------
app.get('/api/settings', (_req, res) => {
  res.json(getUserSettings());
});

app.put('/api/settings', (req, res) => {
  const cur = getUserSettings();
  const {
    studentName = cur.studentName,
    sleepBaselineHours = cur.sleepBaselineHours,
    caffeineHalfLifeHours = cur.caffeineHalfLifeHours,
    preferredWakeTime = cur.preferredWakeTime,
    dailyAvailableHours = cur.dailyAvailableHours,
    onboardingDismissed = cur.onboardingDismissed,
  } = req.body ?? {};

  const safeBaseline = Math.max(5, Math.min(11, Number(sleepBaselineHours) || 8));
  const safeHalfLife = Math.max(2, Math.min(12, Number(caffeineHalfLifeHours) || 5));
  const safeDailyHours = Math.max(1, Math.min(8, Number(dailyAvailableHours) || 7));
  const safeWake = isValidTimeStr(preferredWakeTime) ? preferredWakeTime : cur.preferredWakeTime;

  db.prepare(
    `UPDATE user_settings
     SET studentName = ?, sleepBaselineHours = ?, caffeineHalfLifeHours = ?, preferredWakeTime = ?, dailyAvailableHours = ?, onboardingDismissed = ?
     WHERE id = 1`,
  ).run(
    String(studentName).trim() || 'Student',
    safeBaseline,
    safeHalfLife,
    safeWake,
    safeDailyHours,
    onboardingDismissed ? 1 : 0,
  );

  rebuildDailyMetrics();
  res.json(getUserSettings());
});

app.post('/api/demo/clear', (_req, res) => {
  clearDemoData();
  res.json({ cleared: true });
});

app.post('/api/demo/reset', (_req, res) => {
  resetDemoData();
  res.json({ reset: true });
});

// ---------------- SERVER STARTUP ----------------
async function startServer() {
  const port = Number(process.env.PORT) || 3000;
  const distDir = path.resolve(process.cwd(), 'dist');

  if (process.env.NODE_ENV === 'production' && fs.existsSync(distDir)) {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`DreamLog – SnoozeScience server running at http://0.0.0.0:${port}`);
  });
}

startServer();

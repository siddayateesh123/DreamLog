import type {
  CaffeineLog,
  CorrelationAnalysis,
  DashboardAnalytics,
  ExamPlanTask,
  ExamSchedule,
  SleepDebtSummary,
  SleepLog,
  StudyLog,
  UserSettings,
  WeeklyInsights,
} from '../shared/types.ts';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  getDashboard: (days = 21) => request<DashboardAnalytics>(`/api/analytics/dashboard?days=${days}`),
  getCorrelation: (days = 21) => request<CorrelationAnalysis>(`/api/analytics/correlation?days=${days}`),
  getSleepDebt: (days = 21) => request<SleepDebtSummary>(`/api/analytics/sleep-debt?days=${days}`),
  getWeeklyInsights: (days = 21) => request<WeeklyInsights>(`/api/analytics/weekly-insights?days=${days}`),

  getSleepLogs: () => request<SleepLog[]>('/api/sleep'),
  createSleepLog: (payload: {
    date: string;
    bedtime: string;
    wakeTime: string;
    sleepQuality: number;
    notes?: string;
  }) => request<SleepLog>('/api/sleep', { method: 'POST', body: JSON.stringify(payload) }),
  updateSleepLog: (
    id: number,
    payload: {
      date: string;
      bedtime: string;
      wakeTime: string;
      sleepQuality: number;
      notes?: string;
    },
  ) => request<SleepLog>(`/api/sleep/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteSleepLog: (id: number) => request<{ deleted: boolean }>(`/api/sleep/${id}`, { method: 'DELETE' }),

  getStudyLogs: () => request<StudyLog[]>('/api/study'),
  createStudyLog: (payload: {
    date: string;
    subject: string;
    studyHours: number;
    focusRating: number;
    startTime?: string;
    endTime?: string;
    notes?: string;
  }) => request<StudyLog>('/api/study', { method: 'POST', body: JSON.stringify(payload) }),
  updateStudyLog: (
    id: number,
    payload: {
      date: string;
      subject: string;
      studyHours: number;
      focusRating: number;
      startTime?: string;
      endTime?: string;
      notes?: string;
    },
  ) => request<StudyLog>(`/api/study/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteStudyLog: (id: number) => request<{ deleted: boolean }>(`/api/study/${id}`, { method: 'DELETE' }),

  getCaffeineLogs: () => request<CaffeineLog[]>('/api/caffeine'),
  createCaffeineLog: (payload: {
    date: string;
    beverageType: 'Coffee' | 'Tea' | 'Other';
    consumptionTime: string;
    caffeineAmount: number;
    notes?: string;
  }) => request<CaffeineLog>('/api/caffeine', { method: 'POST', body: JSON.stringify(payload) }),
  deleteCaffeineLog: (id: number) =>
    request<{ deleted: boolean }>(`/api/caffeine/${id}`, { method: 'DELETE' }),

  getExams: () => request<ExamSchedule[]>('/api/exams'),
  createExam: (payload: {
    examDate: string;
    subject: string;
    topics: string;
    priority: 'High' | 'Medium' | 'Low';
    estimatedHours: number;
  }) => request<ExamSchedule>('/api/exams', { method: 'POST', body: JSON.stringify(payload) }),
  updateExam: (
    id: number,
    payload: {
      examDate: string;
      subject: string;
      topics: string;
      priority: 'High' | 'Medium' | 'Low';
      estimatedHours: number;
    },
  ) => request<ExamSchedule>(`/api/exams/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteExam: (id: number) => request<{ deleted: boolean }>(`/api/exams/${id}`, { method: 'DELETE' }),

  getExamPlan: () => request<ExamPlanTask[]>('/api/exams/plan'),
  generateExamPlan: (payload: { dailyAvailableHours: number; preferredWakeTime: string }) =>
    request<{
      tasks: ExamPlanTask[];
      capacityWarning: string | null;
      totalRequestedHours: number;
      totalScheduledHours: number;
      unscheduledHours: number;
      daysPlanned: number;
    }>('/api/exams/generate', { method: 'POST', body: JSON.stringify(payload) }),
  updateExamPlanTask: (
    id: number,
    payload: Partial<Pick<ExamPlanTask, 'completed' | 'title' | 'startTime' | 'endTime'>>,
  ) => request<ExamPlanTask>(`/api/exams/plan/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),

  getSettings: () => request<UserSettings>('/api/settings'),
  updateSettings: (payload: Partial<UserSettings>) =>
    request<UserSettings>('/api/settings', { method: 'PUT', body: JSON.stringify(payload) }),

  clearDemoData: () => request<{ cleared: boolean }>('/api/demo/clear', { method: 'POST' }),
  resetDemoData: () => request<{ reset: boolean }>('/api/demo/reset', { method: 'POST' }),
};

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlarmClock,
  BatteryCharging,
  Bell,
  BookOpen,
  Calendar,
  Coffee,
  Database,
  FileText,
  Home,
  LayoutDashboard,
  Menu,
  Moon,
  Settings,
  TrendingUp,
  X,
} from 'lucide-react';
import { api } from './api/client.ts';
import { AnalyticsView } from './components/AnalyticsView.tsx';
import { BedtimeView } from './components/BedtimeView.tsx';
import { CaffeineView } from './components/CaffeineView.tsx';
import { DashboardView, type NavSection } from './components/DashboardView.tsx';
import { ExamPlannerView } from './components/ExamPlannerView.tsx';
import { LandingPage } from './components/LandingPage.tsx';
import { QuickLogModal } from './components/QuickLogModal.tsx';
import { ReportsView } from './components/ReportsView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { SleepDebtView } from './components/SleepDebtView.tsx';
import { SleepTrackerView } from './components/SleepTrackerView.tsx';
import { StudyTrackerView } from './components/StudyTrackerView.tsx';
import { ConfirmModal, ToastList, type ToastItem } from './components/ui.tsx';
import type {
  CaffeineLog,
  DashboardAnalytics,
  ExamPlanTask,
  ExamSchedule,
  SleepLog,
  StudyLog,
  UserSettings,
} from './shared/types.ts';

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'sleep', label: 'Sleep Tracker', icon: Moon },
  { id: 'study', label: 'Study Tracker', icon: BookOpen },
  { id: 'analytics', label: 'Analytics', icon: TrendingUp },
  { id: 'sleep-debt', label: 'Sleep Debt', icon: BatteryCharging },
  { id: 'bedtime', label: 'Bedtime Recommender', icon: AlarmClock },
  { id: 'caffeine', label: 'Caffeine Tracker', icon: Coffee },
  { id: 'exams', label: 'Exam Planner', icon: Calendar },
  { id: 'reports', label: 'Wellness Reports', icon: FileText },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export default function App() {
  const [showLanding, setShowLanding] = useState(true);
  const [activeTab, setActiveTab] = useState<NavSection>('dashboard');
  const [daysWindow, setDaysWindow] = useState<number>(21);

  const [analytics, setAnalytics] = useState<DashboardAnalytics | null>(null);
  const [sleepLogs, setSleepLogs] = useState<SleepLog[]>([]);
  const [studyLogs, setStudyLogs] = useState<StudyLog[]>([]);
  const [caffeineLogs, setCaffeineLogs] = useState<CaffeineLog[]>([]);
  const [exams, setExams] = useState<ExamSchedule[]>([]);
  const [examPlanTasks, setExamPlanTasks] = useState<ExamPlanTask[]>([]);
  const [settings, setSettings] = useState<UserSettings>({
    studentName: 'Maya Lin',
    sleepBaselineHours: 8,
    caffeineHalfLifeHours: 5,
    preferredWakeTime: '07:30',
    dailyAvailableHours: 7,
    onboardingDismissed: false,
    demoCleared: false,
  });

  const [loading, setLoading] = useState(true);
  const [quickModalMode, setQuickModalMode] = useState<'sleep' | 'study' | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [confirmClearDemo, setConfirmClearDemo] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const notify = useCallback((type: 'success' | 'error' | 'info', message: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const loadAllData = useCallback(
    async (windowDays = daysWindow) => {
      try {
        const [dashData, sleeps, studies, caffeines, examList, planList, userCfg] =
          await Promise.all([
            api.getDashboard(windowDays),
            api.getSleepLogs(),
            api.getStudyLogs(),
            api.getCaffeineLogs(),
            api.getExams(),
            api.getExamPlan(),
            api.getSettings(),
          ]);
        setAnalytics(dashData);
        setSleepLogs(sleeps);
        setStudyLogs(studies);
        setCaffeineLogs(caffeines);
        setExams(examList);
        setExamPlanTasks(planList);
        setSettings(userCfg);
      } catch (err) {
        notify('error', err instanceof Error ? err.message : 'Failed to load DreamLog data.');
      } finally {
        setLoading(false);
      }
    },
    [daysWindow, notify],
  );

  useEffect(() => {
    loadAllData(daysWindow);
  }, [daysWindow, loadAllData]);

  const handleChangeDaysWindow = (days: number) => {
    setDaysWindow(days);
  };

  const handleDismissOnboarding = async () => {
    try {
      const updated = await api.updateSettings({ onboardingDismissed: true });
      setSettings(updated);
    } catch {
      setSettings((s) => ({ ...s, onboardingDismissed: true }));
    }
  };

  const handleClearDemoData = async () => {
    try {
      await api.clearDemoData();
      setConfirmClearDemo(false);
      notify('info', 'Sample demo dataset removed. Start recording your own sleep and study logs.');
      await loadAllData(daysWindow);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to clear demo data.');
    }
  };

  const notifications = useMemo(() => {
    const list: Array<{ id: string; title: string; detail: string; target: NavSection }> = [];
    if (analytics?.hasDemoData) {
      list.push({
        id: 'demo',
        title: '21-Day Demo Dataset Active',
        detail: `${analytics.demoCount} sample entries loaded. You can explore or delete them anytime.`,
        target: 'settings',
      });
    }
    if (analytics && !analytics.correlation.hasConfidence) {
      list.push({
        id: 'corr',
        title: 'Correlation Confidence Threshold',
        detail: `${analytics.correlation.observationCount}/7 paired sleep-study days logged.`,
        target: 'analytics',
      });
    }
    if (analytics && analytics.weeklySleepDebt >= 4) {
      list.push({
        id: 'debt',
        title: `Weekly Sleep Debt: ${analytics.weeklySleepDebt.toFixed(1)}h`,
        detail: 'Consider moving bedtime 30 minutes earlier to recover toward your baseline.',
        target: 'sleep-debt',
      });
    }
    if (exams.length > 0) {
      list.push({
        id: 'exam',
        title: `${exams.length} Upcoming Exam${exams.length === 1 ? '' : 's'} Tracked`,
        detail: `Next: ${exams[0].subject} on ${exams[0].examDate}`,
        target: 'exams',
      });
    }
    return list;
  }, [analytics, exams]);

  if (showLanding) {
    return (
      <>
        <LandingPage
          onGetStarted={() => {
            setShowLanding(false);
            setActiveTab('dashboard');
          }}
          onExploreDashboard={() => {
            setShowLanding(false);
            setActiveTab('dashboard');
          }}
        />
        <ToastList toasts={toasts} onDismiss={(id) => setToasts((p) => p.filter((t) => t.id !== id))} />
      </>
    );
  }

  const activeNavMeta = NAV_ITEMS.find((n) => n.id === activeTab) || NAV_ITEMS[0];

  return (
    <div className="min-h-screen bg-[#0F172A] text-[#F8FAFC] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-[#111827] border-r border-slate-800/90 z-30">
        <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800/90">
          <button
            type="button"
            onClick={() => setShowLanding(true)}
            className="flex items-center gap-2.5 text-left group"
          >
            <Moon className="w-5 h-5 text-[#60A5FA]" />
            <span className="font-display font-bold text-base tracking-tight text-[#F8FAFC] group-hover:text-[#60A5FA] transition-colors">
              DreamLog
            </span>
          </button>
          <button
            type="button"
            onClick={() => setShowLanding(true)}
            className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-slate-800"
            title="Return to Welcome Page"
            aria-label="Return to Welcome Page"
          >
            <Home className="w-4 h-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1" aria-label="Workspace Navigation">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left ${
                  isActive
                    ? 'bg-[#60A5FA]/15 text-[#60A5FA] border border-[#60A5FA]/30'
                    : 'text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1E293B]/60 border border-transparent'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Student Profile Section */}
        <div className="p-4 border-t border-slate-800/90">
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#1E293B]/70 transition-colors text-left"
          >
            <img
              src="/src/assets/images/student_profile_avatar_1794932871185.jpg"
              alt={settings.studentName}
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-full object-cover border border-slate-700 shrink-0"
            />
            <div className="min-w-0">
              <div className="text-sm font-semibold text-[#F8FAFC] truncate">
                {settings.studentName}
              </div>
              <div className="text-xs text-[#94A3B8] truncate">
                Baseline: {settings.sleepBaselineHours}h · Preferences
              </div>
            </div>
          </button>
        </div>
      </aside>

      {/* Mobile Slide-Over Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] bg-[#111827] border-r border-slate-800 h-full flex flex-col z-10">
            <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <Moon className="w-5 h-5 text-[#60A5FA]" />
                <span className="font-display font-bold text-base text-[#F8FAFC]">DreamLog</span>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 text-[#94A3B8] hover:text-[#F8FAFC]"
                aria-label="Close navigation menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${
                      isActive
                        ? 'bg-[#60A5FA]/15 text-[#60A5FA]'
                        : 'text-[#94A3B8] hover:text-[#F8FAFC]'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setShowLanding(true);
                }}
                className="w-full py-2 px-3 rounded-lg border border-slate-700 text-xs font-medium text-[#CBD5E1] flex items-center justify-center gap-2"
              >
                <Home className="w-4 h-4" />
                <span>Welcome Landing Page</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0 pb-20 lg:pb-8">
        {/* Top Workspace Header */}
        <header className="sticky top-0 z-20 h-16 bg-[#0F172A]/90 backdrop-blur-md border-b border-slate-800/90 px-4 sm:px-6 flex items-center justify-between gap-4 print:hidden">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-slate-800"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <div className="text-xs text-[#94A3B8] hidden sm:block">
                DreamLog – SnoozeScience / {activeNavMeta.label}
              </div>
              <h1 className="font-display text-base sm:text-lg font-bold text-[#F8FAFC] truncate">
                {activeNavMeta.label}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setQuickModalMode('sleep')}
              className="hidden sm:inline-flex px-3 py-1.5 rounded-lg border border-slate-700 bg-[#1E293B] text-xs font-medium text-[#F8FAFC] hover:border-[#60A5FA]/60 transition-colors whitespace-nowrap"
            >
              + Sleep
            </button>
            <button
              type="button"
              onClick={() => setQuickModalMode('study')}
              className="hidden sm:inline-flex px-3 py-1.5 rounded-lg bg-[#60A5FA] text-xs font-semibold text-[#0F172A] hover:bg-[#93C5FD] transition-colors whitespace-nowrap"
            >
              + Study
            </button>

            {/* Notification Area */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setNotificationsOpen((v) => !v)}
                className="relative p-2 rounded-lg border border-slate-800 bg-[#1E293B] text-[#94A3B8] hover:text-[#F8FAFC] transition-colors"
                aria-label="Notifications"
              >
                <Bell className="w-4 h-4" />
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#FBBF24] text-[#0F172A] text-[10px] font-mono font-bold flex items-center justify-center">
                    {notifications.length}
                  </span>
                )}
              </button>

              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 rounded-xl border border-slate-700 bg-[#1E293B] shadow-2xl p-4 z-40">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-[#F8FAFC]">
                      Workspace Notifications
                    </span>
                    <button
                      type="button"
                      onClick={() => setNotificationsOpen(false)}
                      className="text-xs text-[#94A3B8] hover:text-[#F8FAFC]"
                    >
                      Close
                    </button>
                  </div>
                  {notifications.length === 0 ? (
                    <p className="text-xs text-[#94A3B8]">All metrics look balanced.</p>
                  ) : (
                    <div className="divide-y divide-slate-800">
                      {notifications.map((n) => (
                        <button
                          key={n.id}
                          type="button"
                          onClick={() => {
                            setActiveTab(n.target);
                            setNotificationsOpen(false);
                          }}
                          className="w-full py-2.5 text-left hover:bg-slate-800/40 rounded px-1.5 transition-colors"
                        >
                          <div className="text-xs font-semibold text-[#F8FAFC]">{n.title}</div>
                          <div className="text-[11px] text-[#94A3B8] mt-0.5">{n.detail}</div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </header>

        {/* DEMO DATA Notice Banner */}
        {analytics?.hasDemoData && (
          <div className="mx-4 sm:mx-6 mt-5 rounded-xl border border-[#FBBF24]/30 bg-[#FBBF24]/10 px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 print:hidden">
            <div className="flex items-center gap-2.5 text-xs text-[#FDE68A]">
              <Database className="w-4 h-4 text-[#FBBF24] shrink-0" />
              <span>
                <strong>DEMO DATA</strong> active ({analytics.demoCount} seeded records over 21 days). Add your own logs to see live recalculation, or clear demo records anytime.
              </span>
            </div>
            <button
              type="button"
              onClick={() => setConfirmClearDemo(true)}
              className="px-3 py-1.5 rounded-lg bg-[#1E293B] border border-slate-700 text-xs font-medium text-[#F8FAFC] hover:border-[#F87171] transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
            >
              Clear Demo Data
            </button>
          </div>
        )}

        {/* Active Module Viewport */}
        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              analytics={analytics}
              settings={settings}
              loading={loading}
              daysWindow={daysWindow}
              onChangeDaysWindow={handleChangeDaysWindow}
              onNavigate={setActiveTab}
              onDismissOnboarding={handleDismissOnboarding}
              onOpenQuickSleep={() => setQuickModalMode('sleep')}
              onOpenQuickStudy={() => setQuickModalMode('study')}
            />
          )}

          {activeTab === 'sleep' && (
            <SleepTrackerView
              logs={sleepLogs}
              onDataChanged={() => loadAllData(daysWindow)}
              onNotify={notify}
            />
          )}

          {activeTab === 'study' && (
            <StudyTrackerView
              logs={studyLogs}
              subjectStats={analytics?.subjectStats ?? []}
              onDataChanged={() => loadAllData(daysWindow)}
              onNotify={notify}
            />
          )}

          {activeTab === 'analytics' && analytics && (
            <AnalyticsView
              analytics={analytics}
              daysWindow={daysWindow}
              onChangeDaysWindow={handleChangeDaysWindow}
            />
          )}

          {activeTab === 'sleep-debt' && analytics && (
            <SleepDebtView
              sleepDebt={analytics.sleepDebt}
              onNavigateSleep={() => setActiveTab('sleep')}
            />
          )}

          {activeTab === 'bedtime' && (
            <BedtimeView defaultWakeTime={settings.preferredWakeTime} />
          )}

          {activeTab === 'caffeine' && (
            <CaffeineView
              logs={caffeineLogs}
              dailySeries={analytics?.dailySeries ?? []}
              halfLifeHours={settings.caffeineHalfLifeHours}
              onDataChanged={() => loadAllData(daysWindow)}
              onNotify={notify}
            />
          )}

          {activeTab === 'exams' && (
            <ExamPlannerView
              exams={exams}
              tasks={examPlanTasks}
              settings={settings}
              onDataChanged={() => loadAllData(daysWindow)}
              onNotify={notify}
            />
          )}

          {activeTab === 'reports' && analytics && (
            <ReportsView
              analytics={analytics}
              settings={settings}
              daysWindow={daysWindow}
              onChangeDaysWindow={handleChangeDaysWindow}
              onNotify={notify}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              settings={settings}
              hasDemoData={analytics?.hasDemoData ?? false}
              demoCount={analytics?.demoCount ?? 0}
              onDataChanged={() => loadAllData(daysWindow)}
              onNotify={notify}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation (Compact <= 15% viewport height) */}
      <nav
        className="lg:hidden fixed bottom-0 inset-x-0 z-30 h-16 bg-[#111827]/95 backdrop-blur-md border-t border-slate-800 grid grid-cols-5 px-1 print:hidden"
        aria-label="Mobile Navigation"
      >
        {(
          [
            { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
            { id: 'sleep', label: 'Sleep', icon: Moon },
            { id: 'study', label: 'Study', icon: BookOpen },
            { id: 'analytics', label: 'Stats', icon: TrendingUp },
          ] as const
        ).map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center gap-1 text-[11px] font-medium ${
                active ? 'text-[#60A5FA]' : 'text-[#94A3B8]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setMobileMenuOpen(true)}
          className="flex flex-col items-center justify-center gap-1 text-[11px] font-medium text-[#94A3B8]"
        >
          <Menu className="w-4 h-4" />
          <span>More</span>
        </button>
      </nav>

      {/* Quick Log Modal */}
      <QuickLogModal
        mode={quickModalMode}
        onClose={() => setQuickModalMode(null)}
        onSaved={() => loadAllData(daysWindow)}
        onNotify={notify}
      />

      {/* Demo Data Clear Confirmation */}
      <ConfirmModal
        open={confirmClearDemo}
        title="Clear 21-Day Demo Dataset"
        message="This deletes all DEMO DATA entries while preserving any personal records you created. You can restore the sample dataset anytime in Settings."
        confirmLabel="Clear Demo Data"
        variant="danger"
        onConfirm={handleClearDemoData}
        onCancel={() => setConfirmClearDemo(false)}
      />

      {/* Toast Notifications */}
      <ToastList toasts={toasts} onDismiss={(id) => setToasts((p) => p.filter((t) => t.id !== id))} />
    </div>
  );
}

import type {
  CorrelationAnalysis,
  DailyMetricPoint,
  ExamPlanTask,
  ExamSchedule,
} from './types.ts';

export function getLocalDateStr(offsetDays = 0): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function addDaysToDateStr(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

export function parseTimeToMinutes(timeStr: string): number {
  const parts = timeStr.split(':');
  if (parts.length !== 2) return NaN;
  const h = Number(parts[0]);
  const m = Number(parts[1]);
  if (!Number.isInteger(h) || !Number.isInteger(m) || h < 0 || h > 23 || m < 0 || m > 59) {
    return NaN;
  }
  return h * 60 + m;
}

export function minutesToTimeStr(totalMinutes: number): string {
  const normalized = ((Math.round(totalMinutes) % 1440) + 1440) % 1440;
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Calculates sleep duration in decimal hours between bedtime and wakeTime (HH:mm).
 * If wakeTime is numerically earlier than or equal to bedtime, treats wakeTime as the following day.
 */
export function calculateSleepDuration(bedtime: string, wakeTime: string): number {
  const bedMin = parseTimeToMinutes(bedtime);
  const wakeMin = parseTimeToMinutes(wakeTime);
  if (Number.isNaN(bedMin) || Number.isNaN(wakeMin)) return 0;
  if (bedMin === wakeMin) return 0;

  let diff = wakeMin - bedMin;
  if (diff < 0) {
    diff += 24 * 60;
  }
  return Math.round((diff / 60) * 100) / 100;
}

export function calculateTimeRangeHours(startTime: string, endTime: string): number {
  const startMin = parseTimeToMinutes(startTime);
  const endMin = parseTimeToMinutes(endTime);
  if (Number.isNaN(startMin) || Number.isNaN(endMin) || startMin === endMin) return 0;
  let diff = endMin - startMin;
  if (diff < 0) diff += 24 * 60;
  return Math.round((diff / 60) * 100) / 100;
}

export function formatHoursMinutes(decimalHours: number | null | undefined): string {
  if (decimalHours === null || decimalHours === undefined || Number.isNaN(decimalHours)) {
    return '—';
  }
  const totalMinutes = Math.round(decimalHours * 60);
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${h}h ${m}m`;
}

export function formatTime12h(time24: string | null | undefined): string {
  if (!time24) return '—';
  const min = parseTimeToMinutes(time24);
  if (Number.isNaN(min)) return time24;
  const h24 = Math.floor(min / 60);
  const m = min % 60;
  const suffix = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${String(m).padStart(2, '0')} ${suffix}`;
}

export function formatShortDate(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return dateStr;
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function getWeekdayName(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return '';
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString('en-US', { weekday: 'long' });
}

export function interpretPearsonR(r: number): { category: string; explanation: string } {
  if (Math.abs(r) < 0.005) {
    return {
      category: 'No Linear Correlation',
      explanation: 'No measurable linear relationship appears between sleep duration and focus rating in this window.',
    };
  }
  if (r >= 0.7) {
    return {
      category: 'Strong Positive Correlation',
      explanation: 'Longer sleep durations are strongly associated with higher study focus ratings across your logged days.',
    };
  }
  if (r >= 0.3) {
    return {
      category: 'Moderate Positive Correlation',
      explanation: 'Nights with longer sleep show a meaningful tendency toward stronger study focus the next day.',
    };
  }
  if (r > 0) {
    return {
      category: 'Weak Positive Correlation',
      explanation: 'Longer sleep shows a slight positive link with focus ratings, though other factors also play a role.',
    };
  }
  if (r <= -0.7) {
    return {
      category: 'Strong Negative Correlation',
      explanation: 'In this window, longer recorded sleep durations coincided with lower focus ratings.',
    };
  }
  if (r <= -0.3) {
    return {
      category: 'Moderate Negative Correlation',
      explanation: 'Recorded focus ratings tended to dip slightly on days with longer logged sleep in this window.',
    };
  }
  return {
    category: 'Weak Negative Correlation',
    explanation: 'A slight negative linear drift appears in this sample, likely reflecting small sample noise or timing shifts.',
  };
}

export function computeCorrelationAnalysis(
  dailyPoints: DailyMetricPoint[],
  latestEntryDate: string | null = null,
): CorrelationAnalysis {
  const paired = dailyPoints.filter(
    (d) => d.totalSleep > 0 && d.averageFocus !== null && d.studySessionsCount > 0,
  );
  const n = paired.length;
  const requiredCount = 7;

  const points = paired.map((d) => ({
    date: d.date,
    x: Math.round(d.totalSleep * 100) / 100,
    y: Math.round((d.averageFocus as number) * 100) / 100,
    studyHours: Math.round(d.totalStudyHours * 100) / 100,
    subjects: d.subjects,
    isDemo: d.isDemo,
    isLatest: latestEntryDate !== null && d.date === latestEntryDate,
  }));

  if (n === 0) {
    return {
      r: null,
      category: 'Insufficient Data',
      explanation: 'Log both nightly sleep and study sessions on the same dates to begin correlation analysis.',
      observationCount: 0,
      requiredCount,
      hasConfidence: false,
      zeroVariance: false,
      confidenceWarning: 'Needs at least 7 days of logs for statistical confidence.',
      meanSleep: null,
      meanFocus: null,
      ols: null,
      points: [],
    };
  }

  const meanX = paired.reduce((acc, d) => acc + d.totalSleep, 0) / n;
  const meanY = paired.reduce((acc, d) => acc + (d.averageFocus as number), 0) / n;

  if (n < requiredCount) {
    return {
      r: null,
      category: 'Insufficient Observations',
      explanation: `You currently have ${n} paired day${n === 1 ? '' : 's'} logged. Add ${requiredCount - n} more paired day${requiredCount - n === 1 ? '' : 's'} to unlock reliable trend calculations.`,
      observationCount: n,
      requiredCount,
      hasConfidence: false,
      zeroVariance: false,
      confidenceWarning: 'Needs at least 7 days of logs for statistical confidence.',
      meanSleep: Math.round(meanX * 100) / 100,
      meanFocus: Math.round(meanY * 100) / 100,
      ols: null,
      points,
    };
  }

  let sumDX2 = 0;
  let sumDY2 = 0;
  let sumDXDY = 0;

  for (const d of paired) {
    const dx = d.totalSleep - meanX;
    const dy = (d.averageFocus as number) - meanY;
    sumDX2 += dx * dx;
    sumDY2 += dy * dy;
    sumDXDY += dx * dy;
  }

  if (sumDX2 < 1e-9 || sumDY2 < 1e-9) {
    return {
      r: null,
      category: 'Undefined (Zero Variance)',
      explanation:
        sumDX2 < 1e-9
          ? 'All logged sleep durations in this range are identical, so a linear slope cannot be calculated.'
          : 'All logged focus ratings in this range are identical, so Pearson correlation is undefined.',
      observationCount: n,
      requiredCount,
      hasConfidence: true,
      zeroVariance: true,
      confidenceWarning: null,
      meanSleep: Math.round(meanX * 100) / 100,
      meanFocus: Math.round(meanY * 100) / 100,
      ols: null,
      points,
    };
  }

  const rawR = sumDXDY / Math.sqrt(sumDX2 * sumDY2);
  const clampedR = Math.max(-1, Math.min(1, rawR));
  const roundedR = Math.round(clampedR * 100) / 100;

  const slope = sumDXDY / sumDX2;
  const intercept = meanY - slope * meanX;
  const minX = Math.min(...points.map((p) => p.x));
  const maxX = Math.max(...points.map((p) => p.x));
  const x1 = Math.max(3, Math.floor((minX - 0.3) * 10) / 10);
  const x2 = Math.min(12, Math.ceil((maxX + 0.3) * 10) / 10);

  const clampY = (val: number) => Math.max(1, Math.min(5, Math.round(val * 100) / 100));
  const sign = intercept >= 0 ? '+' : '-';
  const equation = `y = ${slope.toFixed(2)}x ${sign} ${Math.abs(intercept).toFixed(2)}`;

  const { category, explanation } = interpretPearsonR(roundedR);

  return {
    r: roundedR,
    category,
    explanation,
    observationCount: n,
    requiredCount,
    hasConfidence: true,
    zeroVariance: false,
    confidenceWarning: null,
    meanSleep: Math.round(meanX * 100) / 100,
    meanFocus: Math.round(meanY * 100) / 100,
    ols: {
      slope: Math.round(slope * 1000) / 1000,
      intercept: Math.round(intercept * 1000) / 1000,
      equation,
      linePoints: [
        { x: x1, y: clampY(slope * x1 + intercept) },
        { x: x2, y: clampY(slope * x2 + intercept) },
      ],
    },
    points,
  };
}

export interface BedtimeOption {
  cycles: number;
  sleepHours: number;
  getInBedTime: string;
  fallAsleepTime: string;
  label: string;
  recommended: boolean;
}

export function calculateBedtimeCycles(
  wakeTime: string,
  fallAsleepMinutes: number,
): BedtimeOption[] {
  const wakeMin = parseTimeToMinutes(wakeTime);
  if (Number.isNaN(wakeMin)) return [];
  const latency = Math.max(0, Math.min(120, fallAsleepMinutes));

  const cycleCounts = [6, 5, 4, 3];
  return cycleCounts.map((cycles) => {
    const sleepMinutes = cycles * 90;
    const sleepHours = sleepMinutes / 60;
    const fallAsleepMin = wakeMin - sleepMinutes;
    const getInBedMin = fallAsleepMin - latency;

    let label = 'Minimum Recovery';
    if (cycles === 6) label = 'Optimal Full Rest (9h)';
    else if (cycles === 5) label = 'Balanced Target (7.5h)';
    else if (cycles === 4) label = 'Short Night (6h)';

    return {
      cycles,
      sleepHours,
      getInBedTime: minutesToTimeStr(getInBedMin),
      fallAsleepTime: minutesToTimeStr(fallAsleepMin),
      label,
      recommended: cycles === 5 || cycles === 6,
    };
  });
}

export function calculateRemainingCaffeine(
  initialMg: number,
  elapsedHours: number,
  halfLifeHours = 5,
): number {
  if (elapsedHours < 0 || initialMg <= 0 || halfLifeHours <= 0) return 0;
  return Math.round(initialMg * Math.pow(0.5, elapsedHours / halfLifeHours) * 10) / 10;
}

export function estimateBedtimeCaffeine(
  logs: Array<{ consumptionTime: string; caffeineAmount: number }>,
  targetBedtime: string,
  halfLifeHours = 5,
): number {
  const bedMin = parseTimeToMinutes(targetBedtime);
  if (Number.isNaN(bedMin)) return 0;
  let total = 0;
  for (const log of logs) {
    const cMin = parseTimeToMinutes(log.consumptionTime);
    if (Number.isNaN(cMin)) continue;
    let diffMin = bedMin - cMin;
    if (diffMin < 0) diffMin += 24 * 60;
    // Only count intakes within the 24h window leading up to bedtime
    const elapsedHours = diffMin / 60;
    total += calculateRemainingCaffeine(log.caffeineAmount, elapsedHours, halfLifeHours);
  }
  return Math.round(total * 10) / 10;
}

export interface GeneratedExamPlanResult {
  tasks: Omit<ExamPlanTask, 'id'>[];
  capacityWarning: string | null;
  totalRequestedHours: number;
  totalScheduledHours: number;
  unscheduledHours: number;
  daysPlanned: number;
}

export function generateProtectiveExamTimetable(
  exams: ExamSchedule[],
  dailyAvailableHours: number,
  preferredWakeTime: string,
  startDateStr: string = getLocalDateStr(0),
): GeneratedExamPlanResult {
  if (exams.length === 0) {
    return {
      tasks: [],
      capacityWarning: null,
      totalRequestedHours: 0,
      totalScheduledHours: 0,
      unscheduledHours: 0,
      daysPlanned: 0,
    };
  }

  // Mandatory hard limits: max 8h study/day, min 7h sleep/night
  const maxStudyPerDay = Math.max(1, Math.min(8, dailyAvailableHours));
  const wakeMin = parseTimeToMinutes(preferredWakeTime);
  const safeWakeMin = Number.isNaN(wakeMin) ? 7 * 60 : wakeMin;
  const reservedSleepHours = 7.5; // >= 7 hours mandatory
  const bedtimeMin = safeWakeMin - reservedSleepHours * 60;

  const sortedExams = [...exams]
    .filter((e) => e.examDate >= startDateStr)
    .sort((a, b) => {
      const priorityRank = { High: 0, Medium: 1, Low: 2 };
      if (a.examDate !== b.examDate) return a.examDate.localeCompare(b.examDate);
      return priorityRank[a.priority] - priorityRank[b.priority];
    });

  const activeExams = sortedExams.length > 0 ? sortedExams : [...exams];
  const furthestDate = activeExams.reduce(
    (max, e) => (e.examDate > max ? e.examDate : max),
    startDateStr,
  );

  // Plan between startDateStr and min(furthestDate, startDate + 13 days)
  const dayDates: string[] = [];
  for (let i = 0; i < 14; i++) {
    const dt = addDaysToDateStr(startDateStr, i);
    dayDates.push(dt);
    if (dt >= furthestDate && i >= 6) break;
  }
  if (dayDates.length === 0) dayDates.push(startDateStr);

  // Build weighted topic queue
  const priorityMultiplier = { High: 1.4, Medium: 1.0, Low: 0.75 };
  const subjectPool = activeExams.map((e) => {
    const topics = e.topics
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);
    const requested = Math.max(1, e.estimatedHours || 4);
    return {
      subject: e.subject,
      examDate: e.examDate,
      priority: e.priority,
      topics: topics.length > 0 ? topics : [`${e.subject} Core Review`],
      remainingHours: requested,
      weight: priorityMultiplier[e.priority],
    };
  });

  const totalRequestedHours =
    Math.round(subjectPool.reduce((acc, s) => acc + s.remainingHours, 0) * 10) / 10;

  const tasks: Omit<ExamPlanTask, 'id'>[] = [];
  let totalScheduledHours = 0;

  for (const dayDate of dayDates) {
    // Morning routine & Breakfast
    const breakfastStart = safeWakeMin + 30;
    tasks.push({
      date: dayDate,
      startTime: minutesToTimeStr(breakfastStart),
      endTime: minutesToTimeStr(breakfastStart + 45),
      title: 'Breakfast & Morning Hydration',
      subject: 'Wellness',
      type: 'meal',
      completed: false,
    });

    // Lunch & Dinner fixed anchors
    const lunchStart = safeWakeMin + 5.5 * 60;
    const dinnerStart = safeWakeMin + 11.5 * 60;

    let cursor = breakfastStart + 60; // First study block start
    let dayStudyUsed = 0;
    let topicIdx = 0;

    const eligibleSubjects = subjectPool.filter(
      (s) => s.remainingHours > 0.25 && s.examDate >= dayDate,
    );

    // If all exams already passed or none left, still keep structure clean
    while (dayStudyUsed < maxStudyPerDay - 0.25 && eligibleSubjects.some((s) => s.remainingHours > 0.25)) {
      // Pick highest priority / earliest exam with remaining hours using round-robin weighted rotation
      const available = eligibleSubjects.filter((s) => s.remainingHours > 0.25);
      if (available.length === 0) break;

      const picked = available[topicIdx % available.length];
      topicIdx++;

      const blockHours = Math.min(2, maxStudyPerDay - dayStudyUsed, picked.remainingHours);
      if (blockHours < 0.5) break;

      const blockMins = Math.round(blockHours * 60);

      // Avoid overlapping Lunch
      if (cursor < lunchStart + 45 && cursor + blockMins > lunchStart) {
        tasks.push({
          date: dayDate,
          startTime: minutesToTimeStr(lunchStart),
          endTime: minutesToTimeStr(lunchStart + 45),
          title: 'Lunch Break & Midday Walk',
          subject: 'Wellness',
          type: 'meal',
          completed: false,
        });
        cursor = lunchStart + 60;
      }

      // Avoid overlapping Dinner
      if (cursor < dinnerStart + 45 && cursor + blockMins > dinnerStart) {
        tasks.push({
          date: dayDate,
          startTime: minutesToTimeStr(dinnerStart),
          endTime: minutesToTimeStr(dinnerStart + 45),
          title: 'Dinner & Screen-Free Rest',
          subject: 'Wellness',
          type: 'meal',
          completed: false,
        });
        cursor = dinnerStart + 60;
      }

      // Ensure we stop at least 45 mins before protected sleep wind-down
      const latestEnd = safeWakeMin + (24 - reservedSleepHours - 0.75) * 60;
      if (cursor + blockMins > latestEnd) {
        break;
      }

      const topicLabel = picked.topics[(topicIdx - 1) % picked.topics.length];
      tasks.push({
        date: dayDate,
        startTime: minutesToTimeStr(cursor),
        endTime: minutesToTimeStr(cursor + blockMins),
        title: `${picked.subject}: ${topicLabel}`,
        subject: picked.subject,
        type: 'study',
        completed: false,
      });

      picked.remainingHours = Math.round((picked.remainingHours - blockHours) * 100) / 100;
      dayStudyUsed = Math.round((dayStudyUsed + blockHours) * 100) / 100;
      totalScheduledHours = Math.round((totalScheduledHours + blockHours) * 100) / 100;
      cursor += blockMins;

      // Insert 15-minute recovery break after study block
      if (dayStudyUsed < maxStudyPerDay - 0.25 && cursor + 15 < latestEnd) {
        tasks.push({
          date: dayDate,
          startTime: minutesToTimeStr(cursor),
          endTime: minutesToTimeStr(cursor + 15),
          title: 'Rest & Stretch Break',
          subject: 'Recovery',
          type: 'break',
          completed: false,
        });
        cursor += 15;
      }
    }

    // Ensure Lunch and Dinner appear even on lighter days
    if (!tasks.some((t) => t.date === dayDate && t.title.startsWith('Lunch'))) {
      tasks.push({
        date: dayDate,
        startTime: minutesToTimeStr(lunchStart),
        endTime: minutesToTimeStr(lunchStart + 45),
        title: 'Lunch Break & Midday Walk',
        subject: 'Wellness',
        type: 'meal',
        completed: false,
      });
    }
    if (!tasks.some((t) => t.date === dayDate && t.title.startsWith('Dinner'))) {
      tasks.push({
        date: dayDate,
        startTime: minutesToTimeStr(dinnerStart),
        endTime: minutesToTimeStr(dinnerStart + 45),
        title: 'Dinner & Screen-Free Rest',
        subject: 'Wellness',
        type: 'meal',
        completed: false,
      });
    }

    // Mandatory protected sleep window (>= 7 hours)
    tasks.push({
      date: dayDate,
      startTime: minutesToTimeStr(bedtimeMin),
      endTime: minutesToTimeStr(safeWakeMin),
      title: `Protected Sleep Window (${reservedSleepHours}h reserved)`,
      subject: 'Sleep',
      type: 'sleep',
      completed: false,
    });
  }

  // Sort each day chronologically (keeping bedtime sleep at end of day view)
  tasks.sort((a, b) => {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    if (a.type === 'sleep' && b.type !== 'sleep') return 1;
    if (b.type === 'sleep' && a.type !== 'sleep') return -1;
    return a.startTime.localeCompare(b.startTime);
  });

  const unscheduledHours = Math.max(
    0,
    Math.round((totalRequestedHours - totalScheduledHours) * 10) / 10,
  );
  const capacityWarning =
    unscheduledHours > 0.5
      ? `Safe schedule capacity reached: ${unscheduledHours}h of requested study could not fit before your exam dates without breaking the mandatory 8h/day study cap or 7h/night sleep minimum. Consider prioritizing high-impact topics.`
      : null;

  return {
    tasks,
    capacityWarning,
    totalRequestedHours,
    totalScheduledHours,
    unscheduledHours,
    daysPlanned: dayDates.length,
  };
}

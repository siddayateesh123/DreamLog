import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, Info, Sparkles, TrendingUp } from 'lucide-react';
import { formatShortDate } from '../shared/math.ts';
import type { DashboardAnalytics } from '../shared/types.ts';
import { SleepFocusScatterChart, SleepVsProductivityTrendChart } from './Charts.tsx';

export function AnalyticsView({
  analytics,
  daysWindow,
  onChangeDaysWindow,
}: {
  analytics: DashboardAnalytics;
  daysWindow: number;
  onChangeDaysWindow: (days: number) => void;
}) {
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const { correlation, insights } = analytics;

  const selectedPoint = selectedDate
    ? correlation.points.find((p) => p.date === selectedDate) ?? null
    : correlation.points.find((p) => p.isLatest) ?? null;

  return (
    <div className="space-y-6">
      {/* Window Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-[#F8FAFC]">
            Sleep–Productivity Correlation &amp; Regression Engine
          </h2>
          <p className="text-xs text-[#94A3B8]">
            Pairs exact matching dates with both sleep duration and study focus ratings
          </p>
        </div>
        <div className="flex items-center gap-1 p-1 bg-[#111827] border border-slate-800 rounded-lg">
          {[7, 14, 21, 30].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => onChangeDaysWindow(d)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                daysWindow === d
                  ? 'bg-[#60A5FA] text-[#0F172A] font-semibold'
                  : 'text-[#94A3B8] hover:text-[#F8FAFC]'
              }`}
            >
              Last {d} days
            </button>
          ))}
        </div>
      </div>

      {/* Statistical Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <span className="text-xs text-[#94A3B8]">Pearson Correlation (r)</span>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {correlation.hasConfidence && correlation.r !== null
              ? `${correlation.r >= 0 ? '+' : ''}${correlation.r.toFixed(2)}`
              : '—'}
          </div>
          <p className="mt-1 text-xs text-[#60A5FA]">{correlation.category}</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <span className="text-xs text-[#94A3B8]">Paired Observations</span>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {correlation.observationCount}{' '}
            <span className="text-sm font-normal text-[#94A3B8]">/ {correlation.requiredCount} min</span>
          </div>
          <p className="mt-1 text-xs text-[#94A3B8]">
            {correlation.hasConfidence ? 'Statistical threshold met' : 'Building sample size'}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <span className="text-xs text-[#94A3B8]">OLS Regression Line</span>
          <div className="mt-2 font-mono text-lg font-bold text-[#FBBF24] tabular-nums">
            {correlation.ols ? correlation.ols.equation : 'Unavailable'}
          </div>
          <p className="mt-1 text-xs text-[#94A3B8]">
            {correlation.ols
              ? `Slope: ${correlation.ols.slope >= 0 ? '+' : ''}${correlation.ols.slope.toFixed(3)} focus / hr sleep`
              : 'Requires ≥7 paired days with variance'}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <span className="text-xs text-[#94A3B8]">Sample Means (x̄, ȳ)</span>
          <div className="mt-2 font-mono text-lg font-bold text-[#34D399] tabular-nums">
            {correlation.meanSleep !== null && correlation.meanFocus !== null
              ? `${correlation.meanSleep.toFixed(2)}h · ${correlation.meanFocus.toFixed(2)}/5`
              : '—'}
          </div>
          <p className="mt-1 text-xs text-[#94A3B8]">Mean sleep &amp; mean focus</p>
        </div>
      </div>

      {/* Confidence Warning if < 7 paired observations */}
      {!correlation.hasConfidence && (
        <div className="rounded-xl border border-[#F59E0B]/40 bg-[#F59E0B]/10 p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#FBBF24] shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-semibold text-[#FBBF24]">
              {correlation.confidenceWarning}
            </h3>
            <p className="mt-1 text-xs text-[#CBD5E1] leading-relaxed">
              {correlation.explanation} Note that DreamLog never invents placeholder correlation values when fewer than 7 paired dates exist.
            </p>
          </div>
        </div>
      )}

      {correlation.hasConfidence && (
        <div className="rounded-xl border border-slate-800 bg-[#111827] p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-[#60A5FA] shrink-0 mt-0.5" />
          <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
            <strong className="text-[#F8FAFC]">{correlation.category}:</strong> {correlation.explanation}{' '}
            <span className="text-[#94A3B8]">
              Remember: correlation measures linear association in your records and does not prove causation alone.
            </span>
          </p>
        </div>
      )}

      {/* Scatter Plot + Dual-Axis Weekly Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="h-80">
            <SleepFocusScatterChart
              correlation={correlation}
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
            />
          </div>
          {selectedPoint && (
            <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="text-[#94A3B8]">
                Selected Point:{' '}
                <strong className="text-[#F8FAFC]">{formatShortDate(selectedPoint.date)}</strong>
                {selectedPoint.isLatest && ' · Latest Added'}
              </span>
              <span className="font-mono text-[#FBBF24] tabular-nums">
                {selectedPoint.x.toFixed(2)}h sleep → {selectedPoint.y.toFixed(2)}/5 focus ({selectedPoint.studyHours}h · {selectedPoint.subjects.join(', ')})
              </span>
            </div>
          )}
        </div>

        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-[#60A5FA]" />
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              Sleep vs. Productivity Timeline
            </h3>
          </div>
          <p className="text-xs text-[#94A3B8] mb-3">
            Tracks how nightly sleep duration and next-day focus move together across the window.
          </p>
          <div className="h-72 flex-1">
            <SleepVsProductivityTrendChart series={analytics.dailySeries} />
          </div>
        </div>
      </div>

      {/* Personalized Weekly Optimization Insights */}
      <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5">
        <div className="flex items-center gap-2.5">
          <Sparkles className="w-5 h-5 text-[#FBBF24]" />
          <h3 className="text-base font-semibold text-[#F8FAFC]">
            Data-Driven Optimization Recommendations
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-[#34D399]">Sleep Optimization</h4>
            {insights.sleepRecommendations.map((rec, i) => (
              <div key={i} className="flex items-start gap-2.5 text-sm text-[#CBD5E1]">
                <CheckCircle2 className="w-4 h-4 text-[#34D399] shrink-0 mt-0.5" />
                <span>{rec}</span>
              </div>
            ))}
          </div>
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-[#60A5FA]">Study Productivity</h4>
            {insights.studyRecommendations.map((rec, i) => (
              <div key={i} className="flex items-start gap-2.5 text-sm text-[#CBD5E1]">
                <CheckCircle2 className="w-4 h-4 text-[#60A5FA] shrink-0 mt-0.5" />
                <span>{rec}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

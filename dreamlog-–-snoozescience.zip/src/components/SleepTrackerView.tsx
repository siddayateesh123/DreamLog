import React, { useMemo, useState } from 'react';
import { Clock, Edit3, Moon, Plus, Trash2 } from 'lucide-react';
import { api } from '../api/client.ts';
import {
  calculateSleepDuration,
  formatHoursMinutes,
  formatShortDate,
  formatTime12h,
  getLocalDateStr,
} from '../shared/math.ts';
import type { SleepLog } from '../shared/types.ts';
import { ConfirmModal, EmptyState, StarRatingInput } from './ui.tsx';

export function SleepTrackerView({
  logs,
  onDataChanged,
  onNotify,
}: {
  logs: SleepLog[];
  onDataChanged: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [date, setDate] = useState(getLocalDateStr(0));
  const [bedtime, setBedtime] = useState('23:30');
  const [wakeTime, setWakeTime] = useState('07:30');
  const [sleepQuality, setSleepQuality] = useState(4);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<SleepLog | null>(null);

  const computedDuration = useMemo(() => calculateSleepDuration(bedtime, wakeTime), [bedtime, wakeTime]);

  const resetForm = () => {
    setEditingId(null);
    setDate(getLocalDateStr(0));
    setBedtime('23:30');
    setWakeTime('07:30');
    setSleepQuality(4);
    setNotes('');
    setErrorMsg(null);
  };

  const handleEdit = (log: SleepLog) => {
    setEditingId(log.id);
    setDate(log.date);
    setBedtime(log.bedtime);
    setWakeTime(log.wakeTime);
    setSleepQuality(log.sleepQuality);
    setNotes(log.notes || '');
    setErrorMsg(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (computedDuration < 0.25 || computedDuration > 20) {
      setErrorMsg('Sleep duration must be between 15 minutes and 20 hours.');
      return;
    }

    setSubmitting(true);
    try {
      if (editingId !== null) {
        await api.updateSleepLog(editingId, { date, bedtime, wakeTime, sleepQuality, notes });
        onNotify('success', `Updated sleep log for ${formatShortDate(date)} (${formatHoursMinutes(computedDuration)}).`);
      } else {
        await api.createSleepLog({ date, bedtime, wakeTime, sleepQuality, notes });
        onNotify('success', `Saved ${formatHoursMinutes(computedDuration)} sleep log for ${formatShortDate(date)}.`);
      }
      resetForm();
      await onDataChanged();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to save sleep log.';
      setErrorMsg(msg);
      onNotify('error', msg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteSleepLog(deleteTarget.id);
      onNotify('info', `Deleted sleep log for ${formatShortDate(deleteTarget.date)}.`);
      if (editingId === deleteTarget.id) resetForm();
      setDeleteTarget(null);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to delete sleep log.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sleep Logger Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5 h-fit"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Moon className="w-5 h-5 text-[#60A5FA]" />
              <h2 className="text-base font-semibold text-[#F8FAFC]">
                {editingId !== null ? 'Edit Sleep Record' : 'Nightly Sleep Logger'}
              </h2>
            </div>
            {editingId !== null && (
              <button
                type="button"
                onClick={resetForm}
                className="text-xs text-[#94A3B8] hover:text-[#F8FAFC]"
              >
                Cancel Edit
              </button>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <label htmlFor="sleep-date" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                Date (Morning of Wake-Up)
              </label>
              <input
                id="sleep-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="sleep-bedtime" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                  Bedtime
                </label>
                <input
                  id="sleep-bedtime"
                  type="time"
                  value={bedtime}
                  onChange={(e) => setBedtime(e.target.value)}
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
                />
              </div>
              <div>
                <label htmlFor="sleep-waketime" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                  Wake-up Time
                </label>
                <input
                  id="sleep-waketime"
                  type="time"
                  value={wakeTime}
                  onChange={(e) => setWakeTime(e.target.value)}
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
                />
              </div>
            </div>

            {/* Auto-Calculated Duration Preview */}
            <div className="rounded-lg bg-[#0F172A]/80 border border-slate-800 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-[#94A3B8]">
                <Clock className="w-4 h-4 text-[#60A5FA]" />
                <span>Total Sleep Duration</span>
              </div>
              <div className="text-right">
                <span className="font-mono text-base font-bold text-[#60A5FA] tabular-nums">
                  {computedDuration > 0 ? formatHoursMinutes(computedDuration) : 'Invalid'}
                </span>
                {computedDuration > 0 && (
                  <span className="ml-2 text-xs font-mono text-[#94A3B8]">
                    ({computedDuration.toFixed(2)}h)
                  </span>
                )}
              </div>
            </div>

            <div>
              <span className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                Sleep Quality Rating (1–5 Stars)
              </span>
              <StarRatingInput
                value={sleepQuality}
                onChange={setSleepQuality}
                label="Sleep quality rating"
              />
            </div>

            <div>
              <label htmlFor="sleep-notes" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                Optional Notes
              </label>
              <textarea
                id="sleep-notes"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g., Restorative sleep, no screens after 11 PM"
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] placeholder:text-slate-500 focus:outline-none focus:border-[#60A5FA]"
              />
            </div>

            {errorMsg && (
              <p className="text-xs text-[#F87171] bg-[#F87171]/10 border border-[#F87171]/30 rounded-lg px-3 py-2">
                {errorMsg}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 px-4 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] disabled:opacity-50 transition-colors inline-flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>{submitting ? 'Saving...' : editingId !== null ? 'Update Sleep Log' : 'Save Sleep Log'}</span>
            </button>
          </div>
        </form>

        {/* Sleep History Table */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-semibold text-[#F8FAFC]">Sleep History</h3>
              <p className="text-xs text-[#94A3B8]">
                {logs.length} total record{logs.length === 1 ? '' : 's'} · Overnight midnight crossing supported
              </p>
            </div>
          </div>

          {logs.length === 0 ? (
            <EmptyState
              icon={Moon}
              title="No sleep records yet"
              description="Enter your bedtime and wake-up time on the left to start tracking nightly sleep duration and debt."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-xs font-medium text-[#94A3B8]">
                    <th className="py-2.5 pr-3">Date</th>
                    <th className="py-2.5 px-3">Window</th>
                    <th className="py-2.5 px-3 text-right">Duration</th>
                    <th className="py-2.5 px-3 text-right">Quality</th>
                    <th className="py-2.5 pl-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70 text-sm">
                  {logs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 pr-3 whitespace-nowrap">
                        <div className="font-medium text-[#F8FAFC]">{formatShortDate(log.date)}</div>
                        <div className="text-xs text-[#94A3B8]">
                          {log.date}
                          {log.isDemo ? ' · DEMO DATA' : ''}
                        </div>
                      </td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className="font-mono text-xs text-[#CBD5E1] tabular-nums">
                          {formatTime12h(log.bedtime)} → {formatTime12h(log.wakeTime)}
                        </div>
                        {log.notes && (
                          <div className="text-xs text-[#94A3B8] truncate max-w-[200px]">
                            {log.notes}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right whitespace-nowrap font-mono font-semibold text-[#60A5FA] tabular-nums">
                        {formatHoursMinutes(log.duration)}
                      </td>
                      <td className="py-3 px-3 text-right whitespace-nowrap font-mono text-[#FBBF24] tabular-nums">
                        {log.sleepQuality}/5
                      </td>
                      <td className="py-3 pl-3 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleEdit(log)}
                            className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#60A5FA] hover:bg-slate-800 transition-colors"
                            aria-label={`Edit sleep log for ${log.date}`}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(log)}
                            className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#F87171] hover:bg-slate-800 transition-colors"
                            aria-label={`Delete sleep log for ${log.date}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <ConfirmModal
        open={deleteTarget !== null}
        title="Delete Sleep Record"
        message={`Are you sure you want to delete the sleep log for ${deleteTarget ? formatShortDate(deleteTarget.date) : ''}? Your correlation and sleep debt metrics will recalculate automatically.`}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

import React from 'react';
import {
  Activity,
  ArrowRight,
  BarChart3,
  BookOpen,
  CalendarClock,
  CheckCircle2,
  Moon,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';

export function LandingPage({
  onGetStarted,
  onExploreDashboard,
}: {
  onGetStarted: () => void;
  onExploreDashboard: () => void;
}) {
  return (
    <div className="min-h-screen bg-[#0F172A] text-[#F8FAFC] relative overflow-x-hidden">
      {/* Subtle Night-Sky Ambient Gradient */}
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(96,165,250,0.12)_0%,_rgba(15,23,42,0)_55%)]"
        aria-hidden="true"
      />

      {/* 3-Zone Top Bar Contract */}
      <header className="relative z-10 max-w-7xl mx-auto px-6 py-5 flex items-center justify-between gap-8 border-b border-slate-800/80">
        <a
          href="#top"
          className="text-lg font-bold tracking-tight text-[#F8FAFC] whitespace-nowrap shrink-0 flex items-center gap-2.5"
        >
          <Moon className="w-5 h-5 text-[#60A5FA]" />
          <span>DreamLog</span>
        </a>

        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#94A3B8]">
          <a href="#features" className="hover:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0">
            Features
          </a>
          <a href="#how-it-works" className="hover:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0">
            How It Works
          </a>
          <a href="#evidence" className="hover:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0">
            Correlation Engine
          </a>
          <a href="#benefits" className="hover:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0">
            Student Benefits
          </a>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onExploreDashboard}
            className="px-4 py-2 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] transition-colors whitespace-nowrap shrink-0"
          >
            Explore Dashboard
          </button>
        </div>
      </header>

      <main id="top" className="relative z-10">
        {/* Hero Split */}
        <section className="max-w-7xl mx-auto px-6 pt-12 pb-16 lg:pt-20 lg:pb-24">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center">
              <p className="text-sm font-medium text-[#60A5FA] tracking-wide mb-4">
                DreamLog – SnoozeScience · Student Wellness Analytics
              </p>
              <h1
                className="font-display font-bold tracking-tight text-[#F8FAFC] leading-[1.1] max-w-xl"
                style={{ fontSize: 'clamp(2.35rem, 4.2vw, 3.75rem)', textWrap: 'balance' }}
              >
                Sleep Smarter. Study Better.
              </h1>
              <p className="mt-5 text-base sm:text-lg text-[#94A3B8] leading-relaxed max-w-xl">
                College students often trade sleep for extra study hours—yet cognitive fatigue erodes recall and focus. DreamLog connects your nightly rest, study sessions, and caffeine timing to reveal the real statistical link between sleep and academic performance.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={onGetStarted}
                  className="px-6 py-3 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <span>Get Started</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={onExploreDashboard}
                  className="px-6 py-3 rounded-lg border border-slate-700 bg-[#1E293B]/60 text-[#F8FAFC] text-sm font-semibold hover:bg-[#1E293B] transition-colors whitespace-nowrap shrink-0"
                >
                  Explore Dashboard
                </button>
              </div>

              <div className="mt-10 pt-8 border-t border-slate-800/90 grid grid-cols-3 gap-6 max-w-lg">
                <div>
                  <div className="font-mono text-2xl font-semibold text-[#F8FAFC] tabular-nums">21 Days</div>
                  <div className="mt-1 text-xs text-[#94A3B8]">Pre-loaded demo telemetry</div>
                </div>
                <div>
                  <div className="font-mono text-2xl font-semibold text-[#60A5FA] tabular-nums">Pearson r</div>
                  <div className="mt-1 text-xs text-[#94A3B8]">Live OLS regression fit</div>
                </div>
                <div>
                  <div className="font-mono text-2xl font-semibold text-[#FBBF24] tabular-nums">7h+ Min</div>
                  <div className="mt-1 text-xs text-[#94A3B8]">Exam week sleep protection</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 flex">
              <div className="relative w-full rounded-2xl overflow-hidden border border-slate-800 bg-[#111827] min-h-[320px] lg:min-h-[440px]">
                <img
                  src="/src/assets/images/hero_sleep_study_1794932871424.jpg"
                  alt="Midnight college study desk overlooking a starry sky with warm desk lamp"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A]/90 via-[#0F172A]/20 to-transparent" />
                <div className="absolute bottom-5 left-5 right-5 flex flex-wrap items-end justify-between gap-4">
                  <div>
                    <p className="text-xs font-medium text-[#94A3B8]">Empirical Study Analytics</p>
                    <p className="text-sm font-semibold text-[#F8FAFC] mt-0.5">
                      Pair overnight sleep duration directly with next-day Deep Focus ratings
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Feature Highlights (Asymmetric Grid) */}
        <section id="features" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-800/80">
          <div className="max-w-2xl mb-10">
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F8FAFC]">
              Built for verifiable student self-experimentation
            </h2>
            <p className="mt-2.5 text-sm sm:text-base text-[#94A3B8]">
              Every metric is calculated dynamically from your stored logs—no fabricated scores or generic advice.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="md:col-span-2 rounded-xl border border-slate-800 bg-[#1E293B]/65 p-6">
              <div className="flex items-center gap-3 text-[#60A5FA] mb-3">
                <TrendingUp className="w-5 h-5" />
                <h3 className="font-display text-lg font-semibold text-[#F8FAFC]">
                  Pearson Correlation & OLS Scatter Plot
                </h3>
              </div>
              <p className="text-sm text-[#94A3B8] leading-relaxed">
                Automatically pairs nightly sleep duration with same-day average focus ratings (1–5), computes Pearson&apos;s correlation coefficient and Ordinary Least Squares regression equation, and guards statistical confidence until at least 7 paired days are recorded.
              </p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/65 p-6">
              <div className="flex items-center gap-3 text-[#FBBF24] mb-3">
                <Moon className="w-5 h-5" />
                <h3 className="font-display text-lg font-semibold text-[#F8FAFC]">
                  Overnight Sleep Logger
                </h3>
              </div>
              <p className="text-sm text-[#94A3B8] leading-relaxed">
                Handles midnight crossings seamlessly—logging 11:30 PM to 7:30 AM accurately computes 8h 0m alongside 1–5 star sleep quality ratings.
              </p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/65 p-6">
              <div className="flex items-center gap-3 text-[#34D399] mb-3">
                <BookOpen className="w-5 h-5" />
                <h3 className="font-display text-lg font-semibold text-[#F8FAFC]">
                  Subject Study Tracker
                </h3>
              </div>
              <p className="text-sm text-[#94A3B8] leading-relaxed">
                Log multiple subjects per day with focus scales from Very Poor Focus (1) to Deep Focus (5) and inspect subject-wise output.
              </p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/65 p-6">
              <div className="flex items-center gap-3 text-[#F59E0B] mb-3">
                <Activity className="w-5 h-5" />
                <h3 className="font-display text-lg font-semibold text-[#F8FAFC]">
                  Sleep Debt & Caffeine Half-Life
                </h3>
              </div>
              <p className="text-sm text-[#94A3B8] leading-relaxed">
                Tracks cumulative sleep debt against an 8-hour baseline and models 5-hour caffeine clearance curves right up to bedtime.
              </p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/65 p-6">
              <div className="flex items-center gap-3 text-[#60A5FA] mb-3">
                <ShieldCheck className="w-5 h-5" />
                <h3 className="font-display text-lg font-semibold text-[#F8FAFC]">
                  Exam Week Sleep Preserver
                </h3>
              </div>
              <p className="text-sm text-[#94A3B8] leading-relaxed">
                Builds non-overlapping exam prep schedules capped at 8 study hours per day while protecting at least 7 hours of nightly sleep.
              </p>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section id="how-it-works" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-800/80">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-5">
              <div className="rounded-2xl overflow-hidden border border-slate-800 bg-[#111827]">
                <img
                  src="/src/assets/images/circadian_analytics_visual_1794932872053.jpg"
                  alt="Isometric circadian wave curves and data points"
                  referrerPolicy="no-referrer"
                  className="w-full aspect-[4/3] object-cover"
                />
              </div>
            </div>

            <div className="lg:col-span-7 space-y-6">
              <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F8FAFC]">
                How DreamLog turns daily logs into clarity
              </h2>

              <div className="space-y-5 pt-2">
                {[
                  {
                    step: '01. Record Sleep Across Midnight',
                    desc: 'Enter your bedtime, wake-up time, and quality rating. DreamLog computes exact hours and minutes and updates your weekly sleep debt.',
                  },
                  {
                    step: '02. Log Study Sessions & Focus',
                    desc: 'Capture each course, duration, and 1–5 focus score. Multiple sessions on the same day aggregate into your daily focus average.',
                  },
                  {
                    step: '03. Inspect Your Personal Regression',
                    desc: 'Once 7+ paired days are logged, the correlation engine plots every day, fits an OLS trendline, and highlights your newest entries.',
                  },
                  {
                    step: '04. Act on Weekly Insights & Export PDF',
                    desc: 'Review data-derived recommendations, schedule 90-minute bedtime cycles, and export an advisor-ready Wellness PDF report.',
                  },
                ].map((item) => (
                  <div key={item.step} className="pb-5 border-b border-slate-800/80 last:border-b-0 last:pb-0">
                    <h3 className="font-display text-base font-semibold text-[#F8FAFC]">{item.step}</h3>
                    <p className="mt-1 text-sm text-[#94A3B8] leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Evidence & Benefits */}
        <section id="evidence" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-800/80">
          <div id="benefits" className="rounded-2xl border border-slate-800 bg-[#111827] p-8 lg:p-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7">
                <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F8FAFC]">
                  Why sleep discipline outperforms all-nighters
                </h2>
                <p className="mt-3 text-sm sm:text-base text-[#94A3B8] leading-relaxed">
                  DreamLog pairs your own logs with transparent statistical guardrails—never claiming correlation proves causation, and always separating verified observations from insufficient samples.
                </p>
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    'Tracks 7, 14, 21, and 30-day rolling windows',
                    'Enforces ≥ 7 paired observations before trend claims',
                    'Estimates bedtime caffeine using configurable half-life',
                    'Generates downloadable Wellness PDFs with live charts',
                  ].map((text) => (
                    <div key={text} className="flex items-start gap-2.5 text-sm text-[#CBD5E1]">
                      <CheckCircle2 className="w-4 h-4 text-[#34D399] shrink-0 mt-0.5" />
                      <span>{text}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="lg:col-span-5 flex flex-col gap-4">
                <div className="rounded-xl border border-slate-800 bg-[#1E293B]/70 p-5">
                  <div className="flex items-center justify-between text-xs text-[#94A3B8]">
                    <span>Demo Telemetry Preview</span>
                    <span>21-Day Seed</span>
                  </div>
                  <div className="mt-2 font-mono text-2xl font-semibold text-[#F8FAFC] tabular-nums">
                    7.5h+ Nights → Higher Deep Focus
                  </div>
                  <p className="mt-1.5 text-xs text-[#94A3B8]">
                    Explore the pre-loaded 21-day sample dataset or clear it anytime to record your own semester.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={onGetStarted}
                  className="w-full py-3.5 px-6 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <BarChart3 className="w-4 h-4" />
                  <span>Open DreamLog Workspace</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-800/80 py-8 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#94A3B8]">
          <div className="flex items-center gap-2">
            <CalendarClock className="w-4 h-4 text-[#60A5FA]" />
            <span>DreamLog – SnoozeScience · Student Sleep & Academic Productivity Analytics</span>
          </div>
          <div className="flex items-center gap-5">
            <span>8h tracking baseline is non-diagnostic</span>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={onExploreDashboard}
              className="text-[#60A5FA] hover:underline"
            >
              Launch Dashboard
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

import React from 'react';
import { Activity, AlertCircle, BatteryCharging, CheckCircle2, Info } from 'lucide-react';
import { formatHoursMinutes, formatShortDate } from '../shared/math.ts';
import type { SleepDebtSummary } from '../shared/types.ts';
import { SleepDebtBarChart } from './Charts.tsx';
import { AnimatedNumber, EmptyState } from './ui.tsx';

export function SleepDebtView({
  sleepDebt,
  onNavigateSleep,
}: {
  sleepDebt: SleepDebtSummary;
  onNavigateSleep: () => void;
}) {
  const statusColor =
    sleepDebt.consistencyStatus === 'Consistent'
      ? 'text-[#34D399]'
      : sleepDebt.consistencyStatus === 'Moderate Variance'
        ? 'text-[#F59E0B]'
        : sleepDebt.consistencyStatus === 'Inconsistent'
          ? 'text-[#F87171]'
          : 'text-[#94A3B8]';

  return (
    <div className="space-y-6">
      {/* Disclaimer Banner */}
      <div className="rounded-xl border border-slate-800 bg-[#111827] p-4 flex items-start gap-3">
        <Info className="w-5 h-5 text-[#60A5FA] shrink-0 mt-0.5" />
        <p className="text-xs sm:text-sm text-[#CBD5E1]">
          <strong className="text-[#F8FAFC]">Tracking Baseline Notice:</strong>{' '}
          {sleepDebt.baselineDisclaimer}
        </p>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between text-xs text-[#94A3B8]">
            <span>Weekly Cumulative Debt (7d)</span>
            <BatteryCharging className="w-4 h-4 text-[#F87171]" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            <AnimatedNumber value={sleepDebt.weeklyCumulativeDebt} decimals={2} suffix="h" />
          </div>
          <p className="mt-1 text-xs text-[#94A3B8]">
            Sum of max(0, {sleepDebt.baselineHours}h − sleep)
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between text-xs text-[#94A3B8]">
            <span>Average Nightly Sleep</span>
            <Activity className="w-4 h-4 text-[#60A5FA]" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#60A5FA] tabular-nums">
            <AnimatedNumber value={sleepDebt.averageNightlySleep} decimals={2} suffix="h" />
          </div>
          <p className="mt-1 text-xs text-[#94A3B8]">
            {formatHoursMinutes(sleepDebt.averageNightlySleep)} per night
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between text-xs text-[#94A3B8]">
            <span>Sleep Goal Completion</span>
            <CheckCircle2 className="w-4 h-4 text-[#34D399]" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-[#34D399] tabular-nums">
            <AnimatedNumber value={sleepDebt.goalCompletionPercent} decimals={0} suffix="%" />
          </div>
          <div className="mt-2 h-2 rounded-full bg-[#0F172A] overflow-hidden">
            <div
              className="h-full rounded-full bg-[#34D399] transition-all duration-300"
              style={{ width: `${sleepDebt.goalCompletionPercent}%` }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between text-xs text-[#94A3B8]">
            <span>Sleep Consistency Status</span>
            <AlertCircle className="w-4 h-4 text-[#FBBF24]" />
          </div>
          <div className={`mt-2 font-display text-xl font-bold ${statusColor}`}>
            {sleepDebt.consistencyStatus}
          </div>
          <p className="mt-1 text-xs text-[#94A3B8]">
            Std Dev: ±{sleepDebt.sleepStdDevHours.toFixed(2)}h
          </p>
        </div>
      </div>

      {sleepDebt.dailyBreakdown.length === 0 ? (
        <EmptyState
          icon={BatteryCharging}
          title="No sleep records in this window"
          description="Log your nightly sleep to compute cumulative sleep debt and recovery recommendations."
          actionLabel="Go to Sleep Tracker"
          onAction={onNavigateSleep}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Debt Chart */}
          <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6">
            <h3 className="text-base font-semibold text-[#F8FAFC] mb-1">
              Actual Sleep vs. Daily Sleep Debt
            </h3>
            <p className="text-xs text-[#94A3B8] mb-4">
              Stacked bars show actual rest alongside shortfalls below your {sleepDebt.baselineHours}h baseline
            </p>
            <div className="h-72">
              <SleepDebtBarChart sleepDebt={sleepDebt} />
            </div>
          </div>

          {/* Recommendations + Daily Breakdown */}
          <div className="lg:col-span-5 space-y-6">
            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6">
              <h3 className="text-base font-semibold text-[#F8FAFC] mb-3">
                Recovery &amp; Consistency Recommendations
              </h3>
              <ul className="space-y-3 text-sm text-[#CBD5E1] leading-relaxed">
                {sleepDebt.recommendations.map((rec, i) => (
                  <li key={i} className="pb-2.5 border-b border-slate-800/70 last:border-b-0 last:pb-0">
                    {rec}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6">
              <h3 className="text-base font-semibold text-[#F8FAFC] mb-3">Daily Sleep Debt Log</h3>
              <div className="max-h-56 overflow-y-auto divide-y divide-slate-800/70 text-xs">
                {[...sleepDebt.dailyBreakdown].reverse().map((d) => (
                  <div key={d.date} className="py-2.5 flex items-center justify-between">
                    <span className="font-medium text-[#F8FAFC]">{formatShortDate(d.date)}</span>
                    <div className="flex items-center gap-4 font-mono tabular-nums">
                      <span className="text-[#60A5FA]">{d.actualSleep.toFixed(2)}h slept</span>
                      <span className={d.debt > 0 ? 'text-[#F87171]' : 'text-[#34D399]'}>
                        {d.debt > 0 ? `${d.debt.toFixed(2)}h debt` : '0.00h debt'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

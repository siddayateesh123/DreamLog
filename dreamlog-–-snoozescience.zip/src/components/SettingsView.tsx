import React, { useState } from 'react';
import { Database, RotateCcw, Save, Settings, Trash2 } from 'lucide-react';
import { api } from '../api/client.ts';
import type { UserSettings } from '../shared/types.ts';
import { ConfirmModal } from './ui.tsx';

export function SettingsView({
  settings,
  hasDemoData,
  demoCount,
  onDataChanged,
  onNotify,
}: {
  settings: UserSettings;
  hasDemoData: boolean;
  demoCount: number;
  onDataChanged: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const [studentName, setStudentName] = useState(settings.studentName);
  const [sleepBaselineHours, setSleepBaselineHours] = useState(String(settings.sleepBaselineHours));
  const [caffeineHalfLifeHours, setCaffeineHalfLifeHours] = useState(
    String(settings.caffeineHalfLifeHours),
  );
  const [preferredWakeTime, setPreferredWakeTime] = useState(settings.preferredWakeTime);
  const [dailyAvailableHours, setDailyAvailableHours] = useState(
    String(settings.dailyAvailableHours),
  );
  const [saving, setSaving] = useState(false);
  const [confirmAction, setConfirmAction] = useState<'clear' | 'reset' | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.updateSettings({
        studentName: studentName.trim() || 'Student',
        sleepBaselineHours: Number(sleepBaselineHours) || 8,
        caffeineHalfLifeHours: Number(caffeineHalfLifeHours) || 5,
        preferredWakeTime,
        dailyAvailableHours: Math.min(8, Math.max(1, Number(dailyAvailableHours) || 7)),
      });
      onNotify('success', 'Settings saved and analytics updated.');
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to update settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleDemoAction = async () => {
    if (!confirmAction) return;
    try {
      if (confirmAction === 'clear') {
        await api.clearDemoData();
        onNotify('info', 'Cleared 21-day demo dataset. Your workspace is ready for personal logs.');
      } else {
        await api.resetDemoData();
        onNotify('success', 'Restored 21-day sample demo dataset.');
      }
      setConfirmAction(null);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to update demo dataset.');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <form
        onSubmit={handleSave}
        className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5"
      >
        <div className="flex items-center gap-2.5">
          <Settings className="w-5 h-5 text-[#60A5FA]" />
          <h2 className="text-base font-semibold text-[#F8FAFC]">
            Profile &amp; Tracking Baselines
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label htmlFor="set-name" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Student Name (used in Wellness Reports)
            </label>
            <input
              id="set-name"
              type="text"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
              required
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
          </div>

          <div>
            <label htmlFor="set-baseline" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Sleep Debt Baseline (Hours)
            </label>
            <input
              id="set-baseline"
              type="number"
              min="5"
              max="11"
              step="0.5"
              value={sleepBaselineHours}
              onChange={(e) => setSleepBaselineHours(e.target.value)}
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
          </div>

          <div>
            <label htmlFor="set-halflife" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Caffeine Half-Life Estimate (Hours)
            </label>
            <input
              id="set-halflife"
              type="number"
              min="2"
              max="12"
              step="0.5"
              value={caffeineHalfLifeHours}
              onChange={(e) => setCaffeineHalfLifeHours(e.target.value)}
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
          </div>

          <div>
            <label htmlFor="set-wake" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Default Wake-up Time
            </label>
            <input
              id="set-wake"
              type="time"
              value={preferredWakeTime}
              onChange={(e) => setPreferredWakeTime(e.target.value)}
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
          </div>

          <div>
            <label htmlFor="set-study" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Exam Planner Daily Study Cap (≤8h)
            </label>
            <input
              id="set-study"
              type="number"
              min="1"
              max="8"
              step="0.5"
              value={dailyAvailableHours}
              onChange={(e) => setDailyAvailableHours(e.target.value)}
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="px-5 py-2.5 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] transition-colors inline-flex items-center gap-2"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving...' : 'Save Preferences'}</span>
        </button>
      </form>

      {/* Demo Data Controls */}
      <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-4 h-fit">
        <div className="flex items-center gap-2.5">
          <Database className="w-5 h-5 text-[#FBBF24]" />
          <h2 className="text-base font-semibold text-[#F8FAFC]">DEMO DATA Management</h2>
        </div>
        <p className="text-xs sm:text-sm text-[#94A3B8] leading-relaxed">
          DreamLog seeds 21 days of realistic sample student logs so you can test the correlation engine immediately. Any personal records you add are preserved when clearing demo records.
        </p>

        <div className="rounded-lg bg-[#0F172A] border border-slate-800 p-4 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-[#94A3B8]">Demo Records Currently Active</span>
            <span className="font-mono font-semibold text-[#FBBF24] tabular-nums">
              {hasDemoData ? `${demoCount} entries` : '0 entries (Cleared)'}
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-3 pt-2">
          {hasDemoData && (
            <button
              type="button"
              onClick={() => setConfirmAction('clear')}
              className="w-full py-2.5 px-4 rounded-lg border border-[#F87171]/40 bg-[#F87171]/10 text-[#F87171] text-xs font-semibold hover:bg-[#F87171]/20 transition-colors inline-flex items-center justify-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete Sample Demo Data &amp; Start Fresh</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => setConfirmAction('reset')}
            className="w-full py-2.5 px-4 rounded-lg border border-slate-700 bg-[#0F172A] text-[#F8FAFC] text-xs font-semibold hover:border-[#60A5FA] transition-colors inline-flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4 text-[#60A5FA]" />
            <span>Restore 21-Day Demo Dataset</span>
          </button>
        </div>
      </div>

      <ConfirmModal
        open={confirmAction !== null}
        title={confirmAction === 'clear' ? 'Clear Sample Demo Data' : 'Restore 21-Day Demo Data'}
        message={
          confirmAction === 'clear'
            ? 'This removes all DEMO DATA entries while keeping any personal sleep, study, and caffeine logs you entered.'
            : 'This restores the 21-day sample student dataset alongside any personal entries.'
        }
        confirmLabel={confirmAction === 'clear' ? 'Delete Demo Data' : 'Restore Demo Data'}
        variant={confirmAction === 'clear' ? 'danger' : 'primary'}
        onConfirm={handleDemoAction}
        onCancel={() => setConfirmAction(null)}
      />
    </div>
  );
}

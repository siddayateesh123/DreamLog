import React, { useRef, useState } from 'react';
import { jsPDF } from 'jspdf';
import { Download, FileText, Printer } from 'lucide-react';
import { formatShortDate } from '../shared/math.ts';
import type { DashboardAnalytics, UserSettings } from '../shared/types.ts';
import { SleepFocusScatterChart, SleepVsProductivityTrendChart } from './Charts.tsx';

export function ReportsView({
  analytics,
  settings,
  daysWindow,
  onChangeDaysWindow,
  onNotify,
}: {
  analytics: DashboardAnalytics;
  settings: UserSettings;
  daysWindow: number;
  onChangeDaysWindow: (days: number) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const reportChartAreaRef = useRef<HTMLDivElement | null>(null);
  const [exporting, setExporting] = useState(false);

  const sleepDays = analytics.dailySeries.filter((d) => d.totalSleep > 0);
  const totalSleepHours = Math.round(sleepDays.reduce((a, d) => a + d.totalSleep, 0) * 100) / 100;
  const avgNightlySleep =
    sleepDays.length > 0 ? Math.round((totalSleepHours / sleepDays.length) * 100) / 100 : 0;
  const totalStudyHours =
    Math.round(analytics.dailySeries.reduce((a, d) => a + d.totalStudyHours, 0) * 100) / 100;

  const periodLabel =
    analytics.dailySeries.length > 0
      ? `${formatShortDate(analytics.dailySeries[0].date)} – ${formatShortDate(analytics.dailySeries[analytics.dailySeries.length - 1].date)} (Last ${daysWindow} days)`
      : `Last ${daysWindow} days`;

  const generatedDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handleDownloadPdf = async () => {
    setExporting(true);
    try {
      const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 42;
      const contentWidth = pageWidth - margin * 2;
      let y = 44;

      // Header Banner
      doc.setFillColor(15, 23, 42);
      doc.rect(0, 0, pageWidth, 88, 'F');
      doc.setTextColor(248, 250, 252);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(18);
      doc.text('DreamLog – SnoozeScience', margin, 36);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(11);
      doc.setTextColor(148, 163, 184);
      doc.text('Student Sleep & Academic Wellness Report', margin, 56);
      doc.setFontSize(9);
      doc.text(`Generated: ${generatedDate}`, pageWidth - margin, 36, { align: 'right' });
      doc.text(`Period: ${periodLabel}`, pageWidth - margin, 56, { align: 'right' });

      y = 110;
      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text(`Student: ${settings.studentName}`, margin, y);
      if (analytics.hasDemoData) {
        doc.setFontSize(9);
        doc.setTextColor(180, 83, 9);
        doc.text('Includes DEMO DATA records', pageWidth - margin, y, { align: 'right' });
      }

      // KPI Summary Table
      y += 20;
      const kpis = [
        ['Total Sleep Hours', `${totalSleepHours.toFixed(1)} hrs`],
        ['Avg Nightly Sleep', `${avgNightlySleep.toFixed(2)} hrs`],
        ['Weekly Sleep Debt', `${analytics.weeklySleepDebt.toFixed(2)} hrs`],
        ['Total Study Hours', `${totalStudyHours.toFixed(1)} hrs`],
        ['Average Focus Rating', `${analytics.averageFocusRating.toFixed(2)} / 5`],
        [
          'Pearson Correlation (r)',
          analytics.correlation.hasConfidence && analytics.correlation.r !== null
            ? `${analytics.correlation.r >= 0 ? '+' : ''}${analytics.correlation.r.toFixed(2)} (${analytics.correlation.category})`
            : 'Needs ≥7 paired days',
        ],
      ];

      doc.setDrawColor(203, 213, 225);
      doc.setFillColor(248, 250, 252);
      const colW = contentWidth / 3;
      kpis.forEach((item, idx) => {
        const col = idx % 3;
        const row = Math.floor(idx / 3);
        const bx = margin + col * colW;
        const by = y + row * 44;
        doc.rect(bx, by, colW - 6, 38, 'FD');
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(100, 116, 139);
        doc.text(item[0], bx + 8, by + 14);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(15, 23, 42);
        doc.text(item[1], bx + 8, by + 29);
      });

      y += 106;

      // Capture live Chart.js canvases from the report container
      const canvases = reportChartAreaRef.current?.querySelectorAll('canvas');
      if (canvases && canvases.length >= 2) {
        const addChartSnapshot = (canvas: HTMLCanvasElement, x: number, topY: number, w: number, h: number) => {
          const tempCanvas = document.createElement('canvas');
          tempCanvas.width = canvas.width;
          tempCanvas.height = canvas.height;
          const ctx = tempCanvas.getContext('2d');
          if (ctx) {
            ctx.fillStyle = '#0F172A';
            ctx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
            ctx.drawImage(canvas, 0, 0);
          }
          const imgData = tempCanvas.toDataURL('image/png');
          doc.addImage(imgData, 'PNG', x, topY, w, h);
        };

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text('Visual Analytics Snapshots', margin, y);
        y += 12;

        const halfW = (contentWidth - 10) / 2;
        addChartSnapshot(canvases[0], margin, y, halfW, 145);
        addChartSnapshot(canvases[1], margin + halfW + 10, y, halfW, 145);
        y += 165;
      }

      // Summary & Insights
      const writeSection = (title: string, lines: string[]) => {
        if (y > 740) {
          doc.addPage();
          y = 48;
        }
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text(title, margin, y);
        y += 14;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9.5);
        doc.setTextColor(51, 65, 85);
        for (const line of lines) {
          const wrapped = doc.splitTextToSize(`• ${line}`, contentWidth);
          if (y + wrapped.length * 12 > 790) {
            doc.addPage();
            y = 48;
          }
          doc.text(wrapped, margin, y);
          y += wrapped.length * 12 + 4;
        }
        y += 6;
      };

      writeSection('Summary of Findings', [analytics.insights.weeklySummary]);
      writeSection('Personalized Insights', [
        ...analytics.insights.positiveInsights,
        ...analytics.insights.improvementAreas,
      ]);
      writeSection('Sleep & Study Recommendations', [
        ...analytics.insights.sleepRecommendations,
        ...analytics.insights.studyRecommendations,
      ]);

      // Mandatory Methodological Disclaimer
      if (y > 740) {
        doc.addPage();
        y = 48;
      }
      doc.setDrawColor(226, 232, 240);
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, contentWidth, 44, 'FD');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(30, 41, 59);
      doc.text('Methodological Note:', margin + 8, y + 14);
      doc.setFont('helvetica', 'normal');
      doc.text(
        doc.splitTextToSize(
          'Statistical correlation measures observed linear association in self-reported logs and does not prove causation. The 8-hour sleep baseline is a tracking reference, not a medical prescription.',
          contentWidth - 16,
        ),
        margin + 8,
        y + 26,
      );

      doc.save(`DreamLog_Wellness_Report_${settings.studentName.replace(/\s+/g, '_')}.pdf`);
      onNotify('success', 'Downloaded DreamLog Student Wellness PDF report.');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'PDF generation failed.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-1 p-1 bg-[#111827] border border-slate-800 rounded-lg">
          {[7, 14, 21, 30].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => onChangeDaysWindow(d)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                daysWindow === d
                  ? 'bg-[#60A5FA] text-[#0F172A] font-semibold'
                  : 'text-[#94A3B8] hover:text-[#F8FAFC]'
              }`}
            >
              Last {d} days
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => window.print()}
            className="px-4 py-2 rounded-lg border border-slate-700 bg-[#1E293B] text-xs font-medium text-[#F8FAFC] hover:bg-slate-800 transition-colors inline-flex items-center gap-2 whitespace-nowrap"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
          <button
            type="button"
            disabled={exporting}
            onClick={handleDownloadPdf}
            className="px-4 py-2 rounded-lg bg-[#60A5FA] text-[#0F172A] text-xs font-semibold hover:bg-[#93C5FD] disabled:opacity-50 transition-colors inline-flex items-center gap-2 whitespace-nowrap"
          >
            <Download className="w-4 h-4" />
            <span>{exporting ? 'Generating PDF...' : 'Download PDF Report'}</span>
          </button>
        </div>
      </div>

      {/* Report Document Preview */}
      <div className="rounded-2xl border border-slate-800 bg-[#111827] p-6 sm:p-8 space-y-8">
        {/* Report Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#60A5FA] font-medium">
              <FileText className="w-4 h-4" />
              <span>Academic Advisor Wellness Summary</span>
            </div>
            <h2 className="mt-1 font-display text-2xl font-bold text-[#F8FAFC]">
              DreamLog – SnoozeScience Report
            </h2>
            <p className="mt-1 text-xs text-[#94A3B8]">
              Student: <strong className="text-[#F8FAFC]">{settings.studentName}</strong> · Analysis Period:{' '}
              {periodLabel}
            </p>
          </div>
          <div className="text-left sm:text-right text-xs text-[#94A3B8]">
            <div>Generated: {generatedDate}</div>
            {analytics.hasDemoData && (
              <div className="mt-1 text-[#FBBF24]">Note: Dataset includes DEMO DATA entries</div>
            )}
          </div>
        </div>

        {/* 6 Core Report Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { label: 'Total Sleep', val: `${totalSleepHours.toFixed(1)}h` },
            { label: 'Avg Nightly Sleep', val: `${avgNightlySleep.toFixed(2)}h` },
            { label: 'Weekly Sleep Debt', val: `${analytics.weeklySleepDebt.toFixed(1)}h` },
            { label: 'Total Study Hours', val: `${totalStudyHours.toFixed(1)}h` },
            { label: 'Avg Focus Rating', val: `${analytics.averageFocusRating.toFixed(2)}/5` },
            {
              label: 'Pearson r',
              val:
                analytics.correlation.hasConfidence && analytics.correlation.r !== null
                  ? `${analytics.correlation.r >= 0 ? '+' : ''}${analytics.correlation.r.toFixed(2)}`
                  : 'n < 7',
            },
          ].map((m) => (
            <div key={m.label} className="rounded-lg border border-slate-800 bg-[#1E293B]/60 p-3.5">
              <div className="text-[11px] text-[#94A3B8]">{m.label}</div>
              <div className="mt-1 font-mono text-lg font-bold text-[#F8FAFC] tabular-nums">
                {m.val}
              </div>
            </div>
          ))}
        </div>

        {/* Embedded Live Charts */}
        <div ref={reportChartAreaRef} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-slate-800 bg-[#0F172A] p-4">
            <div className="h-64">
              <SleepFocusScatterChart correlation={analytics.correlation} />
            </div>
          </div>
          <div className="rounded-xl border border-slate-800 bg-[#0F172A] p-4">
            <h4 className="text-xs font-semibold text-[#F8FAFC] mb-2">
              Weekly Sleep vs. Study Focus Trend
            </h4>
            <div className="h-60">
              <SleepVsProductivityTrendChart series={analytics.dailySeries} />
            </div>
          </div>
        </div>

        {/* Findings & Recommendations */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-[#F8FAFC]">Summary of Findings</h3>
            <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
              {analytics.insights.weeklySummary}
            </p>
            <h4 className="text-xs font-semibold text-[#34D399] pt-2">Personalized Insights</h4>
            <ul className="space-y-1.5 text-xs text-[#CBD5E1]">
              {analytics.insights.positiveInsights.map((i, idx) => (
                <li key={idx}>• {i}</li>
              ))}
              {analytics.insights.improvementAreas.map((i, idx) => (
                <li key={`imp-${idx}`}>• {i}</li>
              ))}
            </ul>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              Sleep &amp; Study Optimization Recommendations
            </h3>
            <ul className="space-y-2 text-xs sm:text-sm text-[#CBD5E1]">
              {analytics.insights.sleepRecommendations.map((r, idx) => (
                <li key={idx}>• {r}</li>
              ))}
              {analytics.insights.studyRecommendations.map((r, idx) => (
                <li key={`st-${idx}`}>• {r}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="rounded-lg border border-slate-800 bg-[#0F172A]/80 p-4 text-xs text-[#94A3B8]">
          <strong className="text-[#CBD5E1]">Statistical Disclaimer:</strong> Observed correlation coefficients summarize linear trends in your recorded logs and do not claim or prove causation. The 8-hour sleep tracking baseline is a reference metric, not a medical diagnosis.
        </div>
      </div>
    </div>
  );
}

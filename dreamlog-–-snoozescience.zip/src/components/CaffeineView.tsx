import React, { useMemo, useState } from 'react';
import { Coffee, Info, Plus, Trash2 } from 'lucide-react';
import { api } from '../api/client.ts';
import {
  calculateRemainingCaffeine,
  estimateBedtimeCaffeine,
  formatShortDate,
  formatTime12h,
  getLocalDateStr,
  minutesToTimeStr,
  parseTimeToMinutes,
} from '../shared/math.ts';
import type { CaffeineLog, DailyMetricPoint } from '../shared/types.ts';
import { CaffeineTimelineChart } from './Charts.tsx';
import { ConfirmModal, EmptyState } from './ui.tsx';

const PRESETS: Array<{ label: string; type: 'Coffee' | 'Tea' | 'Other'; mg: number }> = [
  { label: 'Filter Coffee (95mg)', type: 'Coffee', mg: 95 },
  { label: 'Double Espresso (130mg)', type: 'Coffee', mg: 130 },
  { label: 'Green / Black Tea (45mg)', type: 'Tea', mg: 45 },
  { label: 'Matcha Latte (65mg)', type: 'Tea', mg: 65 },
  { label: 'Energy Drink (160mg)', type: 'Other', mg: 160 },
];

export function CaffeineView({
  logs,
  dailySeries,
  halfLifeHours,
  onDataChanged,
  onNotify,
}: {
  logs: CaffeineLog[];
  dailySeries: DailyMetricPoint[];
  halfLifeHours: number;
  onDataChanged: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const [date, setDate] = useState(getLocalDateStr(0));
  const [consumptionTime, setConsumptionTime] = useState('14:00');
  const [beverageType, setBeverageType] = useState<'Coffee' | 'Tea' | 'Other'>('Coffee');
  const [caffeineAmount, setCaffeineAmount] = useState('95');
  const [notes, setNotes] = useState('');
  const [targetBedtime, setTargetBedtime] = useState('23:30');
  const [selectedTimelineDate, setSelectedTimelineDate] = useState(getLocalDateStr(0));
  const [submitting, setSubmitting] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<CaffeineLog | null>(null);

  const activeDayLogs = useMemo(() => {
    const dayLogs = logs.filter((l) => l.date === selectedTimelineDate);
    if (dayLogs.length > 0) return dayLogs;
    // Fallback to most recent date with caffeine logs if today is empty
    const latestDate = logs[0]?.date;
    return latestDate ? logs.filter((l) => l.date === latestDate) : [];
  }, [logs, selectedTimelineDate]);

  const effectiveTimelineDate = activeDayLogs[0]?.date || selectedTimelineDate;

  const totalDayMg = useMemo(
    () => Math.round(activeDayLogs.reduce((acc, l) => acc + l.caffeineAmount, 0)),
    [activeDayLogs],
  );

  const bedtimeMg = useMemo(
    () => estimateBedtimeCaffeine(activeDayLogs, targetBedtime, halfLifeHours),
    [activeDayLogs, targetBedtime, halfLifeHours],
  );

  const timelinePoints = useMemo(() => {
    const bedMin = parseTimeToMinutes(targetBedtime);
    const bedHour = Number.isNaN(bedMin) ? 23 : Math.floor(bedMin / 60);
    const pts: Array<{ label: string; remainingMg: number; isBedtime: boolean }> = [];

    for (let h = 6; h <= 24; h++) {
      const checkMin = h * 60;
      let totalRem = 0;
      for (const l of activeDayLogs) {
        const cMin = parseTimeToMinutes(l.consumptionTime);
        if (Number.isNaN(cMin) || checkMin < cMin) continue;
        const elapsedHours = (checkMin - cMin) / 60;
        totalRem += calculateRemainingCaffeine(l.caffeineAmount, elapsedHours, halfLifeHours);
      }
      const displayHour = h === 24 ? '12 AM' : h === 12 ? '12 PM' : h > 12 ? `${h - 12} PM` : `${h} AM`;
      pts.push({
        label: displayHour,
        remainingMg: Math.round(totalRem * 10) / 10,
        isBedtime: h === bedHour,
      });
    }
    return pts;
  }, [activeDayLogs, targetBedtime, halfLifeHours]);

  // Caffeine timing vs sleep duration comparison across stored logs
  const caffeineSleepComparison = useMemo(() => {
    const withBoth = dailySeries.filter((d) => d.totalSleep > 0 && d.caffeineTotalMg > 0);
    const noCaf = dailySeries.filter((d) => d.totalSleep > 0 && d.caffeineTotalMg === 0);
    const highBed = withBoth.filter((d) => d.caffeineAtBedtimeMg >= 40);
    const lowBed = [...noCaf, ...withBoth.filter((d) => d.caffeineAtBedtimeMg < 40)];

    const avgHigh =
      highBed.length > 0
        ? Math.round((highBed.reduce((a, d) => a + d.totalSleep, 0) / highBed.length) * 100) / 100
        : null;
    const avgLow =
      lowBed.length > 0
        ? Math.round((lowBed.reduce((a, d) => a + d.totalSleep, 0) / lowBed.length) * 100) / 100
        : null;

    return { avgHigh, avgLow, highCount: highBed.length, lowCount: lowBed.length };
  }, [dailySeries]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const mg = Number(caffeineAmount);
    if (Number.isNaN(mg) || mg <= 0 || mg > 1000) {
      onNotify('error', 'Caffeine amount must be between 1 and 1000 mg.');
      return;
    }
    setSubmitting(true);
    try {
      await api.createCaffeineLog({
        date,
        beverageType,
        consumptionTime,
        caffeineAmount: mg,
        notes,
      });
      setSelectedTimelineDate(date);
      setNotes('');
      onNotify('success', `Logged ${mg}mg (${beverageType}) at ${formatTime12h(consumptionTime)}.`);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to save caffeine entry.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteCaffeineLog(deleteTarget.id);
      onNotify('info', 'Deleted caffeine intake record.');
      setDeleteTarget(null);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to delete caffeine log.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Estimate Disclaimer */}
      <div className="rounded-xl border border-slate-800 bg-[#111827] p-4 flex items-start gap-3">
        <Info className="w-5 h-5 text-[#FBBF24] shrink-0 mt-0.5" />
        <p className="text-xs sm:text-sm text-[#CBD5E1]">
          <strong className="text-[#F8FAFC]">Pharmacokinetic Estimate Notice:</strong> Remaining caffeine values are mathematical estimates using a configurable{' '}
          <strong className="font-mono text-[#FBBF24]">{halfLifeHours}-hour half-life</strong> (Remaining = Initial × 0.5^(t / {halfLifeHours})). Individual caffeine metabolism varies significantly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-4 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-4 h-fit"
        >
          <div className="flex items-center gap-2.5">
            <Coffee className="w-5 h-5 text-[#FBBF24]" />
            <h2 className="text-base font-semibold text-[#F8FAFC]">Log Caffeine Intake</h2>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="caf-date" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                Date
              </label>
              <input
                id="caf-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
              />
            </div>
            <div>
              <label htmlFor="caf-time" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                Time
              </label>
              <input
                id="caf-time"
                type="time"
                value={consumptionTime}
                onChange={(e) => setConsumptionTime(e.target.value)}
                required
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
              />
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-[#94A3B8] mb-1.5">Beverage Type</span>
            <div className="grid grid-cols-3 gap-2">
              {(['Coffee', 'Tea', 'Other'] as const).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setBeverageType(type)}
                  className={`py-2 rounded-lg text-xs font-medium border transition-colors ${
                    beverageType === type
                      ? 'bg-[#FBBF24] text-[#0F172A] border-[#FBBF24] font-semibold'
                      : 'bg-[#0F172A] text-[#94A3B8] border-slate-800 hover:text-[#F8FAFC]'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="caf-mg" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Estimated Caffeine (mg)
            </label>
            <input
              id="caf-mg"
              type="number"
              min="1"
              max="1000"
              value={caffeineAmount}
              onChange={(e) => setCaffeineAmount(e.target.value)}
              required
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
            <div className="mt-2 flex flex-wrap gap-1.5">
              {PRESETS.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => {
                    setBeverageType(p.type);
                    setCaffeineAmount(String(p.mg));
                  }}
                  className="px-2 py-1 rounded bg-[#0F172A] border border-slate-800 text-[11px] text-[#94A3B8] hover:text-[#F8FAFC]"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="caf-notes" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Notes (optional)
            </label>
            <input
              id="caf-notes"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g., Afternoon library session"
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 px-4 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] transition-colors inline-flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>{submitting ? 'Saving...' : 'Add Caffeine Log'}</span>
          </button>
        </form>

        {/* Visualization + Summary */}
        <div className="lg:col-span-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-4">
              <span className="text-xs text-[#94A3B8]">
                Daily Intake ({formatShortDate(effectiveTimelineDate)})
              </span>
              <div className="mt-1 font-mono text-2xl font-bold text-[#FBBF24] tabular-nums">
                {totalDayMg} mg
              </div>
              <p className="mt-1 text-xs text-[#94A3B8]">Total logged on selected day</p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-4">
              <div className="flex items-center justify-between text-xs text-[#94A3B8]">
                <span>Est. at Bedtime</span>
                <input
                  type="time"
                  value={targetBedtime}
                  onChange={(e) => setTargetBedtime(e.target.value)}
                  aria-label="Target bedtime for caffeine estimate"
                  className="bg-[#0F172A] border border-slate-700 rounded px-1.5 py-0.5 text-[11px] font-mono text-[#F8FAFC]"
                />
              </div>
              <div
                className={`mt-1 font-mono text-2xl font-bold tabular-nums ${
                  bedtimeMg >= 50 ? 'text-[#F87171]' : 'text-[#34D399]'
                }`}
              >
                {bedtimeMg.toFixed(1)} mg
              </div>
              <p className="mt-1 text-xs text-[#94A3B8]">Estimated residual at {formatTime12h(targetBedtime)}</p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-4">
              <span className="text-xs text-[#94A3B8]">Sleep Impact Observation</span>
              <div className="mt-1 font-mono text-lg font-bold text-[#60A5FA] tabular-nums">
                {caffeineSleepComparison.avgHigh !== null && caffeineSleepComparison.avgLow !== null
                  ? `${caffeineSleepComparison.avgLow.toFixed(2)}h vs ${caffeineSleepComparison.avgHigh.toFixed(2)}h`
                  : 'Collecting Pairs'}
              </div>
              <p className="mt-1 text-xs text-[#94A3B8]">
                Low bedtime caffeine (&lt;40mg) vs ≥40mg nights
              </p>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-base font-semibold text-[#F8FAFC]">
                  Estimated Caffeine Clearance Curve ({formatShortDate(effectiveTimelineDate)})
                </h3>
                <p className="text-xs text-[#94A3B8]">
                  Models exponential half-life decay across the day (marked at bedtime)
                </p>
              </div>
              <input
                type="date"
                value={effectiveTimelineDate}
                onChange={(e) => setSelectedTimelineDate(e.target.value)}
                aria-label="Select date for caffeine curve"
                className="rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-1.5 text-xs text-[#F8FAFC]"
              />
            </div>
            <div className="h-64">
              <CaffeineTimelineChart
                points={timelinePoints}
                bedtimeHourLabel={formatTime12h(minutesToTimeStr(parseTimeToMinutes(targetBedtime)))}
              />
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6">
            <h3 className="text-base font-semibold text-[#F8FAFC] mb-4">Caffeine Intake History</h3>
            {logs.length === 0 ? (
              <EmptyState
                icon={Coffee}
                title="No caffeine logs yet"
                description="Log coffee, tea, or other caffeinated drinks to inspect estimated bedtime caffeine levels."
              />
            ) : (
              <div className="divide-y divide-slate-800/70 max-h-64 overflow-y-auto">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="py-3 flex items-center justify-between gap-3 text-sm"
                  >
                    <div>
                      <div className="font-medium text-[#F8FAFC]">
                        {log.beverageType} ·{' '}
                        <span className="font-mono text-[#FBBF24]">{log.caffeineAmount}mg</span>
                      </div>
                      <div className="text-xs text-[#94A3B8]">
                        {formatShortDate(log.date)} at {formatTime12h(log.consumptionTime)}
                        {log.notes ? ` · ${log.notes}` : ''}
                        {log.isDemo ? ' · DEMO DATA' : ''}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(log)}
                      className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#F87171] hover:bg-slate-800"
                      aria-label="Delete caffeine log"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <ConfirmModal
        open={deleteTarget !== null}
        title="Delete Caffeine Entry"
        message="Remove this caffeine log from your dataset?"
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

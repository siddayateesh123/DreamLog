import React, { useMemo, useState } from 'react';
import { BookOpen, Edit3, Plus, Trash2 } from 'lucide-react';
import { api } from '../api/client.ts';
import {
  calculateTimeRangeHours,
  formatShortDate,
  getLocalDateStr,
} from '../shared/math.ts';
import { FOCUS_DESCRIPTIONS, type StudyLog, type SubjectStat } from '../shared/types.ts';
import { ConfirmModal, EmptyState } from './ui.tsx';

const SUGGESTED_SUBJECTS = [
  'Algorithms',
  'Linear Algebra',
  'Data Structures',
  'Operating Systems',
  'Organic Chemistry',
  'Macroeconomics',
];

export function StudyTrackerView({
  logs,
  subjectStats,
  onDataChanged,
  onNotify,
}: {
  logs: StudyLog[];
  subjectStats: SubjectStat[];
  onDataChanged: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [date, setDate] = useState(getLocalDateStr(0));
  const [subject, setSubject] = useState('Algorithms');
  const [studyHours, setStudyHours] = useState('4.5');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [focusRating, setFocusRating] = useState(5);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<StudyLog | null>(null);

  const weeklyStudyHours = useMemo(() => {
    const weekCutoff = getLocalDateStr(-6);
    const today = getLocalDateStr(0);
    return Math.round(
      logs
        .filter((l) => l.date >= weekCutoff && l.date <= today)
        .reduce((acc, l) => acc + l.studyHours, 0) * 100,
    ) / 100;
  }, [logs]);

  const meanFocus = useMemo(() => {
    if (logs.length === 0) return 0;
    return Math.round((logs.reduce((acc, l) => acc + l.focusRating, 0) / logs.length) * 100) / 100;
  }, [logs]);

  const handleTimeChange = (newStart: string, newEnd: string) => {
    setStartTime(newStart);
    setEndTime(newEnd);
    if (newStart && newEnd) {
      const calc = calculateTimeRangeHours(newStart, newEnd);
      if (calc >= 0.25 && calc <= 16) {
        setStudyHours(calc.toString());
      }
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setDate(getLocalDateStr(0));
    setSubject('Algorithms');
    setStudyHours('4.5');
    setStartTime('');
    setEndTime('');
    setFocusRating(5);
    setNotes('');
    setErrorMsg(null);
  };

  const handleEdit = (log: StudyLog) => {
    setEditingId(log.id);
    setDate(log.date);
    setSubject(log.subject);
    setStudyHours(String(log.studyHours));
    setStartTime(log.startTime || '');
    setEndTime(log.endTime || '');
    setFocusRating(log.focusRating);
    setNotes(log.notes || '');
    setErrorMsg(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const parsedHours = Number(studyHours);

    if (!subject.trim()) {
      setErrorMsg('Please enter a subject name.');
      return;
    }
    if (Number.isNaN(parsedHours) || parsedHours < 0.25 || parsedHours > 16) {
      setErrorMsg('Study duration must be between 0.25 and 16 hours.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        date,
        subject: subject.trim(),
        studyHours: parsedHours,
        focusRating,
        startTime,
        endTime,
        notes,
      };
      if (editingId !== null) {
        await api.updateStudyLog(editingId, payload);
        onNotify('success', `Updated ${subject.trim()} study session (${parsedHours}h).`);
      } else {
        await api.createStudyLog(payload);
        onNotify('success', `Logged ${parsedHours}h of ${subject.trim()} with ${focusRating}/5 focus.`);
      }
      resetForm();
      await onDataChanged();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to save study session.';
      setErrorMsg(msg);
      onNotify('error', msg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteStudyLog(deleteTarget.id);
      onNotify('info', `Deleted ${deleteTarget.subject} study session.`);
      if (editingId === deleteTarget.id) resetForm();
      setDeleteTarget(null);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to delete study session.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Quick Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-4">
          <span className="text-xs text-[#94A3B8]">Weekly Study Hours (7d)</span>
          <div className="mt-1 font-mono text-2xl font-bold text-[#60A5FA] tabular-nums">
            {weeklyStudyHours.toFixed(1)}h
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-4">
          <span className="text-xs text-[#94A3B8]">Overall Mean Focus</span>
          <div className="mt-1 font-mono text-2xl font-bold text-[#FBBF24] tabular-nums">
            {meanFocus.toFixed(2)}/5
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-4">
          <span className="text-xs text-[#94A3B8]">Total Sessions Recorded</span>
          <div className="mt-1 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {logs.length}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Study Logger Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-4 h-fit"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <BookOpen className="w-5 h-5 text-[#FBBF24]" />
              <h2 className="text-base font-semibold text-[#F8FAFC]">
                {editingId !== null ? 'Edit Study Session' : 'Log Study Session'}
              </h2>
            </div>
            {editingId !== null && (
              <button
                type="button"
                onClick={resetForm}
                className="text-xs text-[#94A3B8] hover:text-[#F8FAFC]"
              >
                Cancel Edit
              </button>
            )}
          </div>

          <div>
            <label htmlFor="study-date" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Date
            </label>
            <input
              id="study-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
          </div>

          <div>
            <label htmlFor="study-subject" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Subject Name
            </label>
            <input
              id="study-subject"
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g., Algorithms"
              required
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
            <div className="mt-2 flex flex-wrap gap-1.5">
              {SUGGESTED_SUBJECTS.map((sub) => (
                <button
                  key={sub}
                  type="button"
                  onClick={() => setSubject(sub)}
                  className={`px-2.5 py-1 rounded-md text-xs transition-colors ${
                    subject === sub
                      ? 'bg-[#60A5FA]/20 text-[#60A5FA] border border-[#60A5FA]/40'
                      : 'bg-[#0F172A] text-[#94A3B8] border border-slate-800 hover:text-[#F8FAFC]'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label htmlFor="study-hours" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                Duration (hrs)
              </label>
              <input
                id="study-hours"
                type="number"
                step="0.25"
                min="0.25"
                max="16"
                value={studyHours}
                onChange={(e) => setStudyHours(e.target.value)}
                required
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2.5 text-sm font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
              />
            </div>
            <div>
              <label htmlFor="study-start" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                Start (opt)
              </label>
              <input
                id="study-start"
                type="time"
                value={startTime}
                onChange={(e) => handleTimeChange(e.target.value, endTime)}
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-2.5 py-2.5 text-xs font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
              />
            </div>
            <div>
              <label htmlFor="study-end" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
                End (opt)
              </label>
              <input
                id="study-end"
                type="time"
                value={endTime}
                onChange={(e) => handleTimeChange(startTime, e.target.value)}
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-2.5 py-2.5 text-xs font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
              />
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-[#94A3B8] mb-2">
              Focus Rating: <strong className="text-[#FBBF24]">{focusRating}/5 – {FOCUS_DESCRIPTIONS[focusRating]}</strong>
            </span>
            <div className="grid grid-cols-5 gap-1.5">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  type="button"
                  onClick={() => setFocusRating(rating)}
                  className={`py-2 rounded-lg text-xs font-mono font-semibold border transition-colors ${
                    focusRating === rating
                      ? 'bg-[#FBBF24] text-[#0F172A] border-[#FBBF24]'
                      : 'bg-[#0F172A] text-[#94A3B8] border-slate-800 hover:border-slate-600'
                  }`}
                >
                  {rating}
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-[11px] text-[#94A3B8]">
              1 Very Poor · 2 Low · 3 Moderate · 4 Good · 5 Deep Focus
            </p>
          </div>

          <div>
            <label htmlFor="study-notes" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Optional Notes
            </label>
            <textarea
              id="study-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Topics covered, problem sets, or distractions"
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] placeholder:text-slate-500 focus:outline-none focus:border-[#60A5FA]"
            />
          </div>

          {errorMsg && (
            <p className="text-xs text-[#F87171] bg-[#F87171]/10 border border-[#F87171]/30 rounded-lg px-3 py-2">
              {errorMsg}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 px-4 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] disabled:opacity-50 transition-colors inline-flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>{submitting ? 'Saving...' : editingId !== null ? 'Update Study Session' : 'Save Study Session'}</span>
          </button>
        </form>

        {/* Subject Breakdown & Session History */}
        <div className="lg:col-span-7 space-y-6">
          {/* Subject-wise Breakdown */}
          <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6">
            <h3 className="text-base font-semibold text-[#F8FAFC] mb-4">Subject-Wise Study Breakdown</h3>
            {subjectStats.length === 0 ? (
              <p className="text-xs text-[#94A3B8]">No subject statistics available in this window.</p>
            ) : (
              <div className="space-y-3">
                {subjectStats.map((stat) => {
                  const maxHours = Math.max(...subjectStats.map((s) => s.totalHours), 1);
                  const pct = Math.round((stat.totalHours / maxHours) * 100);
                  return (
                    <div key={stat.subject}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-medium text-[#F8FAFC]">{stat.subject}</span>
                        <span className="font-mono text-[#94A3B8] tabular-nums">
                          {stat.totalHours.toFixed(1)}h · {stat.sessionsCount} session
                          {stat.sessionsCount === 1 ? '' : 's'} ·{' '}
                          <strong className="text-[#FBBF24]">{stat.averageFocus.toFixed(2)}/5</strong> focus
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-[#0F172A] overflow-hidden">
                        <div
                          className="h-full rounded-full bg-[#60A5FA]"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Study History Table */}
          <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6">
            <h3 className="text-base font-semibold text-[#F8FAFC] mb-4">Study Session History</h3>
            {logs.length === 0 ? (
              <EmptyState
                icon={BookOpen}
                title="No study sessions recorded"
                description="Log your first subject and focus rating to track productivity patterns."
              />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-xs font-medium text-[#94A3B8]">
                      <th className="py-2.5 pr-3">Date</th>
                      <th className="py-2.5 px-3">Subject</th>
                      <th className="py-2.5 px-3 text-right">Duration</th>
                      <th className="py-2.5 px-3 text-right">Focus</th>
                      <th className="py-2.5 pl-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/70 text-sm">
                    {logs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 pr-3 whitespace-nowrap">
                          <div className="font-medium text-[#F8FAFC]">{formatShortDate(log.date)}</div>
                          <div className="text-xs text-[#94A3B8]">
                            {log.date}
                            {log.isDemo ? ' · DEMO DATA' : ''}
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-medium text-[#F8FAFC]">{log.subject}</div>
                          {log.notes && (
                            <div className="text-xs text-[#94A3B8] truncate max-w-[210px]">
                              {log.notes}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-3 text-right whitespace-nowrap font-mono text-[#60A5FA] tabular-nums">
                          {log.studyHours.toFixed(2)}h
                        </td>
                        <td className="py-3 px-3 text-right whitespace-nowrap">
                          <span className="font-mono font-semibold text-[#FBBF24] tabular-nums">
                            {log.focusRating}/5
                          </span>
                        </td>
                        <td className="py-3 pl-3 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleEdit(log)}
                              className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#60A5FA] hover:bg-slate-800 transition-colors"
                              aria-label={`Edit study session ${log.subject}`}
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTarget(log)}
                              className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#F87171] hover:bg-slate-800 transition-colors"
                              aria-label={`Delete study session ${log.subject}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      <ConfirmModal
        open={deleteTarget !== null}
        title="Delete Study Session"
        message={`Remove the ${deleteTarget?.subject ?? ''} study session from ${deleteTarget ? formatShortDate(deleteTarget.date) : ''}?`}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

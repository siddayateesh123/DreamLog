import React, { useMemo, useState } from 'react';
import { AlarmClock, BedDouble, Info, Moon } from 'lucide-react';
import { calculateBedtimeCycles, formatHoursMinutes, formatTime12h } from '../shared/math.ts';

export function BedtimeView({ defaultWakeTime = '07:00' }: { defaultWakeTime?: string }) {
  const [wakeTime, setWakeTime] = useState(defaultWakeTime);
  const [fallAsleepMinutes, setFallAsleepMinutes] = useState(15);

  const options = useMemo(
    () => calculateBedtimeCycles(wakeTime, fallAsleepMinutes),
    [wakeTime, fallAsleepMinutes],
  );

  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-slate-800 bg-[#111827] p-4 flex items-start gap-3">
        <Info className="w-5 h-5 text-[#60A5FA] shrink-0 mt-0.5" />
        <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
          Sleep cycles vary between individuals. The 90-minute cycle is an approximation, not a precise biological timer. Prioritise sufficient and consistent sleep.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls */}
        <div className="lg:col-span-4 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5 h-fit">
          <div className="flex items-center gap-2.5">
            <AlarmClock className="w-5 h-5 text-[#60A5FA]" />
            <h2 className="text-base font-semibold text-[#F8FAFC]">
              90-Minute Sleep Cycle Calculator
            </h2>
          </div>

          <div>
            <label htmlFor="bedtime-wake" className="block text-xs font-medium text-[#94A3B8] mb-1.5">
              Desired Wake-up Time
            </label>
            <input
              id="bedtime-wake"
              type="time"
              value={wakeTime}
              onChange={(e) => setWakeTime(e.target.value)}
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-base font-mono text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs font-medium text-[#94A3B8] mb-2">
              <label htmlFor="sleep-latency">Estimated Time to Fall Asleep</label>
              <span className="font-mono text-[#60A5FA] tabular-nums">{fallAsleepMinutes} min</span>
            </div>
            <input
              id="sleep-latency"
              type="range"
              min="0"
              max="60"
              step="5"
              value={fallAsleepMinutes}
              onChange={(e) => setFallAsleepMinutes(Number(e.target.value))}
              className="w-full accent-[#60A5FA]"
            />
            <div className="flex justify-between text-[11px] text-[#94A3B8] mt-1 font-mono">
              <span>0m</span>
              <span>15m</span>
              <span>30m</span>
              <span>45m</span>
              <span>60m</span>
            </div>
          </div>

          <div className="rounded-lg bg-[#0F172A]/80 border border-slate-800 p-4 text-xs text-[#94A3B8] leading-relaxed">
            If you need to wake up at{' '}
            <strong className="text-[#F8FAFC] font-mono">{formatTime12h(wakeTime)}</strong> and take{' '}
            <strong className="text-[#F8FAFC] font-mono">{fallAsleepMinutes} minutes</strong> to drift off, aim to be in bed at one of the recommended times on the right.
          </div>
        </div>

        {/* Bedtime Options */}
        <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {options.map((opt) => (
            <div
              key={opt.cycles}
              className={`rounded-xl border p-6 flex flex-col justify-between transition-colors ${
                opt.recommended
                  ? 'border-[#60A5FA]/50 bg-[#1E293B]'
                  : 'border-slate-800 bg-[#1E293B]/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-[#94A3B8]">
                    {opt.cycles} × 90-min Cycles
                  </span>
                  {opt.recommended ? (
                    <span className="text-xs font-semibold text-[#34D399]">Recommended</span>
                  ) : (
                    <span className="text-xs text-[#F59E0B]">Short Recovery</span>
                  )}
                </div>

                <div className="mt-3 flex items-baseline gap-3">
                  <span className="font-mono text-3xl font-bold text-[#F8FAFC] tabular-nums">
                    {formatTime12h(opt.getInBedTime)}
                  </span>
                  <span className="text-xs text-[#94A3B8]">lights out</span>
                </div>

                <p className="mt-2 text-xs text-[#94A3B8]">
                  Estimated sleep onset:{' '}
                  <span className="font-mono text-[#CBD5E1]">{formatTime12h(opt.fallAsleepTime)}</span>
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-[#CBD5E1] flex items-center gap-1.5">
                  <BedDouble className="w-4 h-4 text-[#60A5FA]" />
                  <span>{opt.label}</span>
                </span>
                <span className="font-mono font-semibold text-[#60A5FA] tabular-nums flex items-center gap-1">
                  <Moon className="w-3.5 h-3.5" />
                  {formatHoursMinutes(opt.sleepHours)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

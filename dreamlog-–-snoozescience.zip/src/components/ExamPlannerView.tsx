import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Calendar,
  CheckSquare,
  Clock,
  Plus,
  ShieldCheck,
  Square,
  Trash2,
} from 'lucide-react';
import { api } from '../api/client.ts';
import { formatShortDate, formatTime12h, getLocalDateStr, getWeekdayName } from '../shared/math.ts';
import type { ExamPlanTask, ExamPriority, ExamSchedule, UserSettings } from '../shared/types.ts';
import { ConfirmModal, EmptyState } from './ui.tsx';

export function ExamPlannerView({
  exams,
  tasks,
  settings,
  onDataChanged,
  onNotify,
}: {
  exams: ExamSchedule[];
  tasks: ExamPlanTask[];
  settings: UserSettings;
  onDataChanged: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const [examDate, setExamDate] = useState(getLocalDateStr(5));
  const [subject, setSubject] = useState('');
  const [topics, setTopics] = useState('');
  const [priority, setPriority] = useState<ExamPriority>('High');
  const [estimatedHours, setEstimatedHours] = useState('6');
  const [dailyAvailableHours, setDailyAvailableHours] = useState(
    String(Math.min(8, settings.dailyAvailableHours || 7)),
  );
  const [preferredWakeTime, setPreferredWakeTime] = useState(settings.preferredWakeTime || '07:30');

  const [viewMode, setViewMode] = useState<'daily' | 'weekly' | 'checklist'>('daily');
  const [selectedDay, setSelectedDay] = useState<string>('');
  const [capacityWarning, setCapacityWarning] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [addingExam, setAddingExam] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ExamSchedule | null>(null);

  const uniqueDates = useMemo(
    () => Array.from(new Set(tasks.map((t) => t.date))).sort(),
    [tasks],
  );
  const activeDay = selectedDay && uniqueDates.includes(selectedDay) ? selectedDay : uniqueDates[0] || '';
  const dayTasks = useMemo(
    () => tasks.filter((t) => t.date === activeDay),
    [tasks, activeDay],
  );

  const studyTasksOnly = useMemo(() => tasks.filter((t) => t.type === 'study'), [tasks]);
  const completedCount = useMemo(
    () => studyTasksOnly.filter((t) => t.completed).length,
    [studyTasksOnly],
  );

  const handleAddExam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) {
      onNotify('error', 'Please enter an exam subject.');
      return;
    }
    setAddingExam(true);
    try {
      await api.createExam({
        examDate,
        subject: subject.trim(),
        topics: topics.trim() || `${subject.trim()} Core Review`,
        priority,
        estimatedHours: Math.max(1, Math.min(40, Number(estimatedHours) || 6)),
      });
      setSubject('');
      setTopics('');
      onNotify('success', `Added ${subject.trim()} exam on ${formatShortDate(examDate)}.`);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to add exam.');
    } finally {
      setAddingExam(false);
    }
  };

  const handleGeneratePlan = async () => {
    const requestedDaily = Number(dailyAvailableHours) || 7;
    if (requestedDaily > 8) {
      onNotify(
        'info',
        'Daily study is automatically capped at 8 hours to preserve restorative sleep.',
      );
    }
    setGenerating(true);
    try {
      const res = await api.generateExamPlan({
        dailyAvailableHours: Math.min(8, Math.max(1, requestedDaily)),
        preferredWakeTime,
      });
      setCapacityWarning(res.capacityWarning);
      if (res.tasks[0]) setSelectedDay(res.tasks[0].date);
      onNotify(
        'success',
        `Generated sleep-protected schedule (${res.totalScheduledHours}h study across ${res.daysPlanned} days).`,
      );
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to generate timetable.');
    } finally {
      setGenerating(false);
    }
  };

  const handleToggleTask = async (task: ExamPlanTask) => {
    try {
      await api.updateExamPlanTask(task.id, { completed: !task.completed });
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to update task.');
    }
  };

  const handleConfirmDeleteExam = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteExam(deleteTarget.id);
      onNotify('info', `Removed ${deleteTarget.subject} exam.`);
      setDeleteTarget(null);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to delete exam.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Mandatory Constraints Banner */}
      <div className="rounded-xl border border-[#34D399]/30 bg-[#1E293B]/80 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-[#34D399] shrink-0 mt-0.5" />
          <div>
            <h2 className="text-sm font-semibold text-[#F8FAFC]">
              Exam Week Sleep Preserver — Protective Invariants Active
            </h2>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              Enforces a maximum of 8 hours of daily study, reserves at least 7 hours for nightly sleep, and protects meal &amp; recovery breaks without overlapping sessions.
            </p>
          </div>
        </div>
        <div className="font-mono text-xs text-[#34D399] shrink-0 tabular-nums">
          {completedCount}/{studyTasksOnly.length} tasks completed
        </div>
      </div>

      {capacityWarning && (
        <div className="rounded-xl border border-[#F59E0B]/40 bg-[#F59E0B]/10 p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#FBBF24] shrink-0 mt-0.5" />
          <p className="text-xs sm:text-sm text-[#FBBF24] leading-relaxed">{capacityWarning}</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Add Exams & Generator Controls */}
        <div className="lg:col-span-4 space-y-6">
          <form
            onSubmit={handleAddExam}
            className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 space-y-3.5"
          >
            <h3 className="text-sm font-semibold text-[#F8FAFC]">Add Exam &amp; Topics</h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="exam-date" className="block text-xs text-[#94A3B8] mb-1">
                  Exam Date
                </label>
                <input
                  id="exam-date"
                  type="date"
                  value={examDate}
                  onChange={(e) => setExamDate(e.target.value)}
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                />
              </div>
              <div>
                <label htmlFor="exam-priority" className="block text-xs text-[#94A3B8] mb-1">
                  Priority
                </label>
                <select
                  id="exam-priority"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as ExamPriority)}
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                >
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label htmlFor="exam-subject" className="block text-xs text-[#94A3B8] mb-1">
                  Subject
                </label>
                <input
                  id="exam-subject"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g., Data Structures"
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                />
              </div>
              <div>
                <label htmlFor="exam-hours" className="block text-xs text-[#94A3B8] mb-1">
                  Est. Hours
                </label>
                <input
                  id="exam-hours"
                  type="number"
                  min="1"
                  max="40"
                  value={estimatedHours}
                  onChange={(e) => setEstimatedHours(e.target.value)}
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                />
              </div>
            </div>

            <div>
              <label htmlFor="exam-topics" className="block text-xs text-[#94A3B8] mb-1">
                Study Topics (comma-separated)
              </label>
              <input
                id="exam-topics"
                type="text"
                value={topics}
                onChange={(e) => setTopics(e.target.value)}
                placeholder="Trees, Graph BFS/DFS, Hashing"
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
              />
            </div>

            <button
              type="submit"
              disabled={addingExam}
              className="w-full py-2 px-4 rounded-lg bg-[#111827] border border-slate-700 text-xs font-semibold text-[#F8FAFC] hover:border-[#60A5FA] transition-colors inline-flex items-center justify-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5 text-[#60A5FA]" />
              <span>{addingExam ? 'Adding...' : 'Add Exam Target'}</span>
            </button>
          </form>

          {/* Upcoming Exams List + Schedule Generator */}
          <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 space-y-4">
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              Upcoming Exams ({exams.length})
            </h3>
            {exams.length === 0 ? (
              <p className="text-xs text-[#94A3B8]">Add at least one exam above to generate a plan.</p>
            ) : (
              <div className="space-y-2.5">
                {exams.map((ex) => (
                  <div
                    key={ex.id}
                    className="rounded-lg bg-[#0F172A]/70 border border-slate-800 p-3 flex items-start justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-[#F8FAFC] truncate">
                        {ex.subject}{' '}
                        <span
                          className={`ml-1 ${
                            ex.priority === 'High'
                              ? 'text-[#F87171]'
                              : ex.priority === 'Medium'
                                ? 'text-[#FBBF24]'
                                : 'text-[#34D399]'
                          }`}
                        >
                          · {ex.priority}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#94A3B8] mt-0.5">
                        {formatShortDate(ex.examDate)} · {ex.estimatedHours}h target
                      </div>
                      <div className="text-[11px] text-[#94A3B8] truncate">{ex.topics}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(ex)}
                      className="p-1 text-[#94A3B8] hover:text-[#F87171]"
                      aria-label={`Delete ${ex.subject}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-3 border-t border-slate-800 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="plan-daily-hrs" className="block text-xs text-[#94A3B8] mb-1">
                    Daily Study Cap (≤8h)
                  </label>
                  <input
                    id="plan-daily-hrs"
                    type="number"
                    min="1"
                    max="8"
                    step="0.5"
                    value={dailyAvailableHours}
                    onChange={(e) => setDailyAvailableHours(e.target.value)}
                    className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                  />
                </div>
                <div>
                  <label htmlFor="plan-wake" className="block text-xs text-[#94A3B8] mb-1">
                    Wake-up Time
                  </label>
                  <input
                    id="plan-wake"
                    type="time"
                    value={preferredWakeTime}
                    onChange={(e) => setPreferredWakeTime(e.target.value)}
                    className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                  />
                </div>
              </div>

              <button
                type="button"
                disabled={generating || exams.length === 0}
                onClick={handleGeneratePlan}
                className="w-full py-2.5 px-4 rounded-lg bg-[#60A5FA] text-[#0F172A] text-xs font-semibold hover:bg-[#93C5FD] disabled:opacity-50 transition-colors"
              >
                {generating ? 'Building Schedule...' : 'Generate Protective Timetable'}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Timetable Views */}
        <div className="lg:col-span-8 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="text-base font-semibold text-[#F8FAFC]">Protective Study Timetable</h3>

            <div className="flex items-center gap-1 p-1 bg-[#0F172A] border border-slate-800 rounded-lg">
              {(
                [
                  { id: 'daily', label: 'Daily Schedule' },
                  { id: 'weekly', label: 'Weekly Calendar' },
                  { id: 'checklist', label: 'Task Checklist' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setViewMode(tab.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    viewMode === tab.id
                      ? 'bg-[#60A5FA] text-[#0F172A] font-semibold'
                      : 'text-[#94A3B8] hover:text-[#F8FAFC]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {tasks.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="No timetable generated yet"
              description="Add your exam subjects on the left and click Generate Protective Timetable."
            />
          ) : viewMode === 'daily' ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {uniqueDates.map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setSelectedDay(d)}
                    className={`px-3 py-1.5 rounded-lg text-xs border transition-colors whitespace-nowrap shrink-0 ${
                      activeDay === d
                        ? 'bg-[#60A5FA]/20 border-[#60A5FA] text-[#F8FAFC] font-semibold'
                        : 'bg-[#0F172A] border-slate-800 text-[#94A3B8] hover:text-[#F8FAFC]'
                    }`}
                  >
                    {getWeekdayName(d).slice(0, 3)} · {formatShortDate(d)}
                  </button>
                ))}
              </div>

              <div className="divide-y divide-slate-800/80">
                {dayTasks.map((t) => (
                  <div key={t.id} className="py-3 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 min-w-0">
                      {t.type === 'study' ? (
                        <button
                          type="button"
                          onClick={() => handleToggleTask(t)}
                          className="text-[#60A5FA] hover:text-[#93C5FD] shrink-0"
                          aria-label={`Mark ${t.title} complete`}
                        >
                          {t.completed ? (
                            <CheckSquare className="w-4 h-4 text-[#34D399]" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      ) : (
                        <Clock className="w-4 h-4 text-[#94A3B8] shrink-0" />
                      )}
                      <div className="min-w-0">
                        <div
                          className={`text-sm font-medium truncate ${
                            t.completed
                              ? 'line-through text-[#94A3B8]'
                              : t.type === 'sleep'
                                ? 'text-[#60A5FA]'
                                : t.type === 'meal' || t.type === 'break'
                                  ? 'text-[#34D399]'
                                  : 'text-[#F8FAFC]'
                          }`}
                        >
                          {t.title}
                        </div>
                        <div className="text-xs text-[#94A3B8] capitalize">
                          {t.type} · {t.subject}
                        </div>
                      </div>
                    </div>
                    <div className="font-mono text-xs text-[#CBD5E1] shrink-0 tabular-nums">
                      {formatTime12h(t.startTime)} – {formatTime12h(t.endTime)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : viewMode === 'weekly' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[540px] overflow-y-auto pr-1">
              {uniqueDates.slice(0, 7).map((d) => {
                const items = tasks.filter((t) => t.date === d);
                return (
                  <div key={d} className="rounded-lg border border-slate-800 bg-[#0F172A]/70 p-4">
                    <div className="text-xs font-semibold text-[#F8FAFC] mb-2.5 flex items-center justify-between">
                      <span>
                        {getWeekdayName(d)} · {formatShortDate(d)}
                      </span>
                      <span className="font-mono text-[#60A5FA]">
                        {items.filter((i) => i.type === 'study').length} study blocks
                      </span>
                    </div>
                    <div className="space-y-1.5 text-xs">
                      {items.map((i) => (
                        <div key={i.id} className="flex items-center justify-between gap-2">
                          <span
                            className={`truncate ${
                              i.type === 'sleep'
                                ? 'text-[#60A5FA]'
                                : i.type === 'study'
                                  ? 'text-[#F8FAFC]'
                                  : 'text-[#94A3B8]'
                            }`}
                          >
                            {i.title}
                          </span>
                          <span className="font-mono text-[11px] text-[#94A3B8] shrink-0">
                            {i.startTime}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80 max-h-[520px] overflow-y-auto">
              {studyTasksOnly.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => handleToggleTask(t)}
                  className="w-full py-3 flex items-center justify-between gap-3 text-left hover:bg-slate-800/30 px-2 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {t.completed ? (
                      <CheckSquare className="w-4 h-4 text-[#34D399] shrink-0" />
                    ) : (
                      <Square className="w-4 h-4 text-[#60A5FA] shrink-0" />
                    )}
                    <div className="min-w-0">
                      <div
                        className={`text-sm font-medium truncate ${
                          t.completed ? 'line-through text-[#94A3B8]' : 'text-[#F8FAFC]'
                        }`}
                      >
                        {t.title}
                      </div>
                      <div className="text-xs text-[#94A3B8]">
                        {formatShortDate(t.date)} · {formatTime12h(t.startTime)} – {formatTime12h(t.endTime)}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <ConfirmModal
        open={deleteTarget !== null}
        title="Remove Exam Target"
        message={`Delete ${deleteTarget?.subject ?? ''} exam from your exam list?`}
        onConfirm={handleConfirmDeleteExam}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

import React, { useEffect, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, Info, Star, X, XCircle } from 'lucide-react';

export function AnimatedNumber({
  value,
  decimals = 1,
  prefix = '',
  suffix = '',
  className = '',
}: {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  className?: string;
}) {
  const [display, setDisplay] = useState(value);
  const prevRef = useRef(value);

  useEffect(() => {
    const start = prevRef.current;
    const end = value;
    if (Math.abs(start - end) < 0.001) {
      setDisplay(end);
      return;
    }
    const duration = 380;
    const startTime = performance.now();
    let frameId = 0;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(start + (end - start) * eased);
      if (t < 1) {
        frameId = requestAnimationFrame(tick);
      } else {
        prevRef.current = end;
      }
    };

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId);
  }, [value]);

  const formatted = Number.isFinite(display) ? display.toFixed(decimals) : '0';
  return (
    <span className={`tabular-nums ${className}`}>
      {prefix}
      {formatted}
      {suffix}
    </span>
  );
}

export function StarRatingInput({
  value,
  onChange,
  label,
}: {
  value: number;
  onChange: (val: number) => void;
  label?: string;
}) {
  return (
    <div className="flex items-center gap-1.5" role="radiogroup" aria-label={label || 'Rating'}>
      {[1, 2, 3, 4, 5].map((star) => {
        const active = star <= value;
        return (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="p-1.5 rounded-lg transition-transform hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            aria-label={`${star} out of 5`}
            aria-checked={value === star}
            role="radio"
          >
            <Star
              className={`w-5 h-5 transition-colors ${
                active
                  ? 'fill-[#FBBF24] text-[#FBBF24]'
                  : 'text-[#475569] hover:text-[#94A3B8]'
              }`}
            />
          </button>
        );
      })}
      <span className="ml-2 text-xs font-mono tabular-nums text-[#94A3B8]">{value}/5</span>
    </div>
  );
}

export function ConfirmModal({
  open,
  title,
  message,
  confirmLabel = 'Confirm Delete',
  variant = 'danger',
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  variant?: 'danger' | 'primary';
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-modal-title"
    >
      <div className="w-full max-w-md rounded-xl bg-[#1E293B] border border-slate-700/80 p-6 shadow-2xl">
        <div className="flex items-start gap-3">
          <div
            className={`p-2 rounded-lg shrink-0 ${
              variant === 'danger' ? 'bg-[#F87171]/15 text-[#F87171]' : 'bg-[#60A5FA]/15 text-[#60A5FA]'
            }`}
          >
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <h3 id="confirm-modal-title" className="text-base font-semibold text-[#F8FAFC]">
              {title}
            </h3>
            <p className="mt-1.5 text-sm text-[#94A3B8] leading-relaxed">{message}</p>
          </div>
        </div>
        <div className="mt-6 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-sm font-medium text-[#94A3B8] hover:text-[#F8FAFC] rounded-lg border border-slate-700 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              variant === 'danger'
                ? 'bg-[#F87171] text-[#0F172A] hover:bg-[#FCA5A5]'
                : 'bg-[#60A5FA] text-[#0F172A] hover:bg-[#93C5FD]'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

export interface ToastItem {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

export function ToastList({
  toasts,
  onDismiss,
}: {
  toasts: ToastItem[];
  onDismiss: (id: string) => void;
}) {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="pointer-events-auto flex items-start gap-3 rounded-xl bg-[#1E293B] border border-slate-700/80 px-4 py-3 shadow-xl"
          role="status"
        >
          {t.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#34D399] shrink-0 mt-0.5" />}
          {t.type === 'error' && <XCircle className="w-5 h-5 text-[#F87171] shrink-0 mt-0.5" />}
          {t.type === 'info' && <Info className="w-5 h-5 text-[#60A5FA] shrink-0 mt-0.5" />}
          <p className="text-sm text-[#F8FAFC] flex-1 leading-snug">{t.message}</p>
          <button
            type="button"
            onClick={() => onDismiss(t.id)}
            className="text-[#94A3B8] hover:text-[#F8FAFC] p-0.5"
            aria-label="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div className="rounded-xl border border-slate-800 bg-[#1E293B]/60 p-10 text-center flex flex-col items-center justify-center">
      <div className="w-12 h-12 rounded-xl bg-[#60A5FA]/10 border border-[#60A5FA]/20 flex items-center justify-center text-[#60A5FA] mb-4">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-base font-semibold text-[#F8FAFC]">{title}</h3>
      <p className="mt-1.5 text-sm text-[#94A3B8] max-w-md leading-relaxed">{description}</p>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="mt-5 px-4 py-2 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] transition-colors whitespace-nowrap shrink-0"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

export function DashboardSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-28 rounded-xl bg-[#1E293B]/80 border border-slate-800" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="h-80 rounded-xl bg-[#1E293B]/80 border border-slate-800" />
        <div className="h-80 rounded-xl bg-[#1E293B]/80 border border-slate-800" />
      </div>
    </div>
  );
}

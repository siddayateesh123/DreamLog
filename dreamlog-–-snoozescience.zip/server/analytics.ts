import {
  computeCorrelationAnalysis,
  estimateBedtimeCaffeine,
  getLocalDateStr,
  getWeekdayName,
} from '../src/shared/math.ts';
import type {
  ActivityItem,
  CaffeineLog,
  DailyMetricPoint,
  DashboardAnalytics,
  SleepDebtSummary,
  SleepLog,
  StudyLog,
  SubjectStat,
  WeeklyInsights,
} from '../src/shared/types.ts';
import { db, getUserSettings } from './db.ts';

function fetchAllRecords() {
  const sleepLogs = db
    .prepare('SELECT * FROM sleep_logs ORDER BY date DESC, id DESC')
    .all() as Array<Omit<SleepLog, 'isDemo'> & { isDemo: number }>;

  const studyLogs = db
    .prepare('SELECT * FROM study_logs ORDER BY date DESC, id DESC')
    .all() as Array<Omit<StudyLog, 'isDemo'> & { isDemo: number }>;

  const caffeineLogs = db
    .prepare('SELECT * FROM caffeine_logs ORDER BY date DESC, consumptionTime DESC, id DESC')
    .all() as Array<Omit<CaffeineLog, 'isDemo'> & { isDemo: number }>;

  return {
    sleepLogs: sleepLogs.map((r) => ({ ...r, isDemo: Boolean(r.isDemo) })),
    studyLogs: studyLogs.map((r) => ({ ...r, isDemo: Boolean(r.isDemo) })),
    caffeineLogs: caffeineLogs.map((r) => ({ ...r, isDemo: Boolean(r.isDemo) })),
  };
}

function buildDailySeries(daysWindow: number): {
  series: DailyMetricPoint[];
  allSeries: DailyMetricPoint[];
  latestEntryDate: string | null;
  sleepLogs: SleepLog[];
  studyLogs: StudyLog[];
  caffeineLogs: CaffeineLog[];
} {
  const settings = getUserSettings();
  const baseline = settings.sleepBaselineHours || 8;
  const halfLife = settings.caffeineHalfLifeHours || 5;

  const { sleepLogs, studyLogs, caffeineLogs } = fetchAllRecords();

  const allDates = new Set<string>();
  for (const s of sleepLogs) allDates.add(s.date);
  for (const st of studyLogs) allDates.add(st.date);
  for (const c of caffeineLogs) allDates.add(c.date);

  const sortedAllDates = Array.from(allDates).sort();

  // Determine the latest date modified/added by the user (non-demo preferred, else latest)
  let latestEntryDate: string | null = null;
  const nonDemoSleep = sleepLogs.filter((s) => !s.isDemo);
  const nonDemoStudy = studyLogs.filter((s) => !s.isDemo);
  if (nonDemoSleep.length > 0 || nonDemoStudy.length > 0) {
    const combined = [...nonDemoSleep, ...nonDemoStudy].sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt),
    );
    latestEntryDate = combined[0]?.date ?? null;
  }

  const buildPoint = (date: string): DailyMetricPoint => {
    const daySleeps = sleepLogs.filter((s) => s.date === date);
    const dayStudies = studyLogs.filter((s) => s.date === date);
    const dayCaffeines = caffeineLogs.filter((c) => c.date === date);

    const totalSleep = Math.round(daySleeps.reduce((sum, s) => sum + s.duration, 0) * 100) / 100;
    const primarySleep = daySleeps[0] ?? null;
    const sleepQuality =
      daySleeps.length > 0
        ? Math.round((daySleeps.reduce((sum, s) => sum + s.sleepQuality, 0) / daySleeps.length) * 10) / 10
        : null;

    const totalStudyHours =
      Math.round(dayStudies.reduce((sum, s) => sum + s.studyHours, 0) * 100) / 100;
    const averageFocus =
      dayStudies.length > 0
        ? Math.round((dayStudies.reduce((sum, s) => sum + s.focusRating, 0) / dayStudies.length) * 100) / 100
        : null;

    const subjects = Array.from(new Set(dayStudies.map((s) => s.subject)));
    const sleepDebt =
      totalSleep > 0 ? Math.max(0, Math.round((baseline - totalSleep) * 100) / 100) : 0;

    const caffeineTotalMg = Math.round(dayCaffeines.reduce((sum, c) => sum + c.caffeineAmount, 0));
    const targetBedtime = primarySleep?.bedtime ?? '23:30';
    const caffeineAtBedtimeMg = estimateBedtimeCaffeine(dayCaffeines, targetBedtime, halfLife);

    const isDemo =
      (daySleeps.length > 0 && daySleeps.every((s) => s.isDemo)) ||
      (dayStudies.length > 0 && dayStudies.every((s) => s.isDemo) && daySleeps.length === 0);

    return {
      date,
      totalSleep,
      sleepQuality,
      bedtime: primarySleep?.bedtime ?? null,
      wakeTime: primarySleep?.wakeTime ?? null,
      totalStudyHours,
      averageFocus,
      studySessionsCount: dayStudies.length,
      subjects,
      sleepDebt,
      caffeineTotalMg,
      caffeineAtBedtimeMg,
      isDemo,
      hasPairedData: totalSleep > 0 && averageFocus !== null && dayStudies.length > 0,
      latestUpdated: latestEntryDate !== null && date === latestEntryDate,
    };
  };

  const allSeries = sortedAllDates.map(buildPoint);

  // Filter to the requested trailing window anchored from today (or latest date if future-dated)
  const todayStr = getLocalDateStr(0);
  const cutoffStr = getLocalDateStr(-(daysWindow - 1));
  const series = allSeries.filter((p) => p.date >= cutoffStr && p.date <= todayStr);

  return { series, allSeries, latestEntryDate, sleepLogs, studyLogs, caffeineLogs };
}

export function computeSleepDebtSummary(
  series: DailyMetricPoint[],
  allSeries: DailyMetricPoint[],
): SleepDebtSummary {
  const settings = getUserSettings();
  const baseline = settings.sleepBaselineHours || 8;
  const baselineDisclaimer = `Calculated against your ${baseline}-hour personal tracking baseline (not a medical diagnosis or universal sleep prescription).`;

  const sleepDays = series.filter((d) => d.totalSleep > 0);
  const todayStr = getLocalDateStr(0);
  const weekCutoff = getLocalDateStr(-6);
  const last7SleepDays = allSeries.filter(
    (d) => d.date >= weekCutoff && d.date <= todayStr && d.totalSleep > 0,
  );

  const weeklyCumulativeDebt =
    Math.round(last7SleepDays.reduce((acc, d) => acc + Math.max(0, baseline - d.totalSleep), 0) * 100) /
    100;
  const periodTotalDebt =
    Math.round(sleepDays.reduce((acc, d) => acc + Math.max(0, baseline - d.totalSleep), 0) * 100) /
    100;

  const averageNightlySleep =
    sleepDays.length > 0
      ? Math.round((sleepDays.reduce((acc, d) => acc + d.totalSleep, 0) / sleepDays.length) * 100) / 100
      : 0;

  const goalCompletionPercent =
    sleepDays.length > 0 ? Math.min(100, Math.round((averageNightlySleep / baseline) * 100)) : 0;

  let sleepStdDevHours = 0;
  let consistencyStatus: SleepDebtSummary['consistencyStatus'] = 'Building Baseline';

  if (sleepDays.length >= 3) {
    const mean = sleepDays.reduce((acc, d) => acc + d.totalSleep, 0) / sleepDays.length;
    const variance =
      sleepDays.reduce((acc, d) => acc + Math.pow(d.totalSleep - mean, 2), 0) / sleepDays.length;
    sleepStdDevHours = Math.round(Math.sqrt(variance) * 100) / 100;

    if (sleepStdDevHours <= 0.65) consistencyStatus = 'Consistent';
    else if (sleepStdDevHours <= 1.25) consistencyStatus = 'Moderate Variance';
    else consistencyStatus = 'Inconsistent';
  }

  const dailyBreakdown = sleepDays.map((d) => ({
    date: d.date,
    actualSleep: d.totalSleep,
    debt: Math.max(0, Math.round((baseline - d.totalSleep) * 100) / 100),
    surplus: Math.max(0, Math.round((d.totalSleep - baseline) * 100) / 100),
  }));

  const recommendations: string[] = [];
  if (sleepDays.length === 0) {
    recommendations.push('Log at least 3 nights of sleep to compute your weekly sleep debt and consistency.');
  } else {
    if (weeklyCumulativeDebt >= 5) {
      recommendations.push(
        `You accumulated ${weeklyCumulativeDebt.toFixed(1)}h of sleep debt over the last 7 days. Aim to add 30–45 minutes to your bedtime over the next few nights rather than sleeping in excessively on one day.`,
      );
    } else if (weeklyCumulativeDebt > 0) {
      recommendations.push(
        `Your 7-day sleep debt is modest at ${weeklyCumulativeDebt.toFixed(1)}h. Holding a steady wake-up time will keep you close to your ${baseline}h baseline.`,
      );
    } else {
      recommendations.push(
        `You met or exceeded your ${baseline}-hour tracking baseline across the past 7 logged days.`,
      );
    }

    if (consistencyStatus === 'Inconsistent') {
      recommendations.push(
        `Your nightly sleep duration varied by ±${sleepStdDevHours.toFixed(2)}h. Anchoring a consistent wake-up time stabilizes focus more effectively than irregular catch-up sleep.`,
      );
    } else if (consistencyStatus === 'Consistent') {
      recommendations.push(
        `Your sleep duration variance is tight (±${sleepStdDevHours.toFixed(2)}h), supporting steady circadian alertness.`,
      );
    }
  }

  return {
    baselineHours: baseline,
    baselineDisclaimer,
    weeklyCumulativeDebt,
    periodTotalDebt,
    averageNightlySleep,
    goalCompletionPercent,
    consistencyStatus,
    sleepStdDevHours,
    dailyBreakdown,
    recommendations,
  };
}

export function computeWeeklyInsights(
  series: DailyMetricPoint[],
  allSeries: DailyMetricPoint[],
  sleepDebt: SleepDebtSummary,
): WeeklyInsights {
  const positiveInsights: string[] = [];
  const improvementAreas: string[] = [];
  const sleepRecommendations: string[] = [];
  const studyRecommendations: string[] = [];

  const todayStr = getLocalDateStr(0);
  const thisWeekCutoff = getLocalDateStr(-6);
  const prevWeekStart = getLocalDateStr(-13);
  const prevWeekEnd = getLocalDateStr(-7);

  const thisWeek = allSeries.filter((d) => d.date >= thisWeekCutoff && d.date <= todayStr);
  const prevWeek = allSeries.filter((d) => d.date >= prevWeekStart && d.date <= prevWeekEnd);

  const pairedAll = series.filter((d) => d.hasPairedData);
  const wellRested = pairedAll.filter((d) => d.totalSleep >= 7.5);
  const underRested = pairedAll.filter((d) => d.totalSleep < 7.5);

  if (wellRested.length > 0 && underRested.length > 0) {
    const highFocus =
      wellRested.reduce((a, d) => a + (d.averageFocus as number), 0) / wellRested.length;
    const lowFocus =
      underRested.reduce((a, d) => a + (d.averageFocus as number), 0) / underRested.length;

    if (highFocus > lowFocus) {
      const pct = Math.round(((highFocus - lowFocus) / lowFocus) * 100);
      positiveInsights.push(
        `Days following 7.5+ hours of sleep showed ${pct}% higher average study focus (${highFocus.toFixed(2)}/5 vs ${lowFocus.toFixed(2)}/5).`,
      );
    } else {
      positiveInsights.push(
        `Average study focus was ${highFocus.toFixed(2)}/5 on 7.5+ hour nights compared with ${lowFocus.toFixed(2)}/5 on shorter nights.`,
      );
    }
  }

  // Peak efficiency day in last 7 days
  const thisWeekStudied = thisWeek.filter((d) => d.averageFocus !== null && d.totalStudyHours > 0);
  let peakEfficiencyDay: string | null = null;
  if (thisWeekStudied.length > 0) {
    const bestDay = [...thisWeekStudied].sort((a, b) => {
      const diff = (b.averageFocus ?? 0) - (a.averageFocus ?? 0);
      if (Math.abs(diff) > 0.01) return diff;
      return b.totalStudyHours - a.totalStudyHours;
    })[0];
    peakEfficiencyDay = getWeekdayName(bestDay.date);
    positiveInsights.push(
      `You studied most efficiently on ${peakEfficiencyDay} (${bestDay.averageFocus?.toFixed(1)}/5 focus across ${bestDay.totalStudyHours}h).`,
    );
  }

  // Week-over-week focus comparison
  const thisWeekFocusDays = thisWeek.filter((d) => d.averageFocus !== null);
  const prevWeekFocusDays = prevWeek.filter((d) => d.averageFocus !== null);
  let focusDeltaPercent: number | null = null;
  if (thisWeekFocusDays.length > 0 && prevWeekFocusDays.length > 0) {
    const curAvg =
      thisWeekFocusDays.reduce((a, d) => a + (d.averageFocus as number), 0) /
      thisWeekFocusDays.length;
    const prevAvg =
      prevWeekFocusDays.reduce((a, d) => a + (d.averageFocus as number), 0) /
      prevWeekFocusDays.length;
    if (prevAvg > 0) {
      focusDeltaPercent = Math.round(((curAvg - prevAvg) / prevAvg) * 100);
      if (focusDeltaPercent > 0) {
        positiveInsights.push(
          `Your average focus rating improved by ${focusDeltaPercent}% this week (${curAvg.toFixed(2)}/5 vs ${prevAvg.toFixed(2)}/5 last week).`,
        );
      } else if (focusDeltaPercent < 0) {
        improvementAreas.push(
          `Your average focus rating dipped by ${Math.abs(focusDeltaPercent)}% compared with last week (${curAvg.toFixed(2)}/5 vs ${prevAvg.toFixed(2)}/5).`,
        );
      }
    }
  }

  // Baseline comparison for this week
  const thisWeekSleeps = thisWeek.filter((d) => d.totalSleep > 0);
  const settings = getUserSettings();
  const baseline = settings.sleepBaselineHours || 8;
  if (thisWeekSleeps.length > 0) {
    const weekSleepAvg =
      thisWeekSleeps.reduce((a, d) => a + d.totalSleep, 0) / thisWeekSleeps.length;
    const diff = Math.round((baseline - weekSleepAvg) * 100) / 100;
    if (diff > 0.25) {
      improvementAreas.push(
        `Your average sleep this week (${weekSleepAvg.toFixed(2)}h) was ${diff.toFixed(2)}h below your ${baseline}-hour tracking baseline.`,
      );
      sleepRecommendations.push(
        `Shift lights-out 30 minutes earlier to close the ${diff.toFixed(1)}h nightly gap toward your ${baseline}h baseline.`,
      );
    } else {
      positiveInsights.push(
        `Your weekly sleep averaged ${weekSleepAvg.toFixed(2)}h, tracking right alongside your ${baseline}-hour baseline.`,
      );
      sleepRecommendations.push(
        `Keep protecting your current wind-down window to maintain ${weekSleepAvg.toFixed(1)}h nightly rest.`,
      );
    }
  }

  // Consistency insight
  if (sleepDebt.consistencyStatus === 'Inconsistent') {
    improvementAreas.push(
      `Your sleep schedule showed high variability this week (±${sleepDebt.sleepStdDevHours.toFixed(2)}h standard deviation).`,
    );
    sleepRecommendations.push(
      'Set a fixed morning wake-up alarm within a 30-minute window across weekdays and weekends.',
    );
  } else if (sleepDebt.consistencyStatus === 'Consistent') {
    positiveInsights.push(
      `Your sleep duration remained highly consistent (±${sleepDebt.sleepStdDevHours.toFixed(2)}h variance).`,
    );
  }

  // Caffeine vs sleep check
  const highCafDays = series.filter((d) => d.caffeineAtBedtimeMg >= 40 && d.totalSleep > 0);
  const lowCafDays = series.filter((d) => d.caffeineAtBedtimeMg < 40 && d.totalSleep > 0);
  if (highCafDays.length > 0 && lowCafDays.length > 0) {
    const avgHigh = highCafDays.reduce((a, d) => a + d.totalSleep, 0) / highCafDays.length;
    const avgLow = lowCafDays.reduce((a, d) => a + d.totalSleep, 0) / lowCafDays.length;
    if (avgLow > avgHigh + 0.25) {
      improvementAreas.push(
        `Nights with ≥40mg estimated caffeine remaining at bedtime averaged ${avgHigh.toFixed(2)}h sleep vs ${avgLow.toFixed(2)}h on lower-caffeine nights.`,
      );
      sleepRecommendations.push(
        'Move your last caffeinated drink at least 8–10 hours before bedtime to reduce estimated residual caffeine.',
      );
    }
  }

  // Study load vs focus balance
  const heavyStudyDays = pairedAll.filter((d) => d.totalStudyHours >= 6);
  const moderateStudyDays = pairedAll.filter((d) => d.totalStudyHours >= 3 && d.totalStudyHours < 6);
  if (heavyStudyDays.length > 0 && moderateStudyDays.length > 0) {
    const heavyFocus =
      heavyStudyDays.reduce((a, d) => a + (d.averageFocus as number), 0) / heavyStudyDays.length;
    const modFocus =
      moderateStudyDays.reduce((a, d) => a + (d.averageFocus as number), 0) /
      moderateStudyDays.length;
    if (modFocus > heavyFocus) {
      studyRecommendations.push(
        `Focused 3–6 hour study days yielded higher focus (${modFocus.toFixed(2)}/5) than 6+ hour marathon days (${heavyFocus.toFixed(2)}/5). Break intense topics into focused 90-minute blocks.`,
      );
    } else {
      studyRecommendations.push(
        'Schedule your hardest analytical subjects in the first 4 hours after waking when focus ratings peak.',
      );
    }
  }

  if (studyRecommendations.length === 0) {
    studyRecommendations.push(
      'Log study subjects alongside start/end times to pinpoint which time of day produces your highest Deep Focus ratings.',
    );
  }
  if (sleepRecommendations.length === 0) {
    sleepRecommendations.push(
      'Log nightly bedtimes and wake-up times consistently so DreamLog can identify your optimal sleep duration.',
    );
  }

  if (positiveInsights.length === 0) {
    positiveInsights.push(
      'Start logging both nightly sleep and daily study sessions to unlock personalized positive trend discoveries.',
    );
  }
  if (improvementAreas.length === 0 && series.length > 0) {
    improvementAreas.push(
      'No major sleep debt or focus drop alerts detected in your active tracking window.',
    );
  }

  const totalWeekStudy = thisWeek.reduce((a, d) => a + d.totalStudyHours, 0);
  const avgWeekSleep =
    thisWeekSleeps.length > 0
      ? thisWeekSleeps.reduce((a, d) => a + d.totalSleep, 0) / thisWeekSleeps.length
      : 0;
  const avgWeekFocus =
    thisWeekFocusDays.length > 0
      ? thisWeekFocusDays.reduce((a, d) => a + (d.averageFocus as number), 0) /
        thisWeekFocusDays.length
      : 0;

  const weeklySummary =
    thisWeekSleeps.length === 0 && thisWeekStudied.length === 0
      ? 'No records logged in the current 7-day window yet. Add your sleep and study logs to generate a weekly performance summary.'
      : `Over the last 7 days, you averaged ${avgWeekSleep.toFixed(2)}h of sleep across ${thisWeekSleeps.length} logged night${thisWeekSleeps.length === 1 ? '' : 's'}, logged ${totalWeekStudy.toFixed(1)}h of study with a ${avgWeekFocus.toFixed(2)}/5 mean focus rating, and accumulated ${sleepDebt.weeklyCumulativeDebt.toFixed(1)}h of sleep debt against your ${baseline}h tracking baseline.`;

  return {
    positiveInsights,
    improvementAreas,
    weeklySummary,
    sleepRecommendations,
    studyRecommendations,
    peakEfficiencyDay,
    focusDeltaPercent,
  };
}

export function getDashboardAnalytics(daysWindow = 21): DashboardAnalytics {
  const validWindow = [7, 14, 21, 30].includes(daysWindow) ? daysWindow : 21;
  const { series, allSeries, latestEntryDate, sleepLogs, studyLogs, caffeineLogs } =
    buildDailySeries(validWindow);

  const todayStr = getLocalDateStr(0);
  const weekCutoff = getLocalDateStr(-6);

  const lastNight = sleepLogs[0] ?? null;

  const weekSleepLogs = allSeries.filter(
    (d) => d.date >= weekCutoff && d.date <= todayStr && d.totalSleep > 0,
  );
  const averageWeeklySleep =
    weekSleepLogs.length > 0
      ? Math.round(
          (weekSleepLogs.reduce((a, d) => a + d.totalSleep, 0) / weekSleepLogs.length) * 100,
        ) / 100
      : 0;

  const totalStudyHoursThisWeek =
    Math.round(
      allSeries
        .filter((d) => d.date >= weekCutoff && d.date <= todayStr)
        .reduce((a, d) => a + d.totalStudyHours, 0) * 100,
    ) / 100;

  const cutoffStr = getLocalDateStr(-(validWindow - 1));
  const windowedStudyLogs = studyLogs.filter((s) => s.date >= cutoffStr && s.date <= todayStr);
  const averageFocusRating =
    windowedStudyLogs.length > 0
      ? Math.round(
          (windowedStudyLogs.reduce((a, s) => a + s.focusRating, 0) / windowedStudyLogs.length) *
            100,
        ) / 100
      : 0;

  const sleepDebt = computeSleepDebtSummary(series, allSeries);
  const correlation = computeCorrelationAnalysis(series, latestEntryDate);
  const insights = computeWeeklyInsights(series, allSeries, sleepDebt);

  // Subject-wise statistics in window
  const subjectMap = new Map<string, { hours: number; focusSum: number; count: number }>();
  for (const s of windowedStudyLogs) {
    const cur = subjectMap.get(s.subject) ?? { hours: 0, focusSum: 0, count: 0 };
    cur.hours += s.studyHours;
    cur.focusSum += s.focusRating;
    cur.count += 1;
    subjectMap.set(s.subject, cur);
  }

  const subjectStats: SubjectStat[] = Array.from(subjectMap.entries())
    .map(([subject, val]) => ({
      subject,
      totalHours: Math.round(val.hours * 100) / 100,
      sessionsCount: val.count,
      averageFocus: Math.round((val.focusSum / val.count) * 100) / 100,
    }))
    .sort((a, b) => b.totalHours - a.totalHours);

  // Recent Activity combined feed
  const recentActivity: ActivityItem[] = [
    ...sleepLogs.slice(0, 8).map((s) => ({
      id: `sleep-${s.id}`,
      type: 'sleep' as const,
      date: s.date,
      title: `Sleep Log (${s.sleepQuality}/5 quality)`,
      detail: `${s.bedtime} → ${s.wakeTime}${s.notes ? ` · ${s.notes}` : ''}`,
      metric: `${s.duration.toFixed(2)}h`,
      isDemo: s.isDemo,
      createdAt: s.createdAt,
    })),
    ...studyLogs.slice(0, 8).map((st) => ({
      id: `study-${st.id}`,
      type: 'study' as const,
      date: st.date,
      title: st.subject,
      detail: `Focus ${st.focusRating}/5${st.notes ? ` · ${st.notes}` : ''}`,
      metric: `${st.studyHours.toFixed(1)}h`,
      isDemo: st.isDemo,
      createdAt: st.createdAt,
    })),
    ...caffeineLogs.slice(0, 5).map((c) => ({
      id: `caf-${c.id}`,
      type: 'caffeine' as const,
      date: c.date,
      title: `${c.beverageType} Intake`,
      detail: `At ${c.consumptionTime}${c.notes ? ` · ${c.notes}` : ''}`,
      metric: `${c.caffeineAmount}mg`,
      isDemo: c.isDemo,
      createdAt: c.createdAt,
    })),
  ]
    .sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return b.createdAt.localeCompare(a.createdAt);
    })
    .slice(0, 10);

  const demoCount =
    sleepLogs.filter((s) => s.isDemo).length +
    studyLogs.filter((s) => s.isDemo).length +
    caffeineLogs.filter((c) => c.isDemo).length;

  return {
    daysWindow: validWindow,
    hasDemoData: demoCount > 0,
    demoCount,
    totalSleepLogs: sleepLogs.length,
    totalStudyLogs: studyLogs.length,
    lastNightSleep: lastNight
      ? {
          duration: lastNight.duration,
          date: lastNight.date,
          bedtime: lastNight.bedtime,
          wakeTime: lastNight.wakeTime,
          quality: lastNight.sleepQuality,
        }
      : {
          duration: null,
          date: null,
          bedtime: null,
          wakeTime: null,
          quality: null,
        },
    averageWeeklySleep,
    totalStudyHoursThisWeek,
    averageFocusRating,
    weeklySleepDebt: sleepDebt.weeklyCumulativeDebt,
    consistencyStatus: sleepDebt.consistencyStatus,
    dailySeries: series,
    subjectStats,
    recentActivity,
    correlation,
    sleepDebt,
    insights,
    latestEntryDate,
  };
}

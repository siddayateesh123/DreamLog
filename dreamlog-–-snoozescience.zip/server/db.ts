import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import {
  calculateSleepDuration,
  generateProtectiveExamTimetable,
  getLocalDateStr,
} from '../src/shared/math.ts';
import type { ExamSchedule, UserSettings } from '../src/shared/types.ts';

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'dreamlog.db');
export const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS sleep_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      bedtime TEXT NOT NULL,
      wakeTime TEXT NOT NULL,
      duration REAL NOT NULL,
      sleepQuality INTEGER NOT NULL,
      notes TEXT DEFAULT '',
      isDemo INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS study_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      subject TEXT NOT NULL,
      studyHours REAL NOT NULL,
      focusRating INTEGER NOT NULL,
      startTime TEXT DEFAULT '',
      endTime TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      isDemo INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS daily_metrics (
      date TEXT PRIMARY KEY,
      totalSleep REAL DEFAULT 0,
      totalStudyHours REAL DEFAULT 0,
      averageFocus REAL,
      sleepDebt REAL DEFAULT 0,
      correlationMetrics TEXT DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS caffeine_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      beverageType TEXT NOT NULL,
      consumptionTime TEXT NOT NULL,
      caffeineAmount REAL NOT NULL,
      notes TEXT DEFAULT '',
      isDemo INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS exam_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      examDate TEXT NOT NULL,
      subject TEXT NOT NULL,
      topics TEXT NOT NULL,
      priority TEXT NOT NULL,
      estimatedHours REAL DEFAULT 4,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS exam_plan_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      startTime TEXT NOT NULL,
      endTime TEXT NOT NULL,
      title TEXT NOT NULL,
      subject TEXT NOT NULL,
      type TEXT NOT NULL,
      completed INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS user_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      studentName TEXT NOT NULL,
      sleepBaselineHours REAL NOT NULL DEFAULT 8,
      caffeineHalfLifeHours REAL NOT NULL DEFAULT 5,
      preferredWakeTime TEXT NOT NULL DEFAULT '07:00',
      dailyAvailableHours REAL NOT NULL DEFAULT 7,
      onboardingDismissed INTEGER NOT NULL DEFAULT 0,
      demoCleared INTEGER NOT NULL DEFAULT 0
    );
  `);

  const settingsRow = db.prepare('SELECT * FROM user_settings WHERE id = 1').get() as
    | { id: number; demoCleared: number }
    | undefined;

  if (!settingsRow) {
    db.prepare(
      `INSERT INTO user_settings (id, studentName, sleepBaselineHours, caffeineHalfLifeHours, preferredWakeTime, dailyAvailableHours, onboardingDismissed, demoCleared)
       VALUES (1, ?, 8, 5, '07:30', 7, 0, 0)`,
    ).run('Maya Lin');
    seedDemoData();
  }
}

interface DemoDayTemplate {
  bedtime: string;
  wakeTime: string;
  quality: number;
  sleepNotes: string;
  sessions: Array<{
    subject: string;
    hours: number;
    focus: number;
    startTime: string;
    endTime: string;
    notes: string;
  }>;
  caffeine?: Array<{
    type: 'Coffee' | 'Tea' | 'Other';
    time: string;
    mg: number;
    notes: string;
  }>;
}

const DEMO_21_DAYS: DemoDayTemplate[] = [
  {
    bedtime: '23:15',
    wakeTime: '07:15',
    quality: 4,
    sleepNotes: 'Steady wind-down before midnight',
    sessions: [
      { subject: 'Algorithms', hours: 3.5, focus: 4, startTime: '09:30', endTime: '13:00', notes: 'Graph traversal problem set' },
      { subject: 'Linear Algebra', hours: 2.0, focus: 4, startTime: '15:00', endTime: '17:00', notes: 'Eigenvalue proofs' },
    ],
    caffeine: [{ type: 'Coffee', time: '08:30', mg: 95, notes: 'Morning filter coffee' }],
  },
  {
    bedtime: '00:45',
    wakeTime: '06:45',
    quality: 3,
    sleepNotes: 'Stayed up finishing lab writeup',
    sessions: [
      { subject: 'Operating Systems', hours: 4.0, focus: 3, startTime: '10:00', endTime: '14:00', notes: 'Virtual memory paging' },
    ],
    caffeine: [
      { type: 'Coffee', time: '09:00', mg: 110, notes: 'Drip coffee' },
      { type: 'Tea', time: '16:30', mg: 45, notes: 'Afternoon green tea' },
    ],
  },
  {
    bedtime: '01:30',
    wakeTime: '06:45',
    quality: 2,
    sleepNotes: 'Short sleep; felt groggy in morning lecture',
    sessions: [
      { subject: 'Organic Chemistry', hours: 3.0, focus: 2, startTime: '13:00', endTime: '16:00', notes: 'Slow recall on reaction mechanisms' },
    ],
    caffeine: [
      { type: 'Coffee', time: '08:00', mg: 140, notes: 'Double espresso' },
      { type: 'Other', time: '18:00', mg: 120, notes: 'Energy drink before library' },
    ],
  },
  {
    bedtime: '22:45',
    wakeTime: '07:30',
    quality: 5,
    sleepNotes: 'Deep restorative recovery sleep',
    sessions: [
      { subject: 'Algorithms', hours: 4.5, focus: 5, startTime: '09:00', endTime: '13:30', notes: 'Dynamic programming mastery' },
      { subject: 'Data Structures', hours: 1.5, focus: 4, startTime: '15:30', endTime: '17:00', notes: 'Balanced BST implementation' },
    ],
    caffeine: [{ type: 'Tea', time: '09:00', mg: 40, notes: 'Morning matcha' }],
  },
  {
    bedtime: '23:30',
    wakeTime: '07:15',
    quality: 4,
    sleepNotes: 'Good sleep continuity',
    sessions: [
      { subject: 'Macroeconomics', hours: 3.5, focus: 4, startTime: '10:30', endTime: '14:00', notes: 'Monetary policy models' },
    ],
  },
  {
    bedtime: '01:00',
    wakeTime: '07:00',
    quality: 3,
    sleepNotes: 'Late screen time delayed sleep onset',
    sessions: [
      { subject: 'Linear Algebra', hours: 4.5, focus: 3, startTime: '11:00', endTime: '15:30', notes: 'SVD practice problems' },
    ],
    caffeine: [{ type: 'Coffee', time: '14:30', mg: 95, notes: 'Afternoon iced coffee' }],
  },
  {
    bedtime: '22:30',
    wakeTime: '07:15',
    quality: 5,
    sleepNotes: 'Weekend catch-up sleep',
    sessions: [
      { subject: 'Operating Systems', hours: 3.0, focus: 5, startTime: '10:00', endTime: '13:00', notes: 'Thread synchronization lab' },
    ],
  },
  {
    bedtime: '23:45',
    wakeTime: '07:15',
    quality: 4,
    sleepNotes: 'Consistent wake time',
    sessions: [
      { subject: 'Algorithms', hours: 5.0, focus: 4, startTime: '09:30', endTime: '14:30', notes: 'Greedy algorithms & proofs' },
    ],
    caffeine: [{ type: 'Coffee', time: '08:45', mg: 95, notes: 'Morning pour-over' }],
  },
  {
    bedtime: '01:45',
    wakeTime: '07:00',
    quality: 2,
    sleepNotes: 'Quiz prep ran too late',
    sessions: [
      { subject: 'Organic Chemistry', hours: 2.5, focus: 2, startTime: '13:30', endTime: '16:00', notes: 'Hard to sustain focus' },
    ],
    caffeine: [
      { type: 'Coffee', time: '09:15', mg: 120, notes: 'Cold brew' },
      { type: 'Coffee', time: '17:30', mg: 95, notes: 'Evening coffee' },
    ],
  },
  {
    bedtime: '23:15',
    wakeTime: '07:00',
    quality: 4,
    sleepNotes: 'Solid 7h 45m rest',
    sessions: [
      { subject: 'Data Structures', hours: 4.0, focus: 4, startTime: '09:30', endTime: '13:30', notes: 'Heaps & priority queues' },
    ],
  },
  {
    bedtime: '22:45',
    wakeTime: '07:15',
    quality: 5,
    sleepNotes: 'Zero caffeine after noon helped',
    sessions: [
      { subject: 'Linear Algebra', hours: 4.0, focus: 5, startTime: '09:00', endTime: '13:00', notes: 'Orthogonal projections' },
      { subject: 'Algorithms', hours: 2.0, focus: 5, startTime: '15:00', endTime: '17:00', notes: 'Shortest path review' },
    ],
    caffeine: [{ type: 'Tea', time: '09:30', mg: 45, notes: 'Earl grey' }],
  },
  {
    bedtime: '00:30',
    wakeTime: '06:45',
    quality: 3,
    sleepNotes: 'Slightly short night',
    sessions: [
      { subject: 'Macroeconomics', hours: 5.5, focus: 3, startTime: '10:00', endTime: '15:30', notes: 'Reading-heavy day' },
    ],
  },
  {
    bedtime: '23:30',
    wakeTime: '06:30',
    quality: 3,
    sleepNotes: 'Early morning seminar',
    sessions: [
      { subject: 'Operating Systems', hours: 3.5, focus: 4, startTime: '11:00', endTime: '14:30', notes: 'File system design' },
    ],
  },
  {
    bedtime: '23:00',
    wakeTime: '07:45',
    quality: 5,
    sleepNotes: 'Long uninterrupted sleep',
    sessions: [
      { subject: 'Algorithms', hours: 4.5, focus: 5, startTime: '09:30', endTime: '14:00', notes: 'Flow networks' },
    ],
    caffeine: [{ type: 'Coffee', time: '09:00', mg: 95, notes: 'Morning coffee' }],
  },
  {
    bedtime: '01:15',
    wakeTime: '06:30',
    quality: 2,
    sleepNotes: 'Restless sleep after late study',
    sessions: [
      { subject: 'Organic Chemistry', hours: 3.0, focus: 2, startTime: '13:00', endTime: '16:00', notes: 'Frequent distractions' },
    ],
    caffeine: [{ type: 'Coffee', time: '16:15', mg: 115, notes: 'Late afternoon latte' }],
  },
  {
    bedtime: '23:00',
    wakeTime: '07:00',
    quality: 4,
    sleepNotes: 'Back on 8h baseline',
    sessions: [
      { subject: 'Data Structures', hours: 4.0, focus: 4, startTime: '09:30', endTime: '13:30', notes: 'Trie & suffix trees' },
      { subject: 'Macroeconomics', hours: 2.0, focus: 4, startTime: '15:00', endTime: '17:00', notes: 'Case study notes' },
    ],
    caffeine: [{ type: 'Tea', time: '10:00', mg: 40, notes: 'Green tea' }],
  },
  {
    bedtime: '00:15',
    wakeTime: '06:45',
    quality: 3,
    sleepNotes: 'Moderate sleep duration',
    sessions: [
      { subject: 'Linear Algebra', hours: 4.0, focus: 3, startTime: '10:00', endTime: '14:00', notes: 'Matrix decompositions' },
    ],
    caffeine: [{ type: 'Coffee', time: '11:30', mg: 95, notes: 'Mid-morning coffee' }],
  },
  {
    bedtime: '22:45',
    wakeTime: '07:30',
    quality: 5,
    sleepNotes: 'Best focus morning of the week',
    sessions: [
      { subject: 'Algorithms', hours: 5.0, focus: 5, startTime: '09:00', endTime: '14:00', notes: 'NP-completeness reductions' },
    ],
    caffeine: [{ type: 'Tea', time: '08:45', mg: 45, notes: 'Matcha latte' }],
  },
  {
    bedtime: '01:15',
    wakeTime: '07:00',
    quality: 2,
    sleepNotes: 'Group project deadline',
    sessions: [
      { subject: 'Operating Systems', hours: 6.5, focus: 2, startTime: '10:00', endTime: '16:30', notes: 'Long grind, diminishing returns' },
    ],
    caffeine: [
      { type: 'Coffee', time: '08:30', mg: 130, notes: 'Strong cold brew' },
      { type: 'Other', time: '17:00', mg: 85, notes: 'Yerba mate' },
    ],
  },
  {
    bedtime: '23:15',
    wakeTime: '07:15',
    quality: 4,
    sleepNotes: 'Recovered rhythm cleanly',
    sessions: [
      { subject: 'Data Structures', hours: 4.0, focus: 4, startTime: '09:30', endTime: '13:30', notes: 'AVL rotations practice' },
    ],
    caffeine: [{ type: 'Coffee', time: '09:15', mg: 95, notes: 'Morning coffee' }],
  },
  {
    bedtime: '23:30',
    wakeTime: '07:00',
    quality: 4,
    sleepNotes: 'Steady 7h 30m before demo day',
    sessions: [
      { subject: 'Linear Algebra', hours: 3.5, focus: 4, startTime: '10:00', endTime: '13:30', notes: 'Practice exam walkthrough' },
    ],
    caffeine: [{ type: 'Tea', time: '10:30', mg: 40, notes: 'Black tea' }],
  },
];

export function seedDemoData() {
  const nowIso = new Date().toISOString();

  const insertSleep = db.prepare(
    `INSERT INTO sleep_logs (date, bedtime, wakeTime, duration, sleepQuality, notes, isDemo, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, 1, ?)`,
  );
  const insertStudy = db.prepare(
    `INSERT INTO study_logs (date, subject, studyHours, focusRating, startTime, endTime, notes, isDemo, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)`,
  );
  const insertCaffeine = db.prepare(
    `INSERT INTO caffeine_logs (date, beverageType, consumptionTime, caffeineAmount, notes, isDemo, createdAt)
     VALUES (?, ?, ?, ?, ?, 1, ?)`,
  );

  const tx = db.transaction(() => {
    // Seed 21 days ending yesterday (-21 to -1) so today (0) is open for immediate logging
    for (let i = 0; i < DEMO_21_DAYS.length; i++) {
      const offset = i - 21; // -21 ... -1
      const dateStr = getLocalDateStr(offset);
      const day = DEMO_21_DAYS[i];
      const duration = calculateSleepDuration(day.bedtime, day.wakeTime);

      insertSleep.run(dateStr, day.bedtime, day.wakeTime, duration, day.quality, day.sleepNotes, nowIso);

      for (const s of day.sessions) {
        insertStudy.run(dateStr, s.subject, s.hours, s.focus, s.startTime, s.endTime, s.notes, nowIso);
      }

      if (day.caffeine) {
        for (const c of day.caffeine) {
          insertCaffeine.run(dateStr, c.type, c.time, c.mg, c.notes, nowIso);
        }
      }
    }

    // Seed sample upcoming exams if none exist
    const existingExams = (db.prepare('SELECT COUNT(*) as cnt FROM exam_schedules').get() as { cnt: number }).cnt;
    if (existingExams === 0) {
      const insertExam = db.prepare(
        `INSERT INTO exam_schedules (examDate, subject, topics, priority, estimatedHours, createdAt)
         VALUES (?, ?, ?, ?, ?, ?)`,
      );
      insertExam.run(
        getLocalDateStr(4),
        'Algorithms',
        'Dynamic Programming, Graph Traversal, Network Flow, NP-Completeness',
        'High',
        10,
        nowIso,
      );
      insertExam.run(
        getLocalDateStr(7),
        'Linear Algebra',
        'Eigenvalues, SVD, Orthogonal Projections',
        'Medium',
        7,
        nowIso,
      );
      insertExam.run(
        getLocalDateStr(10),
        'Operating Systems',
        'Virtual Memory, Thread Synchronization, File Systems',
        'Medium',
        6,
        nowIso,
      );

      const exams = db.prepare('SELECT * FROM exam_schedules').all() as ExamSchedule[];
      const settings = getUserSettings();
      const generated = generateProtectiveExamTimetable(
        exams,
        settings.dailyAvailableHours,
        settings.preferredWakeTime,
        getLocalDateStr(0),
      );
      const insertTask = db.prepare(
        `INSERT INTO exam_plan_tasks (date, startTime, endTime, title, subject, type, completed)
         VALUES (?, ?, ?, ?, ?, ?, 0)`,
      );
      for (const t of generated.tasks) {
        insertTask.run(t.date, t.startTime, t.endTime, t.title, t.subject, t.type);
      }
    }

    db.prepare('UPDATE user_settings SET demoCleared = 0 WHERE id = 1').run();
  });

  tx();
  rebuildDailyMetrics();
}

export function clearDemoData() {
  db.transaction(() => {
    db.prepare('DELETE FROM sleep_logs WHERE isDemo = 1').run();
    db.prepare('DELETE FROM study_logs WHERE isDemo = 1').run();
    db.prepare('DELETE FROM caffeine_logs WHERE isDemo = 1').run();
    db.prepare('UPDATE user_settings SET demoCleared = 1 WHERE id = 1').run();
  })();
  rebuildDailyMetrics();
}

export function resetDemoData() {
  db.transaction(() => {
    db.prepare('DELETE FROM sleep_logs WHERE isDemo = 1').run();
    db.prepare('DELETE FROM study_logs WHERE isDemo = 1').run();
    db.prepare('DELETE FROM caffeine_logs WHERE isDemo = 1').run();
  })();
  seedDemoData();
}

export function getUserSettings(): UserSettings {
  const row = db.prepare('SELECT * FROM user_settings WHERE id = 1').get() as {
    studentName: string;
    sleepBaselineHours: number;
    caffeineHalfLifeHours: number;
    preferredWakeTime: string;
    dailyAvailableHours: number;
    onboardingDismissed: number;
    demoCleared: number;
  };
  return {
    studentName: row.studentName,
    sleepBaselineHours: row.sleepBaselineHours,
    caffeineHalfLifeHours: row.caffeineHalfLifeHours,
    preferredWakeTime: row.preferredWakeTime,
    dailyAvailableHours: row.dailyAvailableHours,
    onboardingDismissed: Boolean(row.onboardingDismissed),
    demoCleared: Boolean(row.demoCleared),
  };
}

export function rebuildDailyMetrics() {
  const settings = getUserSettings();
  const baseline = settings.sleepBaselineHours || 8;

  const sleepRows = db.prepare('SELECT date, duration FROM sleep_logs').all() as Array<{
    date: string;
    duration: number;
  }>;
  const studyRows = db.prepare('SELECT date, studyHours, focusRating FROM study_logs').all() as Array<{
    date: string;
    studyHours: number;
    focusRating: number;
  }>;

  const dateMap = new Map<
    string,
    { totalSleep: number; totalStudyHours: number; focusSum: number; focusCount: number }
  >();

  for (const s of sleepRows) {
    const entry = dateMap.get(s.date) ?? {
      totalSleep: 0,
      totalStudyHours: 0,
      focusSum: 0,
      focusCount: 0,
    };
    entry.totalSleep += s.duration;
    dateMap.set(s.date, entry);
  }

  for (const st of studyRows) {
    const entry = dateMap.get(st.date) ?? {
      totalSleep: 0,
      totalStudyHours: 0,
      focusSum: 0,
      focusCount: 0,
    };
    entry.totalStudyHours += st.studyHours;
    entry.focusSum += st.focusRating;
    entry.focusCount += 1;
    dateMap.set(st.date, entry);
  }

  const tx = db.transaction(() => {
    db.prepare('DELETE FROM daily_metrics').run();
    const insertMetric = db.prepare(
      `INSERT INTO daily_metrics (date, totalSleep, totalStudyHours, averageFocus, sleepDebt, correlationMetrics)
       VALUES (?, ?, ?, ?, ?, ?)`,
    );

    for (const [date, agg] of dateMap.entries()) {
      const totalSleep = Math.round(agg.totalSleep * 100) / 100;
      const totalStudyHours = Math.round(agg.totalStudyHours * 100) / 100;
      const averageFocus =
        agg.focusCount > 0 ? Math.round((agg.focusSum / agg.focusCount) * 100) / 100 : null;
      const sleepDebt = totalSleep > 0 ? Math.max(0, Math.round((baseline - totalSleep) * 100) / 100) : 0;

      insertMetric.run(
        date,
        totalSleep,
        totalStudyHours,
        averageFocus,
        sleepDebt,
        JSON.stringify({ paired: totalSleep > 0 && averageFocus !== null }),
      );
    }
  });

  tx();
}

# DreamLog – SnoozeScience Implementation Plan

DreamLog – SnoozeScience is a full-stack student wellness and academic productivity analytics platform that turns nightly sleep logs and daily study sessions into verifiable statistical insights. It demonstrates how sleep duration, sleep consistency, and caffeine timing relate to study focus through live Pearson correlation, OLS regression trendlines, cumulative sleep debt tracking, exam-week protective scheduling, and exportable wellness reports.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and user-experience choices were confirmed during discovery and govern the build:

- **Entry Flow (Confirmed)**: Users enter on a dedicated Welcome Landing Page (`Sleep Smarter. Study Better.`) with direct **"Get Started"** and **"Explore Dashboard"** actions transitioning smoothly into the full analytics workspace.
- **Persistence Strategy (Confirmed)**: A Node.js + Express REST API backed by a persistent SQLite database stores all sleep logs, study sessions, daily aggregated metrics, caffeine logs, exam schedules, and student settings across browser refreshes.
- **Initial Sample Dataset (Confirmed)**: The database pre-seeds 21 days of realistic **DEMO DATA** on first boot (clearly labeled in the interface) with explicit controls to explore, clear all sample data, or restore the demo dataset at any time.
- **Wellness Report Export (Confirmed)**: Client-side PDF generation captures live Chart.js canvas snapshots alongside calculated metrics, insights, and academic-advisor disclaimers into a downloadable, print-ready PDF document.

---

## 1. Overview & Core Concept

- **What It Does**: DreamLog – SnoozeScience pairs effortless daily logging (sleep times across midnight, multi-subject study blocks, focus ratings, and caffeine intake) with a real-time statistical analytics engine. Every new log immediately updates dashboard KPIs, Pearson correlation (`r`), OLS regression slopes, sleep debt curves, and personalized recommendations.
- **Target Audience & Context**: College students balancing coursework, projects, and exam periods who often trade sleep for extra study hours—and need concrete personal evidence of how rest impacts cognitive focus.
- **Key Value**: Replaces guesswork with personal empirical proof: showing exact focus differentials after well-rested nights, quantifying cumulative sleep debt against an 8-hour tracking baseline, and protecting sleep during exam week with constraint-enforced study schedules.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Welcome & Onboarding Flow**:
   - Visitors arrive at the dark-mode landing experience featuring the DreamLog brand, *"Sleep Smarter. Study Better."* proposition, bespoke night-sky/academic hero visual, numbered how-it-works capabilities, and statistical benefit highlights.
   - Clicking **Get Started** or **Explore Dashboard** opens the workspace with a dismissible quick-start onboarding card explaining how to log sleep and study sessions (without blocking immediate chart access).
2. **Core Daily Logging & Live Recalculation Flow (Demo Scenario)**:
   - On the **Dashboard** or dedicated **Sleep Tracker** / **Study Tracker** views, the student logs last night's sleep (e.g., `11:30 PM` to `7:30 AM` automatically computed across midnight as `8h 0m`, `4/5` quality) and today's study session (`Algorithms`, `4.5 hours`, `5/5 – Deep Focus`).
   - Saving immediately persists via the REST API, triggers server-side and client-synchronized recalculation across the 21-day + newly added dataset, updates all 7 dashboard KPI counters, refreshes the weekly optimization insights, and visually highlights the newly logged observation on the *"How Sleep Affects Your Study Focus"* scatter plot.
3. **Deep-Dive Analytics & Stretch Tool Flows**:
   - Students switch between `7`, `14`, `21`, and `30` day date windows on the Dashboard and Analytics views, inspect cumulative sleep debt, compute 90-minute cycle bedtimes, track 5-hour caffeine half-life clearance before bed, build constraint-safe exam timetables, and export advisor-ready PDF wellness reports.

### Visual Identity & Theme

- **Aesthetic Direction**: Refined nocturnal telemetry and Apple Health-inspired academic analytics—calm, high-contrast, trustworthy, and uncluttered, avoiding neon cyberpunk clichés or decorative clutter.
- **Color Palette & 60-30-10 Discipline**:
  - *Dominant Canvas (60%)*: Deep Midnight Slate (`#0F172A`) primary background and Secondary Obsidian (`#111827`) structural backdrop.
  - *Structural Surfaces (30%)*: Elevated Slate (`#1E293B`) with subtle translucent glassmorphism and crisp `1px` hairline borders (`rgba(148, 163, 184, 0.14)`), Primary Text (`#F8FAFC`), and Secondary Text (`#94A3B8`).
  - *Focused Accents & Semantic States (10%)*: Soft Blue (`#60A5FA`) for primary actions and sleep metrics; Soft Amber (`#FBBF24`) for focus/study highlights; Success Emerald (`#34D399`), Warning Amber (`#F59E0B`), and Alert Coral (`#F87171`)—always paired with explicit text labels or icons rather than color alone.
- **Typography & Tabular Discipline**:
  - *Display & Navigation*: `Plus Jakarta Sans` (`600–700`, tight tracking, `text-wrap: balance` on headlines).
  - *Body & Form Prose*: `DM Sans` (`400–500`, `1.5–1.7` line-height, subtle optical tracking on dark surfaces).
  - *Metrics, Durations, Timestamps & Tables*: `JetBrains Mono` with strict `font-variant-numeric: tabular-nums` so numbers align vertically without jitter.
- **Layout Architecture**:
  - *Landing Page*: Clean 3-zone single-row header (wordmark, concise text links, primary CTA), asymmetric hero split with bespoke 16:9 illustration, numbered capability grid, proof-adjacent metrics, and quiet footer.
  - *Workspace Shell*: Responsive `256px` left sidebar with all 10 navigation modules, student profile summary, active notification drawer, and a compact mobile bottom navigation bar (`<= 15%` viewport height). Single-elevation cards with generous whitespace and unboxed typographic metadata (`·` separators, zero static pill clutter).
- **Interactive Feedback & Motion**:
  - Smooth number counter transitions on KPI updates, `<= 200ms` hover/focus settling, inline validation feedback, confirmation modals before destructive deletes or demo resets, skeleton loaders matching table/card geometry, and clear empty states with primary logging CTAs.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: True Paired-Date Statistical Engine with 7-Day Confidence Gate**
  - *Chosen Approach*: Pair sleep logs and study logs strictly by matching calendar date (`YYYY-MM-DD`), compute daily aggregate study hours and mean focus rating per day, and evaluate Pearson's `r` and Ordinary Least Squares (`y = mx + b`) dynamically across the filtered date window.
  - *Why*: Prevents misleading correlations from unpaired dates or fabricated numbers. Enforces the minimum `n >= 7` paired-observations threshold (displaying *"Needs at least 7 days of logs for statistical confidence."* below 7 pairs) and gracefully handles zero-variance edge cases (identical sleep durations or focus ratings).
  - *Alternatives Considered*: Interpolating missing days or displaying unconstrained `r` on 2–3 points—rejected because it violates statistical integrity.

- **Decision 2: Server-Authoritative SQLite Persistence + Pre-Seeded 21-Day Demo Mode**
  - *Chosen Approach*: Persist all 5 tables (`SleepLogs`, `StudyLogs`, `DailyMetrics`, `CaffeineLogs`, `ExamSchedules`) plus user preferences in a local SQLite database initialized automatically on server startup with 21 realistic, clearly tagged `DEMO DATA` days showing natural variance and a positive sleep-focus relationship.
  - *Why*: Guarantees durability across refreshes and clean REST API semantics (`/api/sleep`, `/api/study`, `/api/analytics/*`, `/api/caffeine`, `/api/exams`) while letting evaluators test both the pre-populated dataset and a clean personal slate with one click.
  - *Alternatives Considered*: Browser-only `localStorage`—rejected because the user selected Express + SQLite persistence for full-stack reliability.

- **Decision 3: Hard-Constraint Exam Week Sleep Preserver**
  - *Chosen Approach*: The schedule generator treats `<= 8h` daily study and `>= 7h` nightly sleep as non-negotiable invariants alongside meal and rest breaks. If total requested subject workload exceeds available safe capacity before exam dates, the planner generates the fullest safe schedule and renders an explicit capacity-shortfall warning rather than silently cutting sleep.
  - *Why*: Directly reinforces the application's core thesis that sacrificing sleep degrades exam performance.

- **Decision 4: Live Canvas-Embedded Client-Side PDF Export**
  - *Chosen Approach*: Render dedicated high-DPI Chart.js canvases (scatter + weekly trends) and serialize them directly into a formatted multi-section PDF document alongside metrics, dynamic insights, recommendations, and an explicit *"correlation does not imply causation"* academic disclaimer.
  - *Why*: Ensures exported PDFs reflect the user's exact filtered period and newly added entries without fragile headless-browser server dependencies.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         React + TypeScript Client                         │
│                                                                           │
│  ┌─────────────────┐   ┌───────────────────────────────────────────────┐  │
│  │  Landing View   │   │            10-Module Workspace Shell           │  │
│  │  - Hero & CTA   │   │  Sidebar (Desktop) / Bottom Nav (Mobile)      │  │
│  │  - How It Works │   │  Notifications · Profile · Demo Data Banner   │  │
│  └────────┬────────┘   └───────────────────────┬───────────────────────┘  │
│           │                                    │                          │
│           ▼                                    ▼                          │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │  Views: Dashboard · Sleep · Study · Analytics · Sleep Debt ·        │  │
│  │         Bedtime · Caffeine · Exam Planner · Reports · Settings      │  │
│  ├─────────────────────────────────────────────────────────────────────┤  │
│  │  Visualization & Export: Chart.js (Scatter/OLS/Bar/Line) + PDF Gen  │  │
│  └─────────────────────────────────┬───────────────────────────────────┘  │
└────────────────────────────────────┼──────────────────────────────────────┘
                                     │ REST JSON (/api/*)
                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                    Express.js + TypeScript API Server                     │
│                                                                           │
│  ┌─────────────────┐   ┌───────────────────────┐   ┌───────────────────┐  │
│  │ CRUD Validators │   │   Analytics Engine    │   │  Exam Scheduler   │  │
│  │ Sleep / Study / │──▶│ Pearson r · OLS Fit · │   │ 8h Study / 7h     │  │
│  │ Caffeine / Exam │   │ Sleep Debt · Insights │   │ Sleep Constraints │  │
│  └────────┬────────┘   └───────────┬───────────┘   └─────────┬─────────┘  │
│           │                        │                         │            │
│           ▼                        ▼                         ▼            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │             SQLite Persistence Layer (Auto-Seeded 21d Demo)         │  │
│  │   SleepLogs · StudyLogs · DailyMetrics · CaffeineLogs · ExamSched   │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Entities

- **SleepLogs**: `id`, `date` (`YYYY-MM-DD`), `bedtime` (`HH:mm`), `wakeTime` (`HH:mm`), `duration` (decimal hours, calculated across midnight when `wakeTime < bedtime`), `sleepQuality` (`1–5`), `notes`, `isDemo` flag.
- **StudyLogs**: `id`, `date`, `subject`, `studyHours`, `focusRating` (`1–5`), `startTime` (optional), `endTime` (optional), `notes`, `isDemo` flag.
- **DailyMetrics**: Recomputed per date (`totalSleep`, `totalStudyHours`, `averageFocus`, `sleepDebt = max(0, 8 - totalSleep)`, `correlationMetrics` snapshot) whenever sleep or study logs change.
- **CaffeineLogs**: `id`, `date`, `beverageType` (`Coffee` | `Tea` | `Other`), `consumptionTime`, `caffeineAmount` (mg), `isDemo` flag.
- **ExamSchedules**: `id`, `examDate`, `subject`, `topics`, `priority` (`High` | `Medium` | `Low`), `estimatedHours`, plus persisted generated timetable blocks and checklist completion states.
- **UserSettings**: `studentName`, `sleepBaselineHours` (default `8`), `caffeineHalfLifeHours` (default `5`), `preferredWakeTime`, `onboardingDismissed`.

### Interactive Component & State Mapping

- **Dashboard & Date Filter (`7d | 14d | 21d | 30d`)**: Queries `/api/analytics/dashboard?days=...`; animates 7 KPI counters, renders 4 synchronized Chart.js visualizations (Weekly Sleep Duration, Weekly Study Hours, Focus Rating Trend, and Sleep vs. Focus Scatter Plot with OLS line), Weekly Performance Summary, Recent Activity feed, and live Insights.
- **Nightly Sleep Logger**: Form with date, bedtime, wake-up time, live midnight-crossing duration preview (`Xh Ym`), 1–5 star selector, notes, validation (`duration > 0` and `< 24h`), and inline edit/delete with confirmation modal.
- **Study Session Tracker**: Form with date, subject quick-select/input, duration hours, optional start/end times (auto-filling duration when both supplied), 1–5 focus rating descriptions (`1 – Very Poor Focus` to `5 – Deep Focus`), notes, subject-wise breakdown chart, and session history table.
- **Correlation & Scatter Plot Engine**: Computes exact Pearson `r`, interpretation tier, observation count `n`, OLS regression equation (`y = mx + b`), and highlights the most recently added/selected point on the Chart.js scatter canvas (`pointStyle` differentiated by focus tier).
- **Sleep Debt & Consistency Monitor**: Computes daily debt against the `8h` tracking baseline (explicitly labeled as a tracking baseline, not a medical prescription), cumulative weekly debt, goal completion `%`, standard deviation-based sleep consistency status, and debt bar chart.
- **Bedtime Recommender, Caffeine Tracker, Exam Planner & PDF Reports**: Each module validates inputs, runs live domain formulas (90-minute sleep cycles + sleep latency; `Remaining = Initial * (0.5)^(t / halfLife)`; protective timetable builder enforcing `<= 8h` study and `>= 7h` sleep; multi-section PDF export with embedded chart images), and reflects updates immediately in the notification and profile state.
